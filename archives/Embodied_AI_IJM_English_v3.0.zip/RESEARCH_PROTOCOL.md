# Revision protocol for the third IJM English manuscript

Recorded on 22 September 2026 after the previous results and the supplied review were known. This is an exploratory revision protocol, not preregistration.

The user instructed the project to undertake the substantive revision recommended in `data/reviewer_comments_20260922.txt`. That instruction authorizes the specifically recommended three-record clarification layer, denominator alignment, exhaustive pair classification and document revision. It does not assert a new independent human reading of those records. Earlier author confirmation of full-corpus review remains accurately attributed to its date and scope.

## Fixed research scope

The accepted corpus, advertisement identities, task assignments, six task–technology combinations and 496-pair analytical frame remain unchanged. The primary observational key is the immutable advertisement `identity_key` together with `label_code`; the 248 advertisements contribute two observations each. Firm summaries aggregate these records by task, technology and company. Unordered company-pair keys additionally include the eligibility threshold. The data are a purposive cross-section of public advertisements, not a panel or a probability sample of employers. No causal effect is estimated.

`source_v2/` preserves the previous delivered package without modification. All new derived outputs are under `analysis/`; a versioned ledger records changes and their precise evidence. No update is made to the accepted research database or historical frozen files. Failed joins stop the affected calculation; unmatched identities are not dropped.

## Measurement and current analysis

M is observed mention presence. G and R retain the established unconditional general/required qualification distinction. Q is their advertisement-level union: P if either is P, Z if both are Z, U otherwise.

The current analysis applies only the three previously source-adjudicated explicit-example clarifications (A032, A065, A099: G and Q from U to Z; R remains Z). These are located through the preserved composite keys and source quotes, not through convenience reading IDs alone. Historical states are retained alongside revised states. Remaining disagreements do not automatically become either unknown or negative; their treatment must follow the same stated scope rule.

Report on the fixed task-advertisement base B: mention share M/B, confirmed-positive share P/B, unresolved share U/B and unknown-assignment bounds [P/B, (P+U)/B]. Report P/(B−U) separately as the evaluable-case conditional proportion. Never describe its ordering as an established full-task ordering.

For firm A minus firm B, report the difference bounds [lo_A−hi_B, hi_A−lo_B]. Strictly positive or negative bounds support a direction under assignments to recorded unknowns; a bound touching zero does not establish a strict direction. These are finite-corpus assignment ranges, not sampling confidence intervals. Exact rational arithmetic determines signs and endpoint equality.

## Comparisons and sensitivity

Retain the previous minimum evaluable-cell rule of at least ten observations separately for M, G and Q in both firms, and the secondary threshold of five. Explain G's role in keeping the M/G/Q comparisons on the same comparison frame, and report whether its requirement excludes any firm beyond Q. Show all 120 cells, including zeros and cells without an evaluable-case proportion, with B, M_N, G_N, Q_N and U/B. Also report how this eligibility differs from a B-only count threshold without substituting a new primary rule.

Classify each eligible M-to-Q comparison jointly by the conditional point ordering and difference-bound direction. Include bound-supported retention, bound-supported reversal, conditional-point reversal with overlapping bounds, same conditional direction with overlapping bounds, and explicit tie/zero cases if present. Do not infer the intersection from separate totals.

Keep distinct: the original frozen analysis, the corrected primary analysis, rule-admissible disputed readings, an extreme substitution of all fresh-reader outputs including rejected readings, and the previously authorized task-boundary restriction applied to the corrected version. All 496 frame rows remain stored with scenario inclusion flags. Compare exact company-pair keys across scenarios and separate any membership changes from changes for common pairs.

The admissible-reading layer will be finalized from the already observed ten disputed cases using source-grounded, explicit scope rules before generating its outputs. Record the original and alternative state sets and any linked interpretations within one advertisement. An optional envelope over allowed interpretations must distinguish semantic ambiguity from the original U-assignment bounds and preserve coupled readings.

## Manuscript and verification

Order the results as task–technology patterns, company coverage and comparisons, then source examples and sensitivity. Move detailed state-match matrices and execution history into one supplementary document. Describe author review directly in the author's voice without inventing row-level logs or independent double coding. Name observed model/deployment identifiers, dates, prompt/rule files and adjudication roles; state unavailable backend versions or run settings as unavailable.

Figures will use the fixed B denominator for the primary Q display. Move the small Linux unresolved label outside its bar and use company names rather than G/X initials. Reorganize literature by the measurement question. Retain the existing descriptive design; no new regressions, firms, collection waves or major theoretical modules are added. Publisher AI-policy work remains outside this revision at the user's earlier instruction; truthful methodological provenance remains in scope.

Numerical outputs must be independently checked, reproduced offline from the delivered snapshots, and tied to every table and key numerical statement. Render and inspect the final four documents, preserve v2 checksums, and provide a point-by-point response.
