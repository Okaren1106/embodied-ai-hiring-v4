# IJM English manuscript revision 3

Current manuscript: **Technology Mentions and Direct Qualification Expressions in Embodied AI Recruitment**. Revised on 22 September 2026 in response to the supplied second review. The current results use three documented example-scope clarifications and distinguish full-task confirmed shares, evaluable-case proportions and unknown-assignment bounds.

## Reading and submission files

| File | Purpose |
| --- | --- |
| `release/English_Manuscript_IJM.docx` | Complete English reading copy with three tables and two figures, 13 rendered pages |
| `release/IJM_Main_Text.docx` | Main text with five insertion calls and separate figure captions, 12 rendered pages |
| `release/IJM_Tables.docx` | Three numbered main tables, one per page |
| `release/Supplementary_Material.docx` | One supplementary document, seven tables, eight rendered pages |
| `release/figures/Figure_1` and `Figure_2` | Separate PNG, SVG and vector PDF figure files |
| `release/tables/S5_Full_Firm_Coverage.csv` | Full electronic coverage table with all 120 firm cells |
| `release/修订回应与研究结果.md` | Chinese point-by-point account of the completed revision |

The main Word file has 4,941 Word-counted words, including front matter, references, insertion calls and captions. Adding the review's allowance of 280 words for each of the five table/figure objects gives approximately 6,341 words. The abstract including headings and keywords contains 191 whitespace-delimited words, or 206 when compounds are split. These are transparent counts under the supplied review's formatting assumptions, not a certification by the publisher. The accompanying full research ZIP is an offline verification bundle; it is not intended to be uploaded wholesale as the manuscript. Local document PDFs and page PNGs were used for layout QA; the four document PDFs are excluded from the current delivery ZIP. Figure PDFs remain publication assets.

## Current results

The original corpus contains 1,654 advertisements from 24 entities. The technology analysis retains 248 advertisements, six task–technology combinations and all 496 advertisement–technology pairs. Current Q states are 170 positive, 280 nonpositive and 46 unresolved. The confirmed share on the full base is 34.3 per cent, the evaluable-case proportion is 37.8 per cent and the assignment bounds are 34.3–43.5 per cent.

| Galbot minus XSquare | Confirmed Q gap | Conditional Q gap | Q difference bounds |
| --- | ---: | ---: | ---: |
| Python | +52.4 pp | +53.6 pp | +19.0 to +63.5 pp |
| PyTorch | −1.6 pp | +1.2 pp | −1.6 to +9.5 pp |
| Linux | +27.5 pp | +33.3 pp | +27.5 to +33.8 pp |

The main comparisons support the Python and Linux directions but no PyTorch direction under every unknown assignment. At the lower threshold, 32 dependent comparisons comprise 22 supported retentions, five supported reversals, three conditional reversals with overlapping bounds and two same-direction conditional comparisons with overlapping bounds. All three main comparisons recur at the lower threshold.

Ten disputed readings form seven coupled switches and 128 deterministic combinations. Every combination retains the same company-pair identities. The 22 supported retentions and five supported reversals persist; a sixth reversal gains support in some readings. Across these readings and unknown assignments, the Linux difference envelope widens to +17.5 to +33.8 pp. The all-fresh extreme additionally includes rejected scope readings and is reported separately.

## Reproduce the numerical analysis

Extract the complete ZIP into a new directory, preserve its relative structure, and run with Python 3.12:

```text
python REPRODUCE.py
```

This command uses the standard library only. It verifies the frozen v2 manifest, applies the three versioned corrections, computes full-base and conditional measures, enumerates eligible pairs and sensitivity combinations, reconstructs the diagnostic ledger and performs independent numerical checks. It writes 28 files in `analysis/`, the revision ledger in `data/`, and two provenance CSV files: 31 deterministic outputs in total. `analysis/figure_coverage.json` belongs to the separate figure workflow and is not claimed as an output of this entry point. All 31 outputs were reproduced byte for byte in an isolated copy. The independent audit passes 26,089 checks, including 120 SQL-reconstructed cells, 70 independently enumerated original/current pairs, 22 exact source quotations and reconstruction of all 128 sensitivity readings.

Publication rendering is separate. `work/make_figures.py` requires matplotlib; `work/build_documents.py` requires python-docx and lxml. The document helpers create native Word equations and editable tables. The observed layout uses Times New Roman and SimSun. The bundled LibreOffice renderer was unavailable on this host; hidden local Microsoft Word exported read-only temporary copies, and PDFium generated the page images. All 36 final document pages were inspected. `verification/document_checks.json` records 212 structural, consistency, coverage and previous-version protection checks with no failures. Its renderer and page hashes identify the reviewed output.

## Evidence and output map

| Claim or object | Computed source |
| --- | --- |
| Main Table I; Figure 1 | `analysis/current_task_summary.csv` |
| Main Table II | `analysis/main_company_comparisons.csv` |
| Main Table III | `analysis/current_pair_summary.csv` |
| Figure 2; Supplementary S4 and S5 | `analysis/current_firm_cells.csv` and `current_task_summary.csv` |
| All current eligible comparisons | `analysis/current_firm_pairs.csv` |
| Current row states and historical counterparts | `analysis/ad_technology_current.csv` |
| Three primary revisions and authorization | `data/analysis_revision_ledger.json` |
| Supplementary S1 and diagnostic matrices | `source_v2/analysis/diagnostic_summary.csv` and `diagnostic_confusion.csv` |
| Supplementary S2 and S3 | `analysis/scenario_totals.csv` and `scenario_pair_summary.csv` |
| Complete retained/excluded scenario membership | `analysis/scenario_members.csv` |
| Named-scenario pair-identity checks | `analysis/scenario_key_audit.csv` |
| All admissible readings and results | `analysis/admissible_reading_switches.csv`, `admissible_reading_pairs.csv`, `admissible_reading_pair_summary.csv` |
| Cross-reading bounds and category ranges | `analysis/admissible_comparison_envelopes.csv`, `admissible_classification_ranges.csv` |
| Supplementary S6 and S7; all 22 decisions | `work/provenance/diagnostic_process.md`, `adjudication_policy.md`, `diagnostic_adjudication_ledger.csv` |
| Exact prompt, packets, sampling frame and frozen output | Paths and SHA-256 hashes in `work/provenance/diagnostic_process_hashes.csv` |
| Independent numerical oracle | `verification/independent_pairs.csv`, `independent_analysis.json` |
| Isolated reproduction | `verification/isolated_reproduction_report.json` |

Paths in the analytical supplement are relative to this package root, except `tables/`, which is relative to `release/`. The analysis unit uses composite `identity_key` plus `label_code`; convenience reading IDs do not replace composite identity. Comparison keys include threshold, task, technology and both company IDs.

## Version and inference boundaries

`source_v2/` is the complete immutable 147-file previous package, supplied only for baseline provenance. Its older manuscript and results are historical; the current manuscript is under `release/` and the current results under `analysis/`. The frozen original classifications and accepted research corpus have not been overwritten. Only A032, A065 and A099 are revised in the current primary analytical layer. The user authorized following the review's recommendation; this is not represented as a new independent human recoding of those rows.

Source-reading diagnostics and arithmetic reproduction establish different things. The former documents wording sensitivity using the saved model outputs and source adjudication; the latter establishes identities and computations. Neither supplies a human gold standard, industry representation, causal identification or an acceptance prediction. The manuscript keeps those limits in its methods and discussion. A public data archive and author/title-page metadata are not fabricated. Captured source advertisements remain third-party material.
