# Blinded source-reading diagnostic report

I read all 105 advertisement–technology cases in `packet_01.json` through `packet_07.json` and inspected every distinct supplied `source_fields` value. Exact duplicate fields were recognized as duplicates but their presence was still checked. I had no inability to inspect a supplied field.

For each case, `judgements.json` records fresh G, R, and derived Q states; an exact source quote when the target technology was mentioned; heading/scope treatment; branch reason; task-support assessment; rationale; and confidence. I applied the packet rule that ordinary `任职要求`, `岗位要求`, `Qualifications`, `What You Have`, and similar labels are general unless a section or statement is explicitly required/mandatory. I treated local choice, example, and preference wording as controlling over broader headings. I did not calculate agreement with any prior state.

The workspace entry instruction required reading the top-level `必读.md` before work. That exposed a high-level project summary, including aggregate research findings, workflow history, and a statement that an earlier Sol trial had systematically under-labelled technical requirements. It did not expose these 105 audit IDs, row-level prior G/R/Q states, row-level rationales, or a matching table. This diagnostic is therefore blinded to row-level prior coding, but not completely ignorant of the project's aggregate history. After that required read, I consulted only `READER_RULES.md` and the seven packet files for source judgments; I used no web data, source-state database, old coding table, manuscript, or other answer file.

This is an independent model-assisted source reading, not a human gold standard and not a claim of human-equivalent reliability.
