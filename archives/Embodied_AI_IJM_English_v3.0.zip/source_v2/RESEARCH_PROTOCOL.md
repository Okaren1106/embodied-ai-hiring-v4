# IJM substantive revision protocol

Recorded 2026-09-21 before producing the new union results and expanded comparisons. This is a revision protocol written with knowledge of the earlier paper's findings, not a preregistration or confirmatory design.

## Authorization and scope

The user requests all non-policy tasks in tier one and both tier-two enhancements in the supplied review, followed by a revised English paper. Publisher AI-use policy is outside this revision's scope. The approved reference corpus remains 24 entities and 1,654 advertisements; the career-page comparison scope remains 23 firms and 1,630 advertisements. No new firms, altered ad identities, new vacancies, or causal claims are introduced. Old releases and source classifications remain immutable.

The analytical core remains the three predefined task groups (105, 87 and 56 advertisements) and their six established task–technology combinations (496 ad–technology observations). Analysis at the ad–technology level uses the composite identity_key + label_code; firm–task–technology aggregates retain separate denominators. Task definitions, source-wave membership and original classifications are preserved.

## Construct extension

Retain M (recorded technology mention), G (GENERAL–UNCONDITIONAL), and R (REQUIRED–UNCONDITIONAL). Add Q, a heading-inclusive direct qualification expression: the advertisement-level union of G and R. Q is P if either constituent is P; Z if both are Z; U if neither is P and one is U. Any NA or source exclusion is separately reported and does not silently become Z. Inspect constituent eligibility before resolving other combinations. This is a named technology being directly specified in a qualification statement, not demonstrated job performance, a legally binding criterion, or realised hiring demand.

Extract both states from final source records; never add aggregate REQUIRED mentions to G. Report G/R overlap, R-only additions, the G-to-Q state transition table, original G and new Q denominators, and assignment bounds. Reproduce the published G counts before using Q.

## Measurement diagnostic

Conduct a bounded source-reading diagnostic with old labels withheld from a fresh reader. Draw deterministically within six task–technology cells, taking up to five observations from each of four prior categories: G positive, G unresolved, G nonpositive with M present, and no recorded mention. Use a fixed hash seed 20260921 to select cases; preserve all frame members and selection flags. This deliberately covers negative and unresolved cases and is not representative sampling for a population error rate. The five-per-stratum bound was fixed before drawing cases or viewing new diagnostic judgements.

The reader receives raw source fields, a neutral rule sheet and the target technology, but not old row states, prior evidence classifications or selection strata. Employer metadata is withheld and explicit employer names are redacted where possible. Any mandatory reading of the workspace's high-level progress summary is recorded: the diagnostic withholds row labels but does not claim complete blinding to prior aggregate conclusions. Ask for G, R, Q, evidence text, branch and heading rationale, and whether the predefined task has clear source support. All distinct source fields must be read; duplicate text may be recognised. Compare the new judgements with old records only after the reader's output is frozen. Review disagreements against original text and record explanations. Keep resulting alternative-state scenarios separate from original states. Do not present a new model reading as independent human coding or gold-standard accuracy. Actual author review is documented separately.

A same-target diagnostic may compare a transparent qualification-section keyword rule with the reviewed direct-expression target; it must not use the M-to-G gap as an error rate. Report confusion cells and unresolved cases rather than unsupported accuracy claims. Rule-level counterexamples will test qualification headings and choice/example branches.

## Empirical extension

Enumerate every firm–task–technology cell, including zero positives and small denominators. For comparative summaries, flag the prespecified common eligibility rule: M, G and Q each have at least ten evaluable ads. Enumerate all unordered firm pairs within each task–technology cell satisfying this rule. Report direction preserved/reversed/tied from M to Q, separately for G to Q; report whether assignment intervals overlap. These are descriptive comparisons sharing firms, not independent observations or significance tests. A threshold-five summary describes sensitivity to the display threshold. No firm is selected using outcome size or sign.

Retain earlier named cases as illustrations within this complete eligible background. Keep the two-company engineering decomposition as an illustrative account of composition and move it out of the headline contribution. Report source and evaluability of its actual member records separately from the existing firm-wide R1/R2/R3 filters, whose definitions remain unchanged.

## Provenance and presentation

Audit selection history, headquarters country, advertised job location, source language and collection wave without substituting one for another. Describe coding in original-language sources separately from translations quoted in the English paper. Use the user's new retrospective account of whole-corpus review and rule/category decisions, keeping its documentary limits explicit.

Final writing follows question → closest literature → gap → design → findings → contribution. Center recruitment interpretation and job analysis; consolidate limitations; use natural terminology. Numbers and figures must come from runnable programs and a fact ledger. Provide a new English paper, source-linked supplement, response matrix, and a self-contained numerical reproduction package. Completion depends on delivering the new analyses and paper, not on favourable findings or an assertion of journal acceptance.
