# Research package for the IJM English revision

This package accompanies **From Technology Mentions to Direct Qualifications in Embodied AI Recruitment**. It contains the new union measure, a bounded source-reading diagnostic and the complete eligible firm-comparison extension. The accepted corpus is unchanged. The original final coding remains the primary analysis; alternative interpretations are explicitly separated.

## Read the paper

- `release/English_Manuscript_IJM.docx` and `.pdf`: complete reading version with tables and figures.
- `release/IJM_Main_Text.docx`: article text with insertion callouts and figure captions.
- `release/IJM_Tables.docx`: Tables I–III; Table III has two panels.
- `release/Supplementary_Material.docx` and `.pdf`: selection, measurement, source examples and sensitivity details.
- `release/figures/`: two figures in PDF, SVG and 400-dpi PNG, generated from the included analysis.
- `release/修订回应与研究结果.md`: response to the supplied review and a concise account of the new research, in Chinese.

The four DOCX files are the English document set. Do not upload the entire working package as an anonymous manuscript. Author identity, affiliations and other author-supplied submission fields are not fabricated here. This revision does not claim journal acceptance or an independent human validation study.

## Reproduce the numbers offline

Use Python 3.10 or newer. Core calculations use the standard library and make no network calls:

```text
python REPRODUCE.py
```

The program regenerates the numerical outputs from frozen inputs and checks identities, joins, union arithmetic, all eligible pairs, sampled quotation provenance and scenario invariants. It also reconstructs the language/location and local decomposition source profiles from the included snapshots. Run in an extracted copy if you wish to preserve the packaged output files byte for byte.

To redraw figures, install matplotlib and run `python work/make_figures.py`. To rebuild DOCX files after edits, install python-docx and run `python work/build_documents.py`; the plot PNGs must already exist. `work/document_tools.py` is self-contained. `work/export_pdf.ps1` optionally exports temporary copies through Microsoft Word on Windows; it does not save changes to the source DOCX files. PDF appearance depends on the rendering environment.

## Locate the evidence

| Article component | Inputs and audit | Output |
| --- | --- | --- |
| G and R union, Table I, Figure 1 | `data/inputs/qualification_states.csv`, `context_index.csv`, `records.json`; `work/analyse.py` | `analysis/ad_technology_union.csv`, `task_technology_summary.csv`, `state_transitions.csv` |
| All firms, Figure 2, Table III | Same fixed 496 pairs and 248 advertisements | `analysis/firm_technology_union.csv` (120 cells), `all_eligible_firm_pairs.csv`, `firm_pair_summary.csv` |
| Diagnostic selection | `work/diagnostic_sampling_frame.csv` (all 496 pairs), `diagnostic_sample_summary.json`, `blind_review/packet.json` | 105 pairs from 94 distinct advertisements; all original and selection states retained |
| Fresh source reading, Table II | `blind_review/judgements.json`, `reader_report.md`; prior output frozen in `work/blind_output_freeze.json` | `analysis/diagnostic_comparison.csv`, `diagnostic_confusion.csv`, `diagnostic_summary.csv` |
| Interpretation and task alternatives | `work/diagnostic_adjudication.json`, `work/analyse_diagnostic.py` | All `analysis/diagnostic_scenario_*.csv`; no overwrite of original labels |
| Five required-only additions | Full source fields in `data/inputs/records.json` | `analysis/required_addition_source_check.csv` (five pairs, four advertisements) |
| Sample, location and language | `work/provenance/profile.py`, frozen provenance inputs and source manifest | `work/provenance/profile_records.csv`, `profile_summary.csv`, `profile_findings.md` |
| Selection and actual author review | `work/provenance/selection_ledger.csv`, `documented_review_evidence.md`, `source_evidence/` | Retrospective author statement and preserved completion records; no invented row-level human audit |
| Local engineering illustration | `data/inputs/D2_K_membership.csv`, `D2_decomposition_role_parts.csv`, `Q3_ads_final.csv` | `work/provenance/D2_record_evaluability.csv` and its summary, covering the actual 82 + 60 records |
| Background identities and scope | `data/inputs/decomposition_paper_extract.csv`, `O4_attribution_seniority_unknown.csv`, `R_source_scope_summary.csv`; `work/check_background.py` | `analysis/background_check.json`: decomposition identity, 84 work-object cases, 81 unlinked products and unchanged R1/R2/R3 scope |
| Reproduction checks | `work/check_analysis.py`, `work/check_diagnostic.py` | `analysis/independent_computation_check.json`, `independent_diagnostic_check.json` |

All paths are relative to this package root. Original project paths in provenance records identify historical origins; they are not required to reproduce the numerical results. `data/inputs/source_manifest.json` hashes the analytical snapshots. The package file manifest and verification report document the delivered version.

The package contains 18 hashed analytical input snapshots. The separate 1,654-row `work/provenance/source_profile_input.jsonl` snapshot and its manifest preserve the minimal source fields used for the language, location and local evaluability checks. Historical source-selection and author-review evidence is retained under `work/provenance/source_evidence/`. One-time extraction and legacy document-scaffolding helpers are omitted; the supplied reproduction and document-building tools use the included inputs.

## Final verification

The four final documents contain 35 pages, all visually inspected after PDF rendering. Their 545 table cells, including the repeated tables in the reading and separate-table versions, match the generated table assets. The isolated numerical reproduction regenerated 27 analysis and source-profile outputs byte for byte. All 482 files in the previous English release remained unchanged. Compact verification records are in `verification/`; `release/verification_summary.json` and `release/DELIVERY.json` summarize the delivered scope.

The complete reading document has 5,615 Microsoft Word words, and the two figures contain approximately 120 additional words. Adding Emerald's 280-word display allowance gives an article estimate of 7,135 words, or 7,415 if the two panels of Table III are counted separately. The 3,043-word supplementary document is separate. Counting methods and the publisher source are recorded in `verification/word_count.json`.

## Units and interpretation

`identity_key` identifies the advertisement source and text version. The analytical key is `identity_key` plus `label_code`; convenience reading IDs must never be used as the only join key. Each of the 248 task advertisements contributes two technology observations. Technology observations, firm cells and firm pairs are distinct units.

`M` denotes an explicit mention, `G` an unconditional general qualification and `R` an unconditional required qualification. `Q` is their advertisement-level union: P if either is P, Z if both are Z, and U otherwise. P means a positive expression is recorded; Z means no positive recorded in the observed scope; U means unresolved. These are textual expressions, not observed hiring decisions or actual skill demand.

For each measure, `N=P+Z`, `B=P+Z+U`, the point share is `P/N`, and unknown-assignment bounds are `[P/B, (P+U)/B]`. Empty point values have zero evaluable denominators and must not be replaced with zero. Bounds do not cover sampling error or unrecognized coding mistakes.

The main pair rule requires M, G and Q denominators of at least ten for both firms; the secondary rule uses five. The 35 rows of `all_eligible_firm_pairs.csv` comprise three main-threshold and 32 lower-threshold rows, with the main comparisons repeated in the latter. These are not 35 independent comparisons. Their interpretation is descriptive and conditional on a purposive sample.

The diagnostic is deliberately stratified. Its raw state matches are not accuracy estimates, a human reliability coefficient or proof of semantic correctness. The fresh-reading alternative deliberately retains all fresh readings, including those rejected under the original rules, as a sensitivity exercise. It is not a newly certified coding dataset.

## Source material and access

Captured job text and evidence excerpts are included for checking the research. They remain third-party material; this package asserts no blanket redistribution license over advertisements. URLs and source identifiers preserve origin information, but live pages may later change or disappear. No public repository is asserted. The package has been tested from an isolated local copy without access to the original project inputs.
