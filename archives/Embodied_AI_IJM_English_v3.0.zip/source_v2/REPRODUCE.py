"""Offline numerical reproduction. Run with Python 3.10 or newer from any directory."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
scripts=['work/analyse.py','work/analyse_diagnostic.py','work/check_required_additions.py',
         'work/check_analysis.py','work/check_diagnostic.py','work/check_background.py','work/provenance/profile.py']
for script in scripts:
 result=subprocess.run([sys.executable,str(root/script)],cwd=root,capture_output=True,text=True,encoding='utf-8')
 if result.returncode:
  print(result.stdout);print(result.stderr,file=sys.stderr)
  raise SystemExit(result.returncode)
 print('PASS '+script)
print('Reproduction complete. See analysis/ and work/provenance/ for numerical results and checks.')
