"""Copy the self-contained computation into a fresh root and compare all results."""
from pathlib import Path
import shutil,subprocess,sys,json,hashlib,uuid
E=Path(__file__).resolve().parents[1];V=E/'verification';V.mkdir(exist_ok=True)
dest=V/('isolated_'+uuid.uuid4().hex[:8]);dest.mkdir()
for folder in ['data','blind_review']:
 shutil.copytree(E/folder,dest/folder)
(dest/'work').mkdir()
shutil.copytree(E/'work/provenance',dest/'work/provenance')
for p in (E/'work').iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.csv']:
  shutil.copyfile(p,dest/'work'/p.name)
shutil.copyfile(E/'REPRODUCE.py',dest/'REPRODUCE.py')
result=subprocess.run([sys.executable,str(dest/'REPRODUCE.py')],cwd=dest,capture_output=True,text=True,encoding='utf-8')
(V/'isolated_run.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
assert result.returncode==0,result.stderr
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
compared=[]
for p in sorted((dest/'analysis').iterdir()):
 expected=E/'analysis'/p.name
 assert p.read_bytes()==expected.read_bytes(),p.name
 compared.append(str(p.relative_to(dest)))
for name in ['profile_records.csv','profile_summary.csv','profile_summary.json','D2_record_evaluability.csv','D2_record_evaluability_summary.csv']:
 p=dest/'work/provenance'/name
 assert p.read_bytes()==(E/'work/provenance'/name).read_bytes(),name
 compared.append(str(p.relative_to(dest)))
report={'independent_directory':dest.name,'analysis_and_profile_files_byte_identical':len(compared),'files':compared,'reproduction_returncode':0,'failures':0,'input_mode':'self-contained snapshots; no original project inputs needed'}
(V/'isolated_reproduction.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
