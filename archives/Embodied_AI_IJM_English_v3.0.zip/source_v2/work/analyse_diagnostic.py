"""Reconcile frozen diagnostic with original states and compute bounded alternatives.
Original data remain unchanged. Alternative recoding applies only to sampled pairs;
task restriction is a separately labelled hypothetical scenario and retains all frame rows.
No agreement rate is interpreted as accuracy or population coding reliability.
"""
from pathlib import Path
import json,csv,collections,itertools,hashlib,copy,ast
E=Path(__file__).resolve().parents[1];W=E/'work';O=E/'analysis';I=E/'data/inputs'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 with (O/name).open('w',encoding='utf-8',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
frozen=json.loads((W/'blind_output_freeze.json').read_text(encoding='utf-8'))
assert hashlib.sha256((E/'blind_review/judgements.json').read_bytes()).hexdigest()==frozen['sha256']
judgements=json.loads((E/'blind_review/judgements.json').read_text(encoding='utf-8'))
frame={r['audit_id']:r for r in read(W/'diagnostic_sampling_frame.csv') if r['audit_id']}
assert len(judgements)==len(frame)==105 and {x['audit_id'] for x in judgements}==set(frame)
rows=read(O/'ad_technology_union.csv')
for r in rows:
 for k in ['M','choice_or_example']:r[k]=int(r[k])
original={(r['identity_key'],r['label_code']):r for r in rows}
adj=json.loads((W/'diagnostic_adjudication.json').read_text(encoding='utf-8'))
decisions={**adj['Q_disagreements'],**adj['other_state_disagreements']}
matched=[]
for j in judgements:
 f=frame[j['audit_id']];old=original[f['identity_key'],f['label_code']]
 assert j['Q']==('P' if 'P' in (j['G'],j['R']) else 'Z' if j['G']==j['R']=='Z' else 'U')
 decision=decisions.get(j['audit_id'],{k:j[k] for k in ['G','R','Q']})
 r={k:old[k] for k in ['identity_key','reading_id','company_id','task','label_code']};r.update(audit_id=j['audit_id'],stratum=f['audit_stratum'])
 for m in ['G','R','Q']:r.update({m+'_original':old[m],m+'_fresh':j[m],m+'_agreement':int(old[m]==j[m]),m+'_adjudicated':decision[m]})
 r.update(task_support=j['task_support'],resolution=decision.get('resolution','agree'),adjudication_reason=decision.get('reason','No state disagreement; no independent proof of correctness is inferred.'),fresh_quote=j['evidence_quote'],fresh_rationale=j['rationale'])
 matched.append(r)
assert sum(x['Q_agreement'] for x in matched)==89
write('diagnostic_comparison.csv',matched)
groups=collections.defaultdict(list)
for r in matched:groups[r['task'],r['label_code']].append(r)
table=[]
for (t,l),rs in sorted(groups.items()):
 x={'task':t,'label_code':l,'sample_pairs':len(rs),'sample_ads':len({r['identity_key'] for r in rs})}
 for m in ['G','R','Q']:x[m+'_agreements']=sum(r[m+'_agreement'] for r in rs)
 x['Q_disagreements']=len(rs)-x['Q_agreements'];x['Q_U_to_Z_clarifications']=sum(r['Q_original']=='U' and r['Q_adjudicated']=='Z' for r in rs)
 table.append(x)
write('diagnostic_summary.csv',table)
conf=collections.Counter((m,r[m+'_original'],r[m+'_fresh']) for r in matched for m in ['G','R','Q'])
write('diagnostic_confusion.csv',[dict(metric=m,original=a,fresh=b,n=n) for (m,a,b),n in sorted(conf.items())])
# Reuse only the pure aggregation functions, not the main analysis file's IO.
tree=ast.parse((W/'analyse.py').read_text(encoding='utf-8'))
ns={'collections':collections}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['summary','share','sign','transition']],type_ignores=[]),'aggregation_functions','exec'),ns)
summarize=ns['summary'];sign=ns['sign'];transition=ns['transition']
flagged={r['identity_key'] for r in matched if r['task_support']!='SUPPORTED'}
assert len(flagged)==4
bykey={(r['identity_key'],r['label_code']):r for r in matched}
allcells=sorted({(r['task'],r['label_code'],r['company_id']) for r in rows});taskcells=sorted({(r['task'],r['label_code']) for r in rows})
sfirms=[];stasks=[];spairs=[];members=[];totals=[]
for scenario in ['ORIGINAL','THREE_EXAMPLE_CLARIFICATIONS','FRESH_READING_ALTERNATIVE','TASK_BOUNDARY_RESTRICTION']:
 rs=copy.deepcopy(rows)
 for r in rs:
  k=(r['identity_key'],r['label_code']);r['included']=int(not(scenario=='TASK_BOUNDARY_RESTRICTION' and r['identity_key'] in flagged))
  r['exclusion_reason']='fresh_reader_task_boundary_flag' if not r['included'] else ''
  if k in bykey and scenario in ['THREE_EXAMPLE_CLARIFICATIONS','FRESH_READING_ALTERNATIVE']:
   suffix='_adjudicated' if scenario=='THREE_EXAMPLE_CLARIFICATIONS' else '_fresh'
   for m in ['G','R','Q']:r[m]=bykey[k][m+suffix]
  members.append(dict(scenario=scenario,**r))
 active=[r for r in rs if r['included']]
 totals.append(dict(scenario=scenario,ads=len({r['identity_key'] for r in active}),pairs=len(active),**summarize(active)))
 fs=[]
 for t,l,c in allcells:
  sub=[r for r in active if (r['task'],r['label_code'],r['company_id'])==(t,l,c)]
  s=dict(scenario=scenario,task=t,label_code=l,company_id=c,**summarize(sub));fs.append(s);sfirms.append(s)
 for t,l in taskcells:stasks.append(dict(scenario=scenario,task=t,label_code=l,**summarize([r for r in active if (r['task'],r['label_code'])==(t,l)])))
 for threshold in [5,10]:
  for t,l in taskcells:
   eligible=[r for r in fs if (r['task'],r['label_code'])==(t,l) and min(r[m+'_N'] for m in ['M','G','Q'])>=threshold]
   for a,b in itertools.combinations(eligible,2):
    mgap=a['M_share']-b['M_share'];qgap=a['Q_share']-b['Q_share']
    spairs.append(dict(scenario=scenario,threshold=threshold,task=t,label_code=l,company_a=a['company_id'],company_b=b['company_id'],M_gap_pp=100*mgap,Q_gap_pp=100*qgap,M_to_Q=transition(sign(mgap),sign(qgap)),Q_bounds_disjoint=int(a['Q_lo']>b['Q_hi'] or b['Q_lo']>a['Q_hi'])))
write('diagnostic_scenario_members.csv',members);write('diagnostic_scenario_firms.csv',sfirms);write('diagnostic_scenario_tasks.csv',stasks);write('diagnostic_scenario_pairs.csv',spairs);write('diagnostic_scenario_totals.csv',totals)
ss=[]
for scenario in [x['scenario'] for x in totals]:
 for th in [5,10]:
  ps=[p for p in spairs if p['scenario']==scenario and p['threshold']==th]
  ss.append(dict(scenario=scenario,threshold=th,pairs=len(ps),reversed=sum(p['M_to_Q']=='reversed' for p in ps),bounds_disjoint=sum(p['Q_bounds_disjoint'] for p in ps)))
write('diagnostic_scenario_summary.csv',ss)
facts={'sample_pairs':len(matched),'sample_ads':len({r['identity_key'] for r in matched}),'agreement':{m:sum(r[m+'_agreement'] for r in matched) for m in ['G','R','Q']},'Q_disagreements':16,'clarified_pairs':sum(r['Q_original']!=r['Q_adjudicated'] for r in matched),'task_flag_pairs':sum(r['task_support']!='SUPPORTED' for r in matched),'task_flag_ads':len(flagged),'scenario_totals':totals,'scenario_summary':ss,'diagnostic_not_population_accuracy':True,'prior_labels_withheld':True,'aggregate_history_exposed':True}
(O/'diagnostic_facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in facts.items() if k!='scenario_totals'},ensure_ascii=False))
