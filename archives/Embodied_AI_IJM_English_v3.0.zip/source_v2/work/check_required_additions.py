"""Record the coordinating editor's complete source check of the five R-only additions.
This targeted construct check was conducted after union calculation. It is separate
from the stratified, prior-label-withheld diagnostic and is not independent human coding.
"""
from pathlib import Path
import csv,json
E=Path(__file__).resolve().parents[1]
records=json.loads((E/'data/inputs/records.json').read_text(encoding='utf-8'))
by={r['reading_id']:r for r in records}
cases=[
 ('E0206','SK_PYTORCH','深度学习框架熟练(PyTorch 为主);能独立推进实验闭环。','硬性要求','The local required heading governs the statement; PyTorch is named as the principal framework, not merely one example.'),
 ('E0205','SK_PYTORCH','PyTorch 熟练;有仿真(Isaac / MuJoCo)或真机联调经验。','硬性要求','The disjunction concerns simulation or hardware integration after the semicolon, not PyTorch.'),
 ('N0874','SK_PYTHON','Strong Python programming skills.','Required Skills:','The direct Python bullet precedes the separate multiple-of list; that list does not govern Python.'),
 ('N0878','SK_PYTHON','Strong Python skills and deep experience with PyTorch','Required Skills','Both languages/frameworks are conjunctively specified under the required heading; the next e.g. list concerns ML tasks.'),
 ('N0878','SK_PYTORCH','Strong Python skills and deep experience with PyTorch','Required Skills','Both names are directly specified; the e.g. list in the next sentence does not govern PyTorch.'),
]
out=[]
for rid,code,quote,heading,rationale in cases:
 r=by[rid];matches=[field for field,text in r['fields'].items() if quote in text and heading in text];assert matches,(rid,quote)
 out.append(dict(identity_key=r['identity_key'],reading_id=rid,label_code=code,heading=heading,quote=quote,source_fields_json=json.dumps(matches),retained_R='P',retained_G='Z',union_Q='P',rationale=rationale,check_type='coordinating_editor_source_rereading_after_union',original_state_changed='NO'))
with (E/'analysis/required_addition_source_check.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(json.dumps({'R_only_pairs_checked':len(out),'distinct_ads':len({r['identity_key'] for r in out}),'unsupported_additions':0}))
