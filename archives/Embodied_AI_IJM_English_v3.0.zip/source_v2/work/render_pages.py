from pathlib import Path
import json
import pypdfium2 as pdfium
from pypdf import PdfReader
from PIL import Image,ImageDraw,ImageFont
E=Path(__file__).resolve().parents[1];R=E/'release';V=E/'verification/pages';V.mkdir(parents=True,exist_ok=True)
meta={}
for name in ['English_Manuscript_IJM','IJM_Main_Text','IJM_Tables','Supplementary_Material']:
    src=R/(name+'.pdf');pdf=pdfium.PdfDocument(src);out=V/name;out.mkdir(exist_ok=True)
    text='\n\n'.join(p.extract_text() or '' for p in PdfReader(src).pages)
    (E/'verification'/(name+'_pdf_text.txt')).write_text(text,encoding='utf-8')
    pages=[]
    for i in range(len(pdf)):
        img=pdf[i].render(scale=1.6).to_pil().convert('RGB');img.save(out/f'page-{i+1:02}.png');pages.append(img)
    for start in range(0,len(pages),4):
        thumbnails=[]
        for i in range(start,min(start+4,len(pages))):
            thumb=pages[i].copy();thumb.thumbnail((480,680));thumb2=Image.new('RGB',(500,720),'#cccccc');thumb2.paste(thumb,((500-thumb.width)//2,28));ImageDraw.Draw(thumb2).text((10,6),f'{name} p{i+1}',fill='black');thumbnails.append(thumb2)
        sheet=Image.new('RGB',(1000,720*((len(thumbnails)+1)//2)),'white')
        for j,img in enumerate(thumbnails):sheet.paste(img,((j%2)*500,(j//2)*720))
        sheet.save(out/f'contact-{start+1:02}.png')
    meta[name]={'pages':len(pdf),'page_image_size':pages[0].size,'pdf_bytes':src.stat().st_size}
(E/'verification/render_summary.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps(meta))
