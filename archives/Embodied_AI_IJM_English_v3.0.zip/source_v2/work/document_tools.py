from pathlib import Path
import re,json,copy,csv,shutil
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.opc.constants import RELATIONSHIP_TYPE as RT

WIDTHS={}

def make(kind):
    d=Document(); sec=d.sections[0]; sec.page_width=Cm(21.59);sec.page_height=Cm(27.94)
    sec.top_margin=sec.bottom_margin=Cm(2);sec.left_margin=sec.right_margin=Cm(2.1)
    sec.header_distance=sec.footer_distance=Cm(.85)
    for style in d.styles:
        for b in style.element.xpath('.//w:pBdr'): b.getparent().remove(b)
    for name,size in [('Normal',11),('Title',17),('Heading 1',12),('Heading 2',11),('Caption',10),('Footer',9)]:
        st=d.styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
        fonts=st.element.get_or_add_rPr().rFonts
        for attr in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:
            fonts.attrib.pop(qn('w:'+attr),None)
        fonts.set(qn('w:eastAsia'),'SimSun')
    n=d.styles['Normal'].paragraph_format;n.line_spacing=1.25 if kind!='submission' else 1.5;n.space_after=Pt(6);n.widow_control=True
    for name in ['Heading 1','Heading 2']:
        st=d.styles[name];st.font.bold=name=='Heading 1';st.font.italic=name=='Heading 2'
        st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(10);st.paragraph_format.space_after=Pt(5)
    d.styles['Caption'].font.bold=True;d.styles['Caption'].font.italic=False
    d.styles['Caption'].paragraph_format.keep_with_next=True
    d.core_properties.title=DOCUMENT_TITLE
    d.core_properties.author='';d.core_properties.last_modified_by='';d.core_properties.subject='';d.core_properties.comments=''
    lng=OxmlElement('w:lang');lng.set(qn('w:val'),'en-US');d.styles['Normal'].element.get_or_add_rPr().append(lng)
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
    return d

def runs(p,text):
    # Render markdown emphasis, literal URLs, and simple inline math with native text/subscript.
    for token in re.split(r'(\*\*.*?\*\*|\*[^*]+\*|`[^`]+`|\$[^$]+\$|https?://[^\s]+|et al\.)',text):
        if not token: continue
        if token.startswith('**'):
            p.add_run(token[2:-2]).bold=True
        elif token.startswith('*'):
            p.add_run(token[1:-1]).italic=True
        elif token.startswith('`'):
            r=p.add_run(token[1:-1]);r.font.name='Consolas';r.font.size=Pt(9)
        elif token.startswith('$'):
            val=token[1:-1].replace('\\sum','Σ').replace('\\in','∈').replace('\\','')
            for part in re.split(r'(_\{[^}]+\}|_[A-Za-z]+)',val):
                r=p.add_run(part.lstrip('_').strip('{}') if part.startswith('_') else part);r.italic=True
                if part.startswith('_'):r.font.subscript=True
        elif token.startswith('http'):
            url=token.rstrip('.,');rel=p.part.relate_to(url,RT.HYPERLINK,is_external=True)
            h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rel);r=OxmlElement('w:r');pr=OxmlElement('w:rPr');co=OxmlElement('w:color');co.set(qn('w:val'),'000000');pr.append(co);r.append(pr);t=OxmlElement('w:t');t.text=url;r.append(t);h.append(r);p._p.append(h)
        else:
            rr=p.add_run(token)
            if token=='et al.':rr.italic=True

def mr(text):
    r=OxmlElement('m:r');t=OxmlElement('m:t');t.text=text;r.append(t);return r

def sub(base,idx):
    e=OxmlElement('m:sSub');a=OxmlElement('m:e');a.append(mr(base));b=OxmlElement('m:sub');b.append(mr(idx));e.extend([a,b]);return e

def frac(top,bottom):
    f=OxmlElement('m:f');n=OxmlElement('m:num');de=OxmlElement('m:den')
    for x in top:n.append(x)
    for x in bottom:de.append(x)
    f.extend([n,de]);return f

def sigma(items):
    n=OxmlElement('m:nary');pr=OxmlElement('m:naryPr');ch=OxmlElement('m:chr');ch.set(qn('m:val'),'∑');pr.append(ch)
    hide=OxmlElement('m:supHide');hide.set(qn('m:val'),'1');pr.append(hide)
    loc=OxmlElement('m:limLoc');loc.set(qn('m:val'),'subSup');pr.append(loc)
    lo=OxmlElement('m:sub');lo.append(mr('k∈K'));up=OxmlElement('m:sup');e=OxmlElement('m:e')
    for x in items:e.append(x)
    n.extend([pr,lo,up,e]);return n

def equation(d,which):
    p=d.add_paragraph();p.paragraph_format.keep_together=True;p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(6)
    om=OxmlElement('m:oMathPara');o=OxmlElement('m:oMath')
    if which=='bounds':
        delimiter=OxmlElement('m:d');pr=OxmlElement('m:dPr')
        for tag,val in [('begChr','['),('endChr',']')]:
            c=OxmlElement('m:'+tag);c.set(qn('m:val'),val);pr.append(c)
        delimiter.append(pr);e=OxmlElement('m:e')
        for x in [frac([mr('P')],[mr('B')]),mr(',  '),frac([mr('P+U')],[mr('B')])]:e.append(x)
        delimiter.append(e);parts=[delimiter]
    else:
        parts=[sub('R','A'),mr('−'),sub('R','B'),mr(' = '),sigma([mr('('),sub('w','Ak'),mr('−'),sub('w','Bk'),mr(')'),frac([sub('r','Ak'),mr('+'),sub('r','Bk')],[mr('2')])]),mr(' + '),sigma([mr('('),sub('r','Ak'),mr('−'),sub('r','Bk'),mr(')'),frac([sub('w','Ak'),mr('+'),sub('w','Bk')],[mr('2')])])]
    for x in parts:o.append(x)
    om.append(o);p._p.append(om)

def table(d,key):
    a=A[key];p=d.add_paragraph(a['title'],'Caption')
    widths=WIDTHS.get(key,a.get('widths',[16.8/len(a['headers'])]*len(a['headers'])));widths=[w*16.8/sum(widths) for w in widths]
    t=d.add_table(rows=1,cols=len(widths));t.autofit=False
    for col,w in zip(t.columns,widths):col.width=Cm(w)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    for i,vals in enumerate([a['headers']]+a['rows']):
        row=t.rows[0] if i==0 else t.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if i==0:pr.append(OxmlElement('w:tblHeader'))
        for j,(cell,val) in enumerate(zip(row.cells,vals)):
            cell.width=Cm(widths[j]);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            p=cell.paragraphs[0];p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_before=Pt(3);p.paragraph_format.space_after=Pt(3)
            if key=='T1B':p.paragraph_format.space_before=Pt(1.5);p.paragraph_format.space_after=Pt(1.5)
            p.paragraph_format.keep_with_next=key!='S5' or i==0 or i==len(a['rows'])
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or key in ['T0','TM','S5'] else WD_ALIGN_PARAGRAPH.CENTER
            rr=p.add_run(str(val));rr.font.size=Pt(9 if len(widths)>5 or key=='T1B' else 10);rr.bold=i==0
            if i==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F0F0F0');cell._tc.get_or_add_tcPr().append(shade)
    p=d.add_paragraph('Notes: '+a['note']);p.paragraph_format.line_spacing=1.1;p.paragraph_format.space_after=Pt(9)
    for rr in p.runs:rr.font.size=Pt(9)

def figure(d,key):
    a=A[key];p=d.add_paragraph(a['title'],'Caption')
    p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.paragraph_format.space_after=Pt(3)
    pic=p.add_run().add_picture(str(R/a['path']),width=Cm(16.7));pic._inline.docPr.set('descr',a['title']+'. '+a['note'])
    p=d.add_paragraph('Notes: '+a['note']);p.paragraph_format.line_spacing=1.1
    for rr in p.runs:rr.font.size=Pt(9)

def expand_asset(k):
    a=A[k]
    if a['kind']=='figure':return a['title']+'\n\n!['+a['title']+']('+a['path']+')\n\nNotes: '+a['note']
    return a['title']+'\n\n| '+' | '.join(a['headers'])+' |\n| '+' | '.join(['---']*len(a['headers']))+' |\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in a['rows'])+'\n\nNotes: '+a['note']

def build(source,name,kind='reader'):
    d=make(kind);expanded=[];in_references=False
    for b in re.split(r'\n\s*\n',source):
        b=b.strip()
        if not b:continue
        match=re.fullmatch(r'\[\[(\w+)\]\]',b)
        if match:
            k=match[1]
            if k=='BOUNDS':
                equation(d,'bounds');expanded.append('\\[P/B, (P+U)/B\\]');continue
            a=A[k]
            if kind=='submission':
                label=LABEL[k].split(', Panel')[0]
                p=d.add_paragraph('[Insert '+label+' here]')
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            elif a['kind']=='table':table(d,k)
            else:figure(d,k)
            expanded.append(expand_asset(k) if kind!='submission' else '[Insert '+LABEL[k].split(', Panel')[0]+' here]')
        elif b.startswith('\\['):
            equation(d,'bounds' if '\\left[' in b else 'decomposition');expanded.append(b)
        elif b.startswith('# '):
            p=d.add_paragraph(b[2:],'Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;expanded.append(b)
        elif b.startswith('## '):
            d.add_paragraph(b[3:],'Heading 1');expanded.append(b)
            in_references=b[3:]=='References'
        elif b.startswith('### '):d.add_paragraph(b[4:],'Heading 2');expanded.append(b)
        elif b.startswith('- '):
            for line in b.splitlines():
                p=d.add_paragraph(style='List Bullet');runs(p,line.removeprefix('- '))
            expanded.append(b)
        else:
            p=d.add_paragraph();runs(p,b);expanded.append(b)
            if in_references:
                p.paragraph_format.left_indent=Cm(.5);p.paragraph_format.first_line_indent=Cm(-.5);p.paragraph_format.line_spacing=1.1;p.paragraph_format.keep_together=True
                for rr in p.runs:rr.font.size=Pt(10)
    d.save(R/(name+'.docx'));(R/(name+'.md')).write_text('\n\n'.join(expanded)+'\n',encoding='utf-8')
    return d
