"""Descriptive, reproducible IJM revision analysis (standard library only).
Unit: identity_key + label_code (496 distinct pairs in 248 fixed ads).
All joins are 1:1 on the declared pair key or m:1 to immutable company IDs.
No observations are removed: thresholds are comparison/display flags.
G and R come from final frozen states; Q is their ad-level union, not a sum.
The revision protocol was recorded before these new outputs were inspected.
No sampling inference, causal estimand or independent-pair assumption is used.
"""
from pathlib import Path
import csv,json,itertools,collections,hashlib
E=Path(__file__).resolve().parents[1];I=E/'data/inputs';O=E/'analysis';O.mkdir(exist_ok=True)
def read(name):
 with (I/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(name,rows):
 assert rows,name
 with (O/name).open('w',encoding='utf-8',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
def union(g,r):
 assert g in 'PZU' and r in 'PZU',(g,r)
 return 'P' if 'P' in [g,r] else 'Z' if g==r=='Z' else 'U'
def share(p,n):return p/n if n else None
def summary(rs):
 out={'B':len(rs),'M_P':sum(x['M'] for x in rs),'M_N':len(rs)}
 out['M_share']=share(out['M_P'],out['M_N'])
 for metric in ['G','R','Q']:
  ct=collections.Counter(x[metric] for x in rs)
  for s in 'PZU':out[metric+'_'+s]=ct[s]
  out[metric+'_N']=ct['P']+ct['Z'];out[metric+'_share']=share(ct['P'],ct['P']+ct['Z'])
  out[metric+'_lo']=share(ct['P'],len(rs));out[metric+'_hi']=share(ct['P']+ct['U'],len(rs))
  assert sum(ct.values())==len(rs)
 out['G_R_overlap']=sum(x['G']==x['R']=='P' for x in rs)
 out['R_only_additions']=sum(x['R']=='P' and x['G']!='P' for x in rs)
 out['Q_P_among_mentions']=sum(x['Q']=='P' and x['M']==1 for x in rs)
 out['Q_Z_among_mentions']=sum(x['Q']=='Z' and x['M']==1 for x in rs)
 out['Q_U_among_mentions']=sum(x['Q']=='U' and x['M']==1 for x in rs)
 out['Q_given_M']=share(out['Q_P_among_mentions'],out['M_P'])
 out['choice_or_example_nonQ']=sum(x['M'] and x['Q']!='P' and x['choice_or_example'] for x in rs)
 assert out['Q_P_among_mentions']==out['Q_P'],'Qualification positive with no mention'
 assert out['Q_P']==out['G_P']+out['R_P']-out['G_R_overlap']
 return out
index=read('context_index.csv');assert len(index)==496
states={}
for r in read('qualification_states.csv'):
 k=(r['identity_key'],r['label_code'],r['metric']);assert k not in states;states[k]=r['state']
assert len(states)==992
company={r['company_id']:r for r in read('company_sample.csv')};assert len(company)==24
records={r['identity_key']:r for r in json.loads((I/'records.json').read_text(encoding='utf-8'))};assert len(records)==248
allrows=[];seen=set()
for r in index:
 k=(r['identity_key'],r['label_code']);assert k not in seen;seen.add(k)
 assert r['identity_key'] in records and r['company_id'] in company
 g=states[k+('GENERAL',)];req=states[k+('REQUIRED',)];assert g==r['G_general_unconditional_state']
 x={k:r[k] for k in ['identity_key','reading_id','company_id','role','task','label_code']}
 x.update(company_name=company[r['company_id']]['company_name'],M=int(r['M_positive']),G=g,R=req,Q=union(g,req),choice_or_example=int(any(r.get(f)=='1' for f in ['has_choice','has_example','has_choice_and_example'])))
 allrows.append(x)
write('ad_technology_union.csv',allrows)
cells=collections.defaultdict(list);firmcells=collections.defaultdict(list)
for r in allrows:
 cells[r['task'],r['label_code']].append(r);firmcells[r['task'],r['label_code'],r['company_id']].append(r)
firms=[]
for (t,l,c),rs in sorted(firmcells.items()):
 v={'task':t,'label_code':l,'company_id':c,'company_name':company[c]['company_name'],**summary(rs)}
 for threshold in [5,10]:v['common_eligible_'+str(threshold)]=int(min(v[m+'_N'] for m in ['M','G','Q'])>=threshold)
 firms.append(v)
assert len(firms)==120
write('firm_technology_union.csv',firms)
aggregate=[]
for (t,l),rs in sorted(cells.items()):
 fs=[x for x in firms if x['task']==t and x['label_code']==l]
 v={'task':t,'label_code':l,'firms':len(fs),**summary(rs)}
 for m in ['M','G','Q']:
  valid=[x for x in fs if x[m+'_N']>0]
  v[m+'_firm_equal']=sum(x[m+'_share'] for x in valid)/len(valid)
 v['eligible_firms_10']=sum(x['common_eligible_10'] for x in fs)
 v['eligible_firms_5']=sum(x['common_eligible_5'] for x in fs)
 aggregate.append(v)
write('task_technology_summary.csv',aggregate)
trans=collections.Counter((r['task'],r['label_code'],r['G'],r['R'],r['Q']) for r in allrows)
write('state_transitions.csv',[dict(task=t,label_code=l,G=g,R=r,Q=q,n=n) for (t,l,g,r,q),n in sorted(trans.items())])
def sign(x):return 1 if x>1e-12 else -1 if x< -1e-12 else 0
def transition(a,b):return 'reversed' if a*b<0 else 'preserved' if a==b and a!=0 else 'tie_both' if a==b==0 else 'tie_to_order' if a==0 else 'order_to_tie'
pairs=[]
for threshold in [5,10]:
 for t,l in sorted(cells):
  fs=[x for x in firms if x['task']==t and x['label_code']==l and x['common_eligible_'+str(threshold)]]
  for a,b in itertools.combinations(fs,2):
   p=dict(threshold=threshold,task=t,label_code=l,company_a=a['company_id'],company_b=b['company_id'],A_B=a['B'],B_B=b['B'])
   for m in ['M','G','Q']:
    p[m+'_gap_pp']=100*(a[m+'_share']-b[m+'_share']);p[m+'_direction']=sign(p[m+'_gap_pp'])
    if m!='M':
     p[m+'_bounds_disjoint']=int(a[m+'_lo']>b[m+'_hi']+1e-12 or b[m+'_lo']>a[m+'_hi']+1e-12)
     p[m+'_bounds_direction']=1 if a[m+'_lo']>b[m+'_hi']+1e-12 else -1 if b[m+'_lo']>a[m+'_hi']+1e-12 else 0
   p['M_to_Q']=transition(p['M_direction'],p['Q_direction']);p['G_to_Q']=transition(p['G_direction'],p['Q_direction'])
   pairs.append(p)
write('all_eligible_firm_pairs.csv',pairs)
pair_summary=[]
for threshold in [5,10]:
 for t,l in sorted(cells):
  ps=[x for x in pairs if x['threshold']==threshold and x['task']==t and x['label_code']==l]
  v={'threshold':threshold,'task':t,'label_code':l,'eligible_firms':sum(x['common_eligible_'+str(threshold)] for x in firms if x['task']==t and x['label_code']==l),'pairs':len(ps)}
  for comp in ['M_to_Q','G_to_Q']:
   ct=collections.Counter(x[comp] for x in ps)
   for outcome in ['preserved','reversed','tie_both','tie_to_order','order_to_tie']:v[comp+'_'+outcome]=ct[outcome]
  v['Q_bounds_disjoint']=sum(x['Q_bounds_disjoint'] for x in ps)
  pair_summary.append(v)
write('firm_pair_summary.csv',pair_summary)
facts={'core_ads':len(records),'core_pairs':len(allrows),'firm_cells':len(firms),'task_summaries':aggregate,'pair_summaries':pair_summary,'total':summary(allrows),'main_pairs':sum(x['threshold']==10 for x in pairs),'lower_threshold_pairs':sum(x['threshold']==5 for x in pairs),'main_pair_outcomes':dict(collections.Counter(x['M_to_Q'] for x in pairs if x['threshold']==10)),'main_G_Q_outcomes':dict(collections.Counter(x['G_to_Q'] for x in pairs if x['threshold']==10)),'main_bounds_disjoint':sum(x['Q_bounds_disjoint'] for x in pairs if x['threshold']==10),'main_unique_firms':len({x[c] for x in pairs if x['threshold']==10 for c in ['company_a','company_b']})}
(O/'facts.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2),encoding='utf-8')
checks={'pairs_unique':len(seen),'states_joined':len(states),'ads_unique':len(records),'original_G_exact_match':496,'source_states_allowed':sorted(set(states.values())),'nonmatches':0,'all_120_firm_cells_retained':True,'union_identities_pass':True,'original_sources_modified':False}
(O/'analysis_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in facts.items() if k not in ['task_summaries','pair_summaries']},ensure_ascii=False))
