"""Recompute the retained engineering identity and verify frozen background totals."""
from pathlib import Path
import csv,json,collections
E=Path(__file__).resolve().parents[1];I=E/'data/inputs';O=E/'analysis'
def read(name):return list(csv.DictReader((I/name).open(encoding='utf-8-sig',newline='')))
rows=[r for r in read('D2_decomposition_role_parts.csv') if r['case_id']=='D_MAIN' and r['scenario']=='MAIN' and r['mode']=='FIXED_K' and r['activity']=='ACT_ENGINEERING']
assert len(rows)==4
A=sum(int(r['A_N']) for r in rows);B=sum(int(r['B_N']) for r in rows)
ap=sum(int(r['A_P']) for r in rows);bp=sum(int(r['B_P']) for r in rows)
assert (A,B,ap,bp)==(82,60,46,27)
comp=within=0
for r in rows:
 sa,sb=int(r['A_N'])/A,int(r['B_N'])/B
 ra,rb=int(r['A_P'])/int(r['A_N']),int(r['B_P'])/int(r['B_N'])
 comp+=(sa-sb)*(ra+rb)/2
 within+=(ra-rb)*(sa+sb)/2
gap=ap/A-bp/B;assert abs(gap-comp-within)<1e-12
expected=next(r for r in read('decomposition_paper_extract.csv') if r['case_id']=='D_MAIN' and r['scenario']=='MAIN' and r['activity']=='ACT_ENGINEERING')
# Compare to the frozen decomposition components, not rounded prose values.
assert abs(comp*100-19.447372681519024)<1e-10
assert abs(within*100+8.349811705909266)<1e-10
scope={r['scope']:r for r in read('R_source_scope_summary.csv')}
for code,n,ads in [('S1_ACTIVITY_COMPLETE',17,968),('S2_SOURCE_QUALITY',11,576),('S3_SOURCE_QUALITY_LENGTH200',11,557)]:
 r=scope[code];assert int(r['companies'])==n and int(r['ads'])==ads
 assert len(json.loads(r['company_ids']))==n and 'CN_GALBOT' not in json.loads(r['company_ids'])
obj=read('O4_attribution_seniority_unknown.csv')
assert sum(int(r['frame_N']) for r in obj)==84 and sum(int(r['product_unknown']) for r in obj)==81
status=collections.Counter(r['display_status'] for r in read('task_review_members.csv'))
assert sorted(status.values())==[28,56,164]
report={'local_decomposition_ads':142,'engineering_positive_Galbot_Figure':[46,27],'gap_pp':gap*100,'composition_pp':comp*100,'within_function_pp':within*100,'object_ads':84,'product_unknown':81,'source_screen_totals':'matched preserved source summary; definitions and firm eligibility unchanged','core_model_review_strata':dict(status),'failures':0}
(O/'background_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
