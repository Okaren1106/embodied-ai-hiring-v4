"""Deterministic stratified diagnostic sample; frame never altered.
No original states, rationales, identities, or selection strata enter reader packet.
"""
from pathlib import Path
import json,csv,hashlib,collections
E=Path(__file__).resolve().parents[1];I=E/'data/inputs';W=E/'work'
B=E/'blind_review';B.mkdir(exist_ok=True)
rows=list(csv.DictReader((I/'context_index.csv').open(encoding='utf-8-sig',newline='')))
records={x['identity_key']:x for x in json.loads((I/'records.json').read_text(encoding='utf-8'))}
catalog={x['code']:x for x in json.loads((I/'catalog.json').read_text(encoding='utf-8'))['labels']}
groups=collections.defaultdict(list)
def h(r):return hashlib.sha256(('20260921|'+r['identity_key']+'|'+r['label_code']).encode()).hexdigest()
for r in rows:
 r['audit_stratum']=r['G_general_unconditional_state'] if r['G_general_unconditional_state'] in ['P','U'] else 'Z_MENTION' if r['M_positive']=='1' else 'NO_MENTION'
 groups[r['task'],r['label_code'],r['audit_stratum']].append(r)
selected=[]
for key,rs in sorted(groups.items()):
 selected.extend(sorted(rs,key=h)[:5])
selected.sort(key=h)
packet=[];keys={}
company_names={r['company'] for r in records.values()}
for n,r in enumerate(selected,1):
 aid=f'A{n:03d}';keys[r['identity_key'],r['label_code']]=aid
 rec=records[r['identity_key']]
 fields={}
 for field,text in rec['fields'].items():
  if text in fields.values():continue
  for company in sorted(company_names,key=len,reverse=True):
   if len(company)>3:text=text.replace(company,'[employer]')
  fields[field]=text
 packet.append({'audit_id':aid,'technology_code':r['label_code'],'technology_name':catalog[r['label_code']]['name'],'task_group':r['task'],'job_title':rec['title'],'source_fields':fields})
for r in rows:r['audit_id']=keys.get((r['identity_key'],r['label_code']),'');r['audit_selected']=int(bool(r['audit_id']))
with (W/'diagnostic_sampling_frame.csv').open('w',encoding='utf-8',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
for start in range(0,len(packet),15):
 (B/f'packet_{start//15+1:02d}.json').write_text(json.dumps(packet[start:start+15],ensure_ascii=False,indent=2),encoding='utf-8')
(B/'packet.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'seed':20260921,'per_stratum_max':5,'frame_pairs':len(rows),'sample_pairs':len(packet),'sample_unique_ads':len({r['identity_key'] for r in selected}),'strata': [{'task':k[0],'technology':k[1],'stratum':k[2],'frame_n':len(v),'sample_n':min(5,len(v))} for k,v in sorted(groups.items())],'packet_sha256':hashlib.sha256((B/'packet.json').read_bytes()).hexdigest()}
(W/'diagnostic_sample_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print({k:v for k,v in summary.items() if k!='strata'})
