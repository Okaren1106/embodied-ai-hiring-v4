# Result fact links

This ledger links the numerical statements in `results.md` to the generated v2.0 analysis outputs. It verifies transcription and declared arithmetic only; it does not provide independent semantic validation.

| Results claim | Source field or row | Check |
| --- | --- | --- |
| 248 advertisements, 496 observations, 120 firm cells | `analysis/facts.json`: `core_ads`, `core_pairs`, `firm_cells` | Direct transcription |
| Overall M=348/496; G=165; R-only=5; Q=170; Q has P/Z/U=170/277/49 and N=447 | `analysis/facts.json`: `total`; `analysis/state_transitions.csv` | 170=165+5; 496=170+277+49; 447=170+277 |
| Overall Q point 38.0%; bounds 34.3–44.2%; Q among mentions 48.9% | `analysis/facts.json`: `total.Q_share`, `Q_lo`, `Q_hi`, `Q_given_M` | Rounded from 170/447, 170/496, 219/496 and 170/348 |
| Five required-only additions: Python +2 and PyTorch +3, with no G/R overlap | `analysis/task_technology_summary.csv`: `R_only_additions`, `G_R_overlap`; `analysis/required_addition_source_check.csv` | All five rows source-read; `original_state_changed=NO` |
| Six task-level M, G, Q counts, bounds, within-mention composition and choice/example counts | `analysis/task_technology_summary.csv`, one row per task–technology combination | Direct transcription and percentage rounding |
| Figure 1 composition: Q-positive, Q-nonpositive and Q-unresolved among mentions | `analysis/task_technology_summary.csv`: `Q_P_among_mentions`, `Q_Z_among_mentions`, `Q_U_among_mentions` | Segment counts sum to M_P for every row |
| 22+22+20+20+18+18=120 cells; 117 point estimates and three all-unknown C++ cells | `analysis/task_technology_summary.csv`: `firms`; `analysis/figure_coverage.json` | Firm counts sum to 120; `shown=117`; three IDs listed in `undefined_Q` |
| Threshold 10: three pairs, two firms, M→Q 2 preserved/1 reversed, G→Q all preserved, two disjoint Q bounds | `analysis/facts.json`: `main_pairs`, `main_unique_firms`, `main_pair_outcomes`, `main_G_Q_outcomes`, `main_bounds_disjoint`; threshold-10 rows in `analysis/all_eligible_firm_pairs.csv` | Exact enumeration |
| Threshold 5: 32 pairs, M→Q 24 preserved/8 reversed, G→Q all 32 preserved, 27 disjoint Q bounds | Threshold-5 rows in `analysis/firm_pair_summary.csv` | Sums across six rows: pairs 32; reversals 8; disjoint 27 |
| Threshold-5 reversal breakdown: Python 3/6, PyTorch 2/6, C++ 2/3, Linux 1/15; two board comparisons preserved | `analysis/firm_pair_summary.csv`, threshold 5 | Direct row values |
| Galbot–XSquare Python counts, point values and bounds | `analysis/firm_technology_union.csv`: `ROBOT_MODEL/SK_PYTHON` rows for `CN_GALBOT`, `CN_XSQUARE`; corresponding threshold-10 row in `analysis/all_eligible_firm_pairs.csv` | M gap 30.1587 pp; Q gap 53.5714 pp; bounds disjoint |
| Galbot–XSquare PyTorch counts, two XSquare R-only additions, G bounds disjoint but Q bounds overlapping | `analysis/firm_technology_union.csv`: `ROBOT_MODEL/SK_PYTORCH` rows; threshold-10 pair row | G bounds: 22.2–38.9 vs 14.3; Q bounds: 22.2–38.9 vs 23.8; M→Q reversed; G→Q preserved |
| Galbot–XSquare Linux counts and bounds | `analysis/firm_technology_union.csv`: `ROBOT_RUNTIME/SK_LINUX` rows; threshold-10 pair row | M gap 23.75 pp; Q gap 33.3333 pp; Q bounds disjoint |
| Original G reproduced, all 120 cells retained, union identities passed | `analysis/analysis_checks.json` | `original_G_exact_match=496`; `all_120_firm_cells_retained=true`; `union_identities_pass=true` |
| Diagnostic frame and raw state matches: 105 pairs/94 advertisements; G 88, R 100, Q 89; 16 Q differences | `analysis/diagnostic_facts.json`; six rows of `analysis/diagnostic_summary.csv` | Sample rows sum to 105; Q differences sum to 16. Counts are not treated as accuracy or agreement rates |
| Review disposition: three PyTorch U→Z clarifications, three protocol-inconsistent scope readings, ten contested list/slash readings | `work/diagnostic_adjudication.json`: `Q_disagreements`; `analysis/diagnostic_facts.json`: `clarified_pairs` | 3+3+10=16; primary states remain frozen; fresh states enter only the alternative scenario |
| Five R differences from generic *Requirements* headings and one G difference from a *Required* statement; Q unchanged | `work/diagnostic_adjudication.json`: `other_state_disagreements` | A013/A029/A092/A095/A102 affect R reading; A073 affects G reading; all retain the same Q |
| Three-clarification scenario: threshold-5 remains 8/32 reversals; threshold-10 remains 1/3; PyTorch Q gap +1.1905 pp and bounds overlap | `analysis/diagnostic_scenario_summary.csv`; `analysis/diagnostic_scenario_pairs.csv`; `analysis/diagnostic_scenario_firms.csv` | Compare `THREE_EXAMPLE_CLARIFICATIONS` with `ORIGINAL` |
| All-16 alternative: threshold-5 reversals 7/32; threshold-10 reversals 0/3; PyTorch Q gap −0.2801 pp and bounds overlap; Python/Linux bounds remain disjoint | Same three diagnostic scenario CSVs, `FRESH_READING_ALTERNATIVE` rows | Alternative states do not overwrite primary records |
| Task-boundary restriction: remove four advertisements/five pairs, retain 244 advertisements/488 pairs and original pair-direction counts | `analysis/diagnostic_facts.json`: `task_flag_pairs`, `task_flag_ads`, scenario totals and summary; `diagnostic_scenario_*.csv` | Threshold-5 remains 8 reversals; threshold-10 remains 1 |

The diagnostic comparisons are bounded sensitivity evidence. No match count is reported as accuracy, human agreement or a population error rate, and no scenario overwrites the frozen primary \(Q\) results.
