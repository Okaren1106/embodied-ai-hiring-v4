# From Technology Mentions to Direct Qualifications in Embodied AI Recruitment

**Purpose:** This paper asks how firm comparisons within the same embodied artificial intelligence task change when a named technology's presence is separated from its direct specification as a candidate qualification.

**Design/methodology/approach:** The study uses a purposive corpus of 1,654 public job advertisements from 24 entities. Its analytical core contains 248 advertisements, six task–technology combinations and 496 advertisement–technology observations. A heading-inclusive union of unconditional general and required statements records direct qualification expressions. The analysis retains unresolved cases, enumerates all firm cells and compares eligible firms under rules fixed in the revision protocol. A bounded fresh reading examines source-level ambiguity.

**Findings:** Direct-expression rates vary sharply by technology: Linux is directly specified in 47 of 52 mentions, compared with 23 of 83 for PyTorch. The Python and Linux assignment bounds remain non-overlapping across alternative readings, while the small PyTorch point ordering changes and its bounds overlap. The diagnostic identifies material ambiguity in slash, list and example constructions; it is not an independent accuracy assessment.

**Originality:** The paper connects established relational job-advertisement coding to fixed task denominators and complete eligible firm comparisons. It shows how named-technology context can alter descriptive conclusions about publicly articulated qualifications without treating advertisements as realized labor demand.

**Keywords:** job advertisements; technology qualifications; skill requirements; firm heterogeneity; embodied artificial intelligence; recruitment

**Article classification:** Research paper
