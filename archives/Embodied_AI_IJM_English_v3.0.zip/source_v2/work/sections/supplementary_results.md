# Supplementary results and offline result files

## Diagnostic scenarios

The result files preserve four scenarios without replacing the primary states. **ORIGINAL** is the frozen primary analysis: 248 advertisements, 496 advertisement–technology observations and \(Q\) states of 170 positive, 277 nonpositive and 49 unresolved, giving 447 observations in the point-estimate denominator. **THREE_EXAMPLE_CLARIFICATIONS** resolves three PyTorch cases from unresolved to nonpositive because the complete phrases place PyTorch inside example lists. The positive count remains 170, while the nonpositive count rises to 280 and unresolved count falls to 46. **FRESH_READING_ALTERNATIVE** replaces all 16 disputed \(Q\) states with the frozen fresh-reader judgments, including contested or protocol-inconsistent interpretations. It produces 180 positive, 277 nonpositive and 39 unresolved observations. This is an alternative reading, not a corrected dataset. **TASK_BOUNDARY_RESTRICTION** excludes the four advertisements represented by five diagnostic task flags. It contains 244 advertisements and 488 advertisement–technology observations, with 169 positive, 271 nonpositive and 48 unresolved \(Q\) states.

The PyTorch comparison shows why the scenarios remain separate. Under ORIGINAL, the Galbot-minus-XSquare direct-expression point gap is +2.86 percentage points even though the mention ordering runs in the opposite direction; the firms' assignment intervals overlap. The three example clarifications narrow this point gap to +1.19 points without changing the ordering or interval overlap. Under FRESH_READING_ALTERNATIVE, the gap becomes −0.28 points, placing XSquare slightly higher, while the intervals still overlap. The primary threshold-ten mention-to-\(Q\) reversal therefore disappears in that alternative. At the threshold of five, the number of reversals declines from eight of 32 to seven. The Python and Linux threshold-ten comparisons retain non-overlapping \(Q\) bounds. TASK_BOUNDARY_RESTRICTION leaves the original pair-direction counts unchanged. These scenarios locate the result that depends on reading: the sign of a small PyTorch point gap. They do not convert the diagnostic into an accuracy estimate or establish universal validity.

## Source examples

Four excerpts show how headings and local relations enter the states. They are bounded illustrations; each decision used the complete available source.

- **E0205:** under “硬性要求” [mandatory requirements], “PyTorch 熟练;有仿真(Isaac / MuJoCo)或真机联调经验。” [translation: “Proficient in PyTorch; experience with simulation (Isaac/MuJoCo) or physical-robot integration.”] The later choice does not govern PyTorch, so \(R\) and \(Q\) are positive.
- **N0878:** under *Required Skills*, the English source states exactly, “Strong Python skills and deep experience with PyTorch”. Both names enter \(R\) and \(Q\); the required heading does not also make them \(G\) positives.
- **N0158:** “有使用PyTorch/TensorFlow、Isaac Gym/Mujoco等工具进行机器人控制相关算法开发的经验。” [translation: “Experience using tools such as PyTorch/TensorFlow and Isaac Gym/MuJoCo to develop robot-control algorithms.”] The example scope supports the PyTorch \(U\)-to-\(Z\) clarification.
- **N0149:** “熟练使用PyTorch/TensorFlow” [translation: “Proficient in using PyTorch/TensorFlow.”] The slash supplies no explicit conjunction, choice or example marker. The primary state therefore remains unresolved, while the fresh nonpositive reading is retained only in the alternative scenario.

## Firm cells and pair enumeration

The primary firm file, `analysis/firm_technology_union.csv`, contains all 120 firm–task–technology cells: 44 for the two technologies in robot learning and model development, 40 for the two robot-runtime technologies and 36 for the two board-circuitry indicators. Each row supplies the advertisement base, \(M\), \(G\), \(R\) and \(Q\) positive/nonpositive/unresolved counts, point denominators, bounds, within-mention composition and eligibility flags. Zero positives are retained. Three C++ cells have no evaluable \(Q\) point denominator and should be read from their 0–100 per cent bounds.

`analysis/all_eligible_firm_pairs.csv` is the exhaustive primary comparison file. It has 35 threshold-specific rows: three at the threshold of ten and 32 at the threshold of five. These are not 35 independent firm pairs. The three threshold-ten contrasts also satisfy the threshold-five rule, multiple technologies reuse the same firms, and pair rows share advertisements. Users should filter `threshold`, then `task` and `label_code`, before reading `M_gap_pp`, `Q_gap_pp`, `M_to_Q` and the bound-overlap fields. `analysis/firm_pair_summary.csv` aggregates those rows by threshold and task–technology combination; it should not be used to infer sampling uncertainty.

The diagnostic scenario files provide the same navigation without overwriting the primary data:

- `diagnostic_scenario_summary.csv` gives pair counts, reversals and disjoint-bound counts by scenario and threshold.
- `diagnostic_scenario_pairs.csv` lists every scenario-specific eligible pair and its mention and \(Q\) gaps.
- `diagnostic_scenario_firms.csv` supplies the underlying firm-level \(P/Z/U\), denominator and bound fields.
- `diagnostic_scenario_tasks.csv` and `diagnostic_scenario_totals.csv` provide task-level and overall aggregates.
- `diagnostic_scenario_members.csv` records advertisement membership and states, while `diagnostic_comparison.csv` links the 105 diagnostic pairs to their frozen fresh readings and task-support flags.

A reproducible offline check should begin with `diagnostic_scenario_summary.csv`, select one scenario and threshold in `diagnostic_scenario_pairs.csv`, and then recover each endpoint from `diagnostic_scenario_firms.csv` using `scenario + task + label_code + company_id`. Point values use \(P/(P+Z)\); assignment bounds use \(P/(P+Z+U)\) and \((P+U)/(P+Z+U)\). Comparisons across scenarios should hold the pair key fixed. The files expose recorded uncertainty; they do not supply confidence intervals or independent observations.

## Engineering-activity decomposition as background

The earlier Galbot–Figure engineering-activity decomposition is retained only as a supplementary example of composition. Its fixed four-function comparison contains 82 Galbot records and 60 Figure records. Galbot's pooled engineering-activity rate exceeds Figure's by 11.10 percentage points, decomposed arithmetically as \(+19.45-8.35\): a positive function-composition component and a negative within-function component. The identity describes these advertisements and does not estimate a firm effect.

The local source audit and the R1/R2/R3 screens answer different questions. `work/provenance/D2_record_evaluability.csv` and its summary inspect the 142 records that actually enter the four-function comparison. All have captured text bodies and evaluable activity status, so the local 82/60 denominator is recoverable. This check concerns source availability and denominator consistency, not independent semantic recoding.

R1, R2 and R3 instead apply successively to entire recruitment boards. R1 retains only firms for which every advertisement has evaluable activity status; R2 adds an official source rated GOOD or EXCELLENT and no source-insufficient primary-function record; R3 further retains descriptions of at least 200 characters. They retain 17 firms/968 advertisements, 11/576 and 11/557, respectively. Galbot fails the whole-board condition in each screen, so the Galbot–Figure decomposition is unavailable there even though all 82 Galbot records inside the local four-function comparison are evaluable. The resulting missing values are a consequence of the broader firm-screen rule, not evidence that the 142 local records disappeared or failed their local source check.
