"""Paper figures from fixed task/technology outputs; no statistical inference.
Figure1 shows the context of recorded mentions. Figure2 retains every firm cell.
Colors: blue direct expression, gray no recorded direct expression, hatch unknown.
Figures use vector PDF/SVG and 400 dpi PNG; no source or analysis is modified.
"""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
E=Path(__file__).resolve().parents[1]; O=E/'analysis'; R=E/'release';F=R/'figures';F.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','axes.labelsize':9})
def read(n):
 with (O/n).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
order=[('ROBOT_MODEL','SK_PYTHON'),('ROBOT_MODEL','SK_PYTORCH'),('ROBOT_RUNTIME','SK_CPP'),('ROBOT_RUNTIME','SK_LINUX'),('BOARD_CIRCUIT','SK_ALTIUM'),('BOARD_CIRCUIT','V2_EMC_SIPI')]
names=['Robot learning — Python','Robot learning — PyTorch','Robot runtime — C++','Robot runtime — Linux','Board circuitry — Altium','Board circuitry — EMC/SI/PI']
title=['Robot learning\nPython','Robot learning\nPyTorch','Robot runtime\nC++','Robot runtime\nLinux','Board circuitry\nAltium','Board circuitry\nEMC/SI/PI']
agg={(r['task'],r['label_code']):r for r in read('task_technology_summary.csv')}
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(F/(name+'.'+ext),dpi=400,bbox_inches='tight',facecolor='white')
 plt.close(fig)
fig,ax=plt.subplots(figsize=(7.0,3.9));y=np.arange(6)
base=np.zeros(6)
for fld,label,color,hatch in [('Q_P_among_mentions','Direct qualification expression','#0072B2',None),('Q_Z_among_mentions','No direct expression recorded','#B8B8B8',None),('Q_U_among_mentions','Unresolved','#FFFFFF','////')]:
 vals=np.array([100*int(agg[k][fld])/int(agg[k]['M_P']) for k in order]);counts=[int(agg[k][fld]) for k in order]
 bars=ax.barh(y,vals,left=base,height=.64,label=label,color=color,edgecolor='#444444',linewidth=.4,hatch=hatch)
 for b,v,n in zip(bars,vals,counts):
  if v>=1.5:ax.text(b.get_x()+v/2,b.get_y()+b.get_height()/2,str(n),ha='center',va='center',fontsize=9 if v>=5 else 8,color='white' if fld=='Q_P_among_mentions' else 'black',bbox=dict(facecolor='white',edgecolor='none',pad=.3) if v<5 else None)
 base+=vals
ax.set_yticks(y,names);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Share of advertisements mentioning the technology (%)')
ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False);ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
ax.legend(loc='lower center',bbox_to_anchor=(.35,1.05),ncol=1,frameon=False,fontsize=8.5)
fig.tight_layout();save(fig,'Figure_1')
rows=read('firm_technology_union.csv');fig,axes=plt.subplots(2,3,figsize=(7.1,5.5),sharex=True,sharey=True)
shown=0;missing=[]
for ax,key,ttl in zip(axes.flat,order,title):
 ax.plot([0,100],[0,100],color='#9B9B9B',lw=.7,ls='--',zorder=0)
 for r in [r for r in rows if (r['task'],r['label_code'])==key]:
  if not r['Q_share']:
   missing.append(r['company_id']+'|'+key[1])
   ax.vlines(100*float(r['M_share']),0,100,color='#ADADAD',linewidth=.8,linestyles='dotted',zorder=1)
   continue
  n=min(int(r[k+'_N']) for k in ['M','G','Q']);x=100*float(r['M_share']);v=100*float(r['Q_share']);lo=100*float(r['Q_lo']);hi=100*float(r['Q_hi']);shown+=1
  color='#0072B2' if n>=10 else '#5A5A5A' if n>=5 else '#ADADAD'
  ax.vlines(x,lo,hi,color=color,linewidth=.8,alpha=.6,zorder=1)
  ax.scatter([x],[v],s=26 if n>=10 else 22 if n>=5 else 15,marker='o' if n>=5 else '^',facecolors=color if n>=10 else 'none',edgecolors=color,linewidths=.8,zorder=3)
  if r['company_id'] in ['CN_GALBOT','CN_XSQUARE'] and key[0]!='BOARD_CIRCUIT':
   label='G' if r['company_id']=='CN_GALBOT' else 'X'
   offset=(4,4 if label=='G' else -10)
   if label=='G' and key[1]=='SK_PYTORCH':offset=(5,-11)
   if label=='G' and key[1]=='SK_LINUX':offset=(-12,-10)
   ax.annotate(label,(x,v),xytext=offset,textcoords='offset points',fontsize=7.5,fontweight='bold')
 ax.set_title(ttl,fontsize=9);ax.set_xlim(-4,106);ax.set_ylim(-4,106);ax.set_xticks([0,50,100]);ax.set_yticks([0,50,100]);ax.grid(alpha=.12);ax.tick_params(labelsize=8)
fig.supxlabel('Technology mentions among task advertisements (%)',fontsize=9,y=.065)
fig.supylabel('Direct qualification expressions among evaluable task advertisements (%)',fontsize=9,x=.008)
handles=[Line2D([0],[0],marker='o',color='none',markerfacecolor='#0072B2',markeredgecolor='#0072B2',label='N ≥ 10'),Line2D([0],[0],marker='o',color='none',markerfacecolor='none',markeredgecolor='#5A5A5A',label='5 ≤ N < 10'),Line2D([0],[0],marker='^',color='none',markerfacecolor='none',markeredgecolor='#ADADAD',label='N < 5')]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.54,-.005),ncol=3,frameon=False,fontsize=8)
fig.tight_layout(rect=(.03,.10,1,1));save(fig,'Figure_2')
meta={'Figure_1':{'path':'figures/Figure_1.png','title':'Qualification context among technology mentions','note':'Bars partition the advertisements mentioning each technology into direct qualification expressions (Q positive), no such expression recorded, and unresolved context. Segment labels are advertisement counts. Q combines GENERAL and REQUIRED unconditional positives at the advertisement level. Absence of Q does not imply absence of demand.'},'Figure_2':{'path':'figures/Figure_2.png','title':'Technology mentions and direct qualification expressions across firms','note':f'The 120 firm–task–technology cells include {shown} point estimates; three C++ cells (Galaxea, Noetix and Figure) have no evaluable Q and appear as dotted full-range bounds only. Coincident marks can overlap. N is the smallest evaluable denominator across M, G and Q. Vertical lines are assignments of recorded unknowns, not confidence intervals; the dashed diagonal marks equal percentages. G labels Galbot and X labels XSquare. Small cells remain visible and are separately flagged.'}}
(F/'assets.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
(O/'figure_coverage.json').write_text(json.dumps({'total_cells':len(rows),'shown':shown,'undefined_Q':missing},indent=2),encoding='utf-8')
print(json.dumps({'figure_1_rows':6,'figure_2_cells':shown,'undefined_Q':missing}))
