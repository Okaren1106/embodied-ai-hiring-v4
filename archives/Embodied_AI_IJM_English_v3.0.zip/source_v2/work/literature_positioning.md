# Literature positioning for the IJM revision

Source audit completed 21 September 2026. This note is limited to the four named *International Journal of Manpower* articles and the contribution they can support. It does not supply findings for the revised analysis.

## Central positioning

The revised paper should be organized around one question: **When firms recruit for the same task, does a named technology appear anywhere in the advertisement, or is it directly stated as a candidate qualification?** These are different properties of recruitment text. A technology can be mentioned in duties, examples, alternatives or background description without being directly specified in a qualification statement.

For drafting, `M` is the recorded technology mention and `Q` is the heading-inclusive union of direct `GENERAL` and `REQUIRED` qualification expressions, with choice, example and unresolved relations handled by the frozen rules. `Q` should be described in ordinary prose before the notation is introduced. It is evidence about what an employer publicly articulates in an advertisement. It is not demonstrated worker competence, a legally binding hiring criterion, a count of hires or realized labor demand.

The task restriction is what makes the firm comparison interpretable. Function composition and work-object coding should establish comparability, identify remaining differences in job content and explain why an unrestricted firm-wide technology rate can mislead. They should not be presented as two additional headline contributions. The empirical extension can then enumerate eligible firm pairs within each task–technology cell and show whether comparisons are preserved, reversed or tied when the measure changes from mention to direct qualification expression. The paper's advance is to make an established relational distinction the basis of systematic within-task comparisons of specific named technologies. It is not the invention of a general job-advertisement ontology or a new extraction algorithm.

## What the four IJM articles support

### Bonesso, Gerli and Bruni (2022)

**Access checked:** complete publisher HTML, not merely an abstract.

The article studies 24 Italian analytics professionals (11 data scientists and 13 data analysts) through behavioral event interviews. The authors collected 120 episodes, classified the two roles, and coded the narratives using a 33-competency codebook. Their explicit methodological aim is to observe competencies manifested in work episodes rather than rely on self-assessment or employers' expected skill sets in advertisements. In their sample, data scientists more frequently demonstrated several emotional, social and cognitive competencies than data analysts, with the reported thresholds varying by competency.

**Use in the revision:** this paper establishes that closely related technical roles can differ in their competency profiles and, more importantly, that advertised expectations and competencies enacted at work are distinct evidence. The present paper complements that work by measuring firms' public recruitment statements for comparable tasks. It should not cite Bonesso et al. as validation that job-ad requirements are actual worker competencies or effective performance.

### Hennecke and Knabe (2026)

**Access checked:** complete open-access publisher HTML.

The article links the American Time Use Survey to O*NET and constructs occupation-level teleworkability from task and work-context items. Its focal distinction is between the structural potential to perform a job remotely and realized remote-work episodes. The authors also compare the index with observed remote-work shares and retain explicit endogeneity and causal-identification limitations.

**Use in the revision:** this is a nearby IJM precedent for treating two adjacent measures as different constructs when substituting one for the other can change interpretation. The analogy should remain narrow. In the present paper, the adjacent measures are a technology's appearance in an advertisement and its direct specification in a qualification expression. Hennecke and Knabe do not provide a theory of vacancy wording and should not be used as if they did.

### Colombo and Marcato (2023)

**Access checked:** complete publisher PDF, not merely an abstract or repository record.

The article studies Italian online job advertisements and links detailed skill measures to local labor-market concentration. Although the abstract describes a data source covering 2013–2018, the methods state that the internally consistent estimation sample uses 2015–2018 and contains 553,132 vacancies. The authors identify more than 250 specific skills, group them into broader categories, and construct both a vacancy-level binary measure and a within-occupation term frequency–inverse document frequency measure. Their analysis relates skill demand, education and experience requirements to concentration and interprets the pattern through employer-provided training.

**Use in the revision:** this is the closest substantive IJM paper. It demonstrates how vacancy-derived skill measures can address a labor-market question and how occupation and market denominators structure interpretation. The revised paper advances a different measurement margin: before a named technology is aggregated as a skill requirement, it asks what relation the advertisement asserts around that name. This does not invalidate Colombo and Marcato's taxonomy or estimates. It identifies a finer semantic problem that becomes material in within-task comparisons of specific technologies. The comparison with their method is an inference from the full text: their empirical measures operate on extracted skills and skill categories, whereas the revised paper makes the local relation around each target technology part of the measured state.

### Chala et al. (2018)

**Access checked:** complete institutional abstract and metadata; no accessible article full text was found. TU Wien's record explicitly reports `no Fulltext`, and publisher full text was not accessible in this audit. Claims below are therefore abstract-level only.

The abstract proposes an automatic bidirectional matching framework that measures semantic similarity between job-seeker qualifications and skills and employer vacancies. It describes combining WageIndicator survey data, ISCO and ESCO occupational information, open vacancy sources and social-network profiles, using machine-learning techniques to enrich profiles and match in both directions. It also acknowledges limited job-seeker data and the resulting limits on recommendation quality and maturity.

**Use in the revision:** the article shows that semantic structure in recruitment text can be used for a practical recruitment problem. The revised paper has a different objective: interpretable measurement of the relation around a predefined technology name, followed by descriptive firm comparison within a predefined task. It should not claim to improve candidate–vacancy matching, and no details beyond the abstract should be attributed to Chala et al.

## Compact literature bridge for the Introduction

IJM research already treats skill measurement as central to labor-market and recruitment questions. Colombo and Marcato (2023) extract detailed skills from Italian vacancies and relate their distribution to local labor-market concentration, while Chala et al. (2018) use semantic information from vacancies, occupational standards and job-seeker profiles in a bidirectional matching framework. Bonesso et al. (2022) show, through work-episode interviews, that related analytics roles differ in behavioral competencies, while also distinguishing competencies enacted at work from employers' expected skill sets in advertisements. These IJM studies establish the value of detailed recruitment and competency evidence, but their focal constructs are skill categories, matching or enacted behavior rather than the local semantic status of a named technology in a vacancy.

Relational job-advertisement research already represents work processes, tools, work objects, alternatives and requirement strength; its applications distinguish robots used as tools from robots treated as work objects and examine the alternative relation between PyTorch and TensorFlow (Krüger et al., 2025). Building on that contribution, the present paper asks whether relation-aware coding changes within-task comparisons across firms. A technology name may occur in duties, as one option or example, or as a direct qualification expression. Treating each occurrence as equivalent qualification evidence can therefore change the interpretation of differences between firms recruiting for the same task. The distinction also resembles the measurement discipline in Hennecke and Knabe (2026), who separate a job's teleworkability from realized remote work because the two measures answer different questions. Here, the distinction is between textual exposure to a technology and the employer's direct public specification of that technology as a candidate qualification.

The paper contributes a comparative application of relation-aware measurement. It first fixes a task denominator, then distinguishes a named technology's presence from its direct specification in a qualification expression, retaining unresolved cases rather than forcing them into either state. It then evaluates how the complete set of eligible within-task firm comparisons changes between these measures. Function and work-object coding support the task restriction and diagnose residual job-content differences. The contribution is therefore a more precise account of publicly articulated technology qualifications in the eligible comparisons, not a measure of worker capability, hiring outcomes or aggregate labor demand.

## Short contribution architecture

1. **Labour and HR question.** Firms may recruit for similar tasks while articulating different technology qualifications. The paper asks how much measured firm heterogeneity depends on distinguishing a technology mention from a direct qualification expression.
2. **Comparability design.** Predefined task groups supply the denominator. Function and work-object evidence test whether advertisements grouped under the same task remain substantively comparable.
3. **Measurement contribution.** Operationalize established relational distinctions as separate states for mention, direct qualification expression and unresolved relation; document how `GENERAL` and `REQUIRED` statements form the direct-expression union without double counting.
4. **Validation role.** The bounded rereading diagnostic tests whether the recorded distinction can be applied to source text and reports disagreements and unresolved cases. It does not create a population error rate or an independent human gold standard.
5. **Empirical extension.** Enumerate all eligible within-task firm pairs under the prespecified denominator rule and report how direction and interval overlap change from mention to direct qualification expression. Named cases become illustrations within that complete comparison set.
6. **Interpretive limit.** The analysis measures public recruitment language at fixed collection dates. It does not identify causal firm strategy, effective hiring criteria, vacancies filled or competencies held by workers.

## Discussion sentences that remain safe before results are inserted

- The contrast between mention and direct qualification expression changes the construct being compared: the former records textual exposure to a technology, whereas the latter records a narrower public statement about candidate qualifications.
- Within-task restriction reduces one source of compositional variation, but it does not make advertisements identical; work-object and source-text evidence are therefore needed to interpret residual firm differences.
- The semantic distinction complements vacancy studies that aggregate extracted skills by asking what the advertisement asserts around a specific technology before that reference enters a firm-level comparison.
- Agreement between the two measures would show robustness to this distinction; disagreement would show that the wording around technologies, rather than name frequency alone, contributes to the comparison.

## Claims to avoid

- Do not call `Q` a true, actual, binding or validated skill requirement.
- Do not infer workforce strategy, training policy or organizational capability from the advertisement comparisons.
- Do not describe the rereading diagnostic as independent human coding or gold-standard validation unless the evidence changes.
- Do not imply that Bonesso et al. validate job advertisements as measures of enacted competence.
- Do not imply that Hennecke and Knabe provide a vacancy-text framework; their relevance is the disciplined separation of adjacent constructs.
- Do not claim that Colombo and Marcato confuse all mentions with requirements; state only that their published empirical measures operate on extracted skills/categories and do not analyze the local relation around the target technology.
- Do not attribute full-text methods or findings to Chala et al.; only the abstract and institutional metadata were accessible.
- Do not claim a new extraction algorithm, ontology or algorithm benchmark; the contribution is the comparative use of the recorded semantic states.
- Do not generalize beyond the firms and firm pairs that satisfy the prespecified task and evaluability rules. If the main eligibility threshold yields few comparisons, state that directly and treat the lower threshold as sensitivity evidence.
