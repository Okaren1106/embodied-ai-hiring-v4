# Verified IJM reference additions

Verification date: 21 September 2026. Reference entries use the journal's author–date style. Primary links are included for audit and can be removed from the manuscript reference list if the production style requires DOI-only links.

## Reference-ready entries

Bonesso, S., Gerli, F. and Bruni, E. (2022), “The emotional and social side of analytics professionals: an exploratory study of the behavioral profile of data scientists and data analysts”, *International Journal of Manpower*, Vol. 43 No. 9, pp. 19–41, doi: [10.1108/IJM-07-2020-0342](https://doi.org/10.1108/IJM-07-2020-0342).

Chala, S.A., Ansari, F., Fathi, M. and Tijdens, K. (2018), “Semantic matching of job seeker to vacancy: a bidirectional approach”, *International Journal of Manpower*, Vol. 39 No. 8, pp. 1047–1063, doi: [10.1108/IJM-10-2018-0331](https://doi.org/10.1108/IJM-10-2018-0331).

Colombo, E. and Marcato, A. (2023), “Skill demand and labour market concentration: evidence from Italian vacancies”, *International Journal of Manpower*, Vol. 44 No. 9, pp. 156–198, doi: [10.1108/IJM-04-2023-0181](https://doi.org/10.1108/IJM-04-2023-0181).

Hennecke, J. and Knabe, A. (2026), “Homebound happiness? Teleworkability of jobs and emotional well-being during labor and non-labor activities”, *International Journal of Manpower*, Vol. 47 No. 10, pp. 192–212, doi: [10.1108/IJM-09-2025-0721](https://doi.org/10.1108/IJM-09-2025-0721).

## Primary-source audit

### Bonesso, Gerli and Bruni (2022)

- Publisher full text: [Emerald article page](https://www.emerald.com/ijm/article/43/9/19/146610/The-emotional-and-social-side-of-analytics)
- Access depth: complete HTML, open access, CC BY 4.0.
- Metadata verified: three authors; 2022 journal year; Vol. 43 No. 9; pp. 19–41; DOI `10.1108/IJM-07-2020-0342`.
- Safe claims from full text: exploratory study of 24 Italian professionals; 11 classified as data scientists and 13 as data analysts; 120 behavioral episodes; behavioral event interviews; 33-competency codebook; role differences reported for selected emotional, social and cognitive competencies.
- Scope note: the article studies competencies manifested in narrated work episodes. It explicitly contrasts this evidence with employers' expected skill sets in job postings.

### Chala et al. (2018)

- Institutional record: [TU Wien reposiTUm](https://repositum.tuwien.at/handle/20.500.12708/144537)
- Second author institutional record: [University of Amsterdam DARE](https://dare.uva.nl/id/7d060d70-7acf-43ac-9eeb-3373b65e5ef8)
- Publisher DOI: [10.1108/IJM-10-2018-0331](https://doi.org/10.1108/IJM-10-2018-0331)
- Access depth: abstract and metadata only. TU Wien reports `item.fulltext: no Fulltext`; publisher full text was not accessible in this audit.
- Metadata verified: four authors; 2018; Vol. 39 No. 8; pp. 1047–1063; DOI `10.1108/IJM-10-2018-0331`.
- Safe abstract-level claims: proposes automatic bidirectional semantic matching of job-seeker qualifications/skills and vacancies; integrates occupational standards, survey, vacancy and social-network information; describes machine-learning use; acknowledges limited job-seeker data and limits to recommendation quality/maturity.
- Do not cite unverified implementation details, model performance or results not stated in the abstract.

### Colombo and Marcato (2023)

- Publisher issue page: [International Journal of Manpower, Vol. 44 No. 9](https://www.emerald.com/ijm/issue/44/9)
- Publisher full-text PDF: [Emerald PDF](https://www.emerald.com/ijm/article-pdf/44/9/156/977000/ijm-04-2023-0181.pdf)
- Institutional record: [Università Cattolica PubliRES](https://publires.unicatt.it/it/publications/skill-demand-and-labour-market-concentration-evidence-from-italia/)
- Access depth: complete publisher PDF, open access, CC BY 4.0.
- Metadata verified: two authors; 2023; Vol. 44 No. 9; pp. 156–198; DOI `10.1108/IJM-04-2023-0181`.
- Safe claims from full text: online-vacancy source begins in 2013, but the internally consistent analysis uses 2015–2018; final sample 553,132 vacancies; more than 250 specific skills; skill categories constructed from a fine taxonomy; both binary and within-occupation TF-IDF measures; association of local concentration with skill, education and experience requirements.
- Wording caution: the abstract says the dataset covers 2013–2018, while Section 4.1 says the analysis concentrates on 2015–2018. Use 2015–2018 when describing the estimation sample.

### Hennecke and Knabe (2026)

- Publisher full text: [Emerald article page](https://www.emerald.com/ijm/article/47/10/192/1386667/Homebound-happiness-Teleworkability-of-jobs-and)
- Earlier version for provenance only: [IZA Discussion Paper No. 17634](https://www.econstor.eu/handle/10419/314531)
- Access depth: complete publisher HTML, open access, CC BY 4.0. The IZA item is an earlier working-paper version and should not replace the journal citation.
- Metadata verified: two authors; 2026; Vol. 47 No. 10; pp. 192–212; DOI `10.1108/IJM-09-2025-0721`; publisher date 14 July 2026.
- Safe claims from full text: links ATUS well-being diaries to O*NET occupational characteristics; constructs occupation-level teleworkability from task/work-context items; distinguishes structural teleworkability from realized remote work; evaluates its association with observed remote-work shares; reports descriptive/regression associations and explicitly states remaining endogeneity limits.
- Scope note: cite this article for the importance of separating adjacent constructs, not as a theory or method for vacancy semantics.

## Citation-role map

| Manuscript role | Citation | Supported use |
|---|---|---|
| Closest vacancy skill-demand study in IJM | Colombo and Marcato (2023) | Detailed vacancy skill measures can answer a labor-market question; occupation and local-market structure matter for interpretation. |
| Semantic recruitment application in IJM | Chala et al. (2018) | Recruitment text and occupational standards can be processed semantically for job-seeker–vacancy matching; abstract-level claim only. |
| Boundary between advertisements and enacted competence | Bonesso et al. (2022) | Related analytics roles differ in behavioral competencies; work-episode evidence is distinct from employer expectations in advertisements. |
| Measurement precedent for adjacent constructs | Hennecke and Knabe (2026) | Structural teleworkability and realized remote work answer different questions; the relevance is measurement discipline rather than substantive theory transfer. |
