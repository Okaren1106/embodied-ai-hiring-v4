"""Create the article, submission text, tables and supplement from fixed results."""
from pathlib import Path
import csv,json,re
import document_tools as dt
E=Path(__file__).resolve().parents[1];W=E/'work';R=E/'release';S=W/'sections';O=E/'analysis'
R.mkdir(exist_ok=True);(R/'tables').mkdir(exist_ok=True);(R/'authoring').mkdir(exist_ok=True)
def read(name):
 return list(csv.DictReader((O/name).open(encoding='utf-8-sig',newline='')))
def i(r,k):return int(r[k])
def pct(r,k):return f"{100*float(r[k]):.1f}"
order=['SK_PYTHON','SK_PYTORCH','SK_CPP','SK_LINUX','SK_ALTIUM','V2_EMC_SIPI']
names={'SK_PYTHON':'Robot learning: Python','SK_PYTORCH':'Robot learning: PyTorch','SK_CPP':'Robot runtime: C++','SK_LINUX':'Robot runtime: Linux','SK_ALTIUM':'Board circuitry: Altium','V2_EMC_SIPI':'Board circuitry: EMC/SI/PI'}
def ordered(rows):return sorted(rows,key=lambda r:order.index(r['label_code']))
A={}
source=' Source: calculations from the captured job-advertisement corpus.'
def table(k,title,headers,rows,note,widths):
 A[k]={'kind':'table','title':title,'headers':headers,'rows':rows,'note':note+source,'widths':widths}
t=ordered(read('task_technology_summary.csv'))
table('T1','Table I. Mentions and direct named qualification expressions',
 ['Task and technology','Ads B','Mention M','General G','R','Direct Q/N','U','Q/mentions %'],
 [[names[r['label_code']],r['B'],r['M_P'],r['G_P'],r['R_P'],r['Q_P']+'/'+r['Q_N'],r['Q_U'],pct(r,'Q_given_M')] for r in t],
 'Robot learning denotes robot learning and model development. M is any mention; G and R are unconditional general and required qualification positives. Q is their advertisement-level union. N excludes unresolved states; B includes them. No G/R positive overlaps occur in these six cells. R adds five pairs in four advertisements. The final column conditions on M. B, M, G, R and U are counts on the task base; Q/N reports positives over evaluable cases and excludes U. The EMC/SI/PI family includes electromagnetic compatibility, signal integrity and power integrity. Technologies within a task share advertisements and must not be treated as independent samples.',[4.6,1,1.4,1.4,1.4,1.8,1.3,1.9])
t=ordered(read('diagnostic_summary.csv'))
table('T2','Table II. Coverage and state matches in the source-reading diagnostic',
 ['Task and technology','Pairs','G matches','R matches','Q matches','Q differs','Example clarifications'],
 [[names[r['label_code']],r['sample_pairs'],r['G_agreements'],r['R_agreements'],r['Q_agreements'],r['Q_disagreements'],r['Q_U_to_Z_clarifications']] for r in t],
 'The 105 pairs cover 94 distinct advertisements. Matches compare the frozen original state with the fresh reader output, before adjudication. Sampling used prior-state strata and is not a probability sample for estimating coding accuracy. Prior row labels were withheld, but high-level project history was visible. The reader was a model; these counts are neither human intercoder reliability nor validation against a gold standard. Three explicit examples are U-to-Z clarifications; ten Q differences remain contestable and three reflect unsupported fresh scope readings.',[4.7,1.2,1.6,1.6,1.6,1.6,2.5])
for threshold,k,panel in [(10,'T3A','A'),(5,'T3B','B')]:
 t=ordered([r for r in read('firm_pair_summary.csv') if i(r,'threshold')==threshold])
 table(k,f'Table III. Eligible firm comparisons\nPanel {panel} Minimum common denominator of {threshold}',
  ['Task and technology','Eligible firms','Pairs','M to Q reversals','G to Q reversals','Disjoint Q bounds'],
  [[names[r['label_code']],r['eligible_firms'],r['pairs'],r['M_to_Q_reversed'],r['G_to_Q_reversed'],r['Q_bounds_disjoint']] for r in t],
  'Each firm must meet the stated minimum separately for M, G and Q. All eligible unordered pairs are retained; zero pairs means fewer than two eligible firms. Pair outcomes are dependent because they share firms and advertisements. At ten, all three pairs compare Galbot and XSquare. At five, 32 pairs include those three comparisons; the panels are not separate replications. Bounds assign all recorded unknowns to each endpoint and are not confidence intervals.',[4.8,2.0,1.1,2.4,2.4,2.6])
fig=json.loads((R/'figures/assets.json').read_text(encoding='utf-8'))
for key,num in [('F1','Figure_1'),('F2','Figure_2')]:
 a=fig[num];A[key]={**a,'kind':'figure','title':num.replace('_',' ')+'. '+a['title']}
conf={(r['original'],r['fresh']):int(r['n']) for r in read('diagnostic_confusion.csv') if r['metric']=='Q'}
table('S1','Supplementary Table S1. Original and fresh Q states',
 ['Original Q state','Fresh P','Fresh Z','Fresh U','Total'],
 [[m]+[conf.get((m,n),0) for n in ['P','Z','U']]+[sum(conf.get((m,n),0) for n in ['P','Z','U'])] for m in ['P','Z','U']],
 'Rows are original states, columns are fresh states. P is positive, Z no positive recorded, and U unresolved. The diagonal sums to 89 of 105. The stratified sample deliberately includes difficult and nonpositive cases; the matrix does not estimate population accuracy.',[5,2,2,2,2])
totals={r['scenario']:r for r in read('diagnostic_scenario_totals.csv')}
scenario_names={'ORIGINAL':'Original states','THREE_EXAMPLE_CLARIFICATIONS':'Three example clarifications','FRESH_READING_ALTERNATIVE':'Fresh reading alternative','TASK_BOUNDARY_RESTRICTION':'Task boundary restriction'}
table('S2','Supplementary Table S2. Aggregate diagnostic scenarios',
 ['Scenario','Ads','Pairs','Q positive','Q evaluable','Q unknown','Q among mentions %'],
 [[scenario_names[k],r['ads'],r['pairs'],r['Q_P'],r['Q_N'],r['Q_U'],pct(r,'Q_given_M')] for k,r in totals.items()],
 'Original states remain the primary analysis. The clarification scenario changes three PyTorch U states to Z. The fresh alternative substitutes all 105 sampled G/R states before deriving Q; 16 Q states differ. It retains fresh readings even where the protocol did not support them and is a stress test, not the preferred recoding. The task restriction excludes four advertisements from both target technologies. All other original rows are unchanged.',[4.7,1,1,1.6,1.8,1.7,2.6])
t=read('diagnostic_scenario_summary.csv')
table('S3','Supplementary Table S3. Firm comparison sensitivity to source interpretation',
 ['Scenario','Threshold','Pairs','M to Q reversals','Disjoint Q bounds'],
 [[scenario_names[r['scenario']],r['threshold'],r['pairs'],r['reversed'],r['bounds_disjoint']] for r in t],
 'Threshold is the minimum evaluable denominator in M, G and Q. The same enumeration rule is reapplied in each scenario. The fresh alternative changes the small Galbot–XSquare PyTorch point ordering at ten; its bounds overlap in every scenario. The Python and Linux bounds remain separated. Rows across thresholds and scenarios overlap and are not independent observations.',[6.4,2,1.6,2.7,2.7])
t=ordered(read('task_technology_summary.csv'))
table('S4','Supplementary Table S4. Pooled and firm-equal direct-expression rates',
 ['Task and technology','Firms','Pooled Q %','Firm equal Q %','Unknown bounds %'],
 [[names[r['label_code']],r['firms'],pct(r,'Q_share'),pct(r,'Q_firm_equal'),pct(r,'Q_lo')+'–'+pct(r,'Q_hi')] for r in t],
 'Pooled Q uses Q positive/evaluable advertisements. Firm-equal Q averages valid firm shares, including zero-positive firms and excluding only zero-evaluable cells. Bounds use the pooled task base. Full record-level and all 120 firm cells, including three undefined C++ points, are supplied in the analysis CSV files.',[5.5,1.4,2.7,3.2,3.5])
table('S5','Supplementary Table S5. Selection sequence and evidential limits',
 ['Selection scope','Rule and selected set','Exclusions and unknowns','Timing and knowledge of outcomes'],[
 ['Initial company wave','Readable public job details, stable identifiers and core fields; eight firms and 610 advertisements.','No surviving exhaustive ranking of all nonselected firms.','Observed 31 August 2026; purposive, with no claim of outcome-blind selection.'],
 ['Expansion from the existing 40-company landscape','Identifiable entity, research relevance, source quality and feasible official board; 16 entities and 1,044 advertisements.','Failed sources retained; Leju lacked a verifiable current parent-company source. Unavailability is not zero hiring.','Observed 11 September, accepted 14 September 2026; priority rules preceded final source verification.'],
 ['24 accepted entities','All accepted identities retained; 23 company boards and 1,630 advertisements form the company comparison scope.','Amazon FAR is a bounded team; its 24 advertisements remain separate.','Scope follows organizational boundary rather than a numerical outcome threshold.'],
 ['Work-object cases','Case-priority firms AgiBot, Galbot, Dexterity and Nimble; ML/AI and software functions, 84 advertisements.','Other firms and functions outside this set; 81 advertisements have no named product link.','Exploratory cases; no preserved outcome-blind rule for selecting these four firms.'],
 ['Tasks and technologies','Primary-function by responsibility-defined-task intersection; 105 learning, 87 runtime and 56 circuitry advertisements, with two technologies per task.','Nonmatching tasks/functions and FAR excluded. Nonpositive and unresolved technology states retained.','Task/catalog rules preceded full coding but followed pilot inspection; not preregistered.'],
 ['Engineering illustration','Galbot and Figure; four shared functions with at least ten evaluable advertisements in both firms; 82 and 60 records.','Below-threshold functions excluded; no exhaustive rule documented for choosing the firm pair.','Earlier exploratory illustration; functions fixed across its sensitivity scenarios.'],
 ['Current comparison extension','All 120 firm cells; every unordered pair satisfying common M/G/Q denominators of ten and five.','Small and undefined cells kept in full outputs, with comparative eligibility flagged separately.','Rules recorded 21 September 2026 before new union calculations, with earlier results already known.']
 ],'This compact ledger summarizes the full selection_ledger.csv, which retains exact entity lists, source records and historical named-case selection. The study is exploratory throughout; recording a revision protocol does not make earlier selection outcome-blind.',[2.8,5.3,4.4,4.3])

def textfile(name):
 text=(S/name).read_text(encoding='utf-8').strip()
 text=re.sub(r'\\\((.*?)\\\)',lambda m:'$'+m[1]+'$',text)
 text=text.replace('X Square Robot','XSquare').replace('X Square','XSquare')
 # Preserve punctuation in prose; titles and headings use a clean outline.
 text=re.sub(r'^(#{1,3} .+)$',lambda m:re.sub(r'(?<=\d)\.(?=\s)','',m[1]).replace(',','').replace(':',''),text,flags=re.M)
 return text
parts=[textfile(f) for f in ['front.md','introduction.md','methods.md','results.md','discussion_conclusion.md']]
availability='## Data availability\n\nThe accompanying research package contains versioned analytical inputs, source excerpts and identifiers for the task sample, final states, all firm cells and comparisons, the complete diagnostic and executable reproduction scripts. The package README maps each table and figure to its inputs and computation. Captured advertisements remain third-party materials; their inclusion for verification does not imply permission for unrestricted redistribution. No public repository is asserted.'
refs=(W/'references.md').read_text(encoding='utf-8').strip()
body='\n\n'.join(parts+[availability,refs])
sm=textfile('supplementary_methods.md');sm=re.sub(r'^# .*?\n\n','',sm)
sr=textfile('supplementary_results.md');sr=re.sub(r'^# .*?\n\n','',sr)
supp='# Supplementary Material\n\n'+parts[0].splitlines()[0][2:]+'\n\n'+sm+'\n\n'+sr+'\n\n## Supplementary tables\n\n'+'\n\n'.join('[['+k+']]' for k in ['S1','S2','S3','S4','S5'])
dt.R=R;dt.A=A;dt.LABEL={k:v['title'].split('. ')[0] for k,v in A.items()};dt.LABEL['T3A']=dt.LABEL['T3B']='Table III'
dt.DOCUMENT_TITLE=parts[0].splitlines()[0][2:]
dt.build(body,'English_Manuscript_IJM')
submission=re.sub(r'\[\[T3A\]\]\s*\[\[T3B\]\]','[[T3A]]',body)
submission=submission.replace('[[T3B]]','')
submission+='\n\n## Figure captions\n\n'+'\n\n'.join(A[k]['title']+'\n\nNotes: '+A[k]['note'] for k in ['F1','F2'])
dt.build(submission,'IJM_Main_Text','submission')
dt.build(supp,'Supplementary_Material')
d=dt.make('tables');d.add_paragraph('Tables','Title')
for index,group in enumerate([['T1'],['T2'],['T3A','T3B']]):
 if index:d.add_page_break()
 for k in group:dt.table(d,k)
d.save(R/'IJM_Tables.docx')
(R/'IJM_Tables.md').write_text('\n\n'.join(dt.expand_asset(k) for k in ['T1','T2','T3A','T3B']),encoding='utf-8')
for k,a in A.items():
 if a['kind']=='table':
  with (R/'tables'/(k+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
   wr=csv.writer(f);wr.writerow(a['headers']);wr.writerows(a['rows'])
(R/'authoring/assets.json').write_text(json.dumps(A,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'authoring/manuscript_source.md').write_text(body,encoding='utf-8')
(R/'authoring/supplement_source.md').write_text(supp,encoding='utf-8')
print('Built four English DOCX documents')
