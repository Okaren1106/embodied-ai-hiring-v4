"""Independent SQL aggregation and source reconciliation of the revision outputs."""
from pathlib import Path
import sqlite3,json,csv,itertools,hashlib
E=Path(__file__).resolve().parents[1];I=E/'data/inputs';O=E/'analysis'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
db=sqlite3.connect(':memory:')
db.execute('create table state (id text, tech text, metric text, value text, primary key(id,tech,metric))')
db.executemany('insert into state values (?,?,?,?)',[(r['identity_key'],r['label_code'],r['metric'],r['state']) for r in read(I/'qualification_states.csv')])
db.execute('create table frame (id text, tech text, task text, firm text, mention int, primary key(id,tech))')
db.executemany('insert into frame values (?,?,?,?,?)',[(r['identity_key'],r['label_code'],r['task'],r['company_id'],int(r['M_positive'])) for r in read(I/'context_index.csv')])
db.execute("create view joined as select f.*,g.value g,r.value r,case when g.value='P' or r.value='P' then 'P' when g.value='Z' and r.value='Z' then 'Z' else 'U' end q from frame f join state g on f.id=g.id and f.tech=g.tech and g.metric='GENERAL' join state r on f.id=r.id and f.tech=r.tech and r.metric='REQUIRED'")
assert db.execute('select count(*) from joined').fetchone()[0]==496
expected={(r['task'],r['label_code']):r for r in read(O/'task_technology_summary.csv')}
checks=[]
for t,l,B,M,G,R,Q,U in db.execute("select task,tech,count(*),sum(mention),sum(g='P'),sum(r='P'),sum(q='P'),sum(q='U') from joined group by task,tech"):
 r=expected[t,l]
 for key,value in [('B',B),('M_P',M),('G_P',G),('R_P',R),('Q_P',Q),('Q_U',U)]:
  assert int(r[key])==value,(t,l,key);checks.append((t,l,key))
original=I/'original_firm_context.csv'
old={(r['task'],r['label_code'],r['company_id']):r for r in read(original)}
new=read(O/'firm_technology_union.csv');assert len(new)==len(old)==120
for r in new:
 s=old[r['task'],r['label_code'],r['company_id']]
 for key in ['M_P','M_N','G_P','G_N','G_U']:
  assert int(r[key])==int(s[key]),(r['company_id'],key);checks.append((r['company_id'],key))
 for m in ['G','R','Q']:
  P,Z,U,N,B=(int(r[m+'_P']),int(r[m+'_Z']),int(r[m+'_U']),int(r[m+'_N']),int(r['B']))
  assert P+Z==N and N+U==B
  if N:assert abs(float(r[m+'_share'])-P/N)<1e-12
  assert abs(float(r[m+'_lo'])-P/B)<1e-12 and abs(float(r[m+'_hi'])-(P+U)/B)<1e-12
  checks.append((r['company_id'],m,'arithmetic'))
rows=read(O/'all_eligible_firm_pairs.csv');keys=set()
for r in rows:
 key=(r['threshold'],r['task'],r['label_code'],r['company_a'],r['company_b']);assert key not in keys;keys.add(key)
for threshold in [5,10]:
 for t,l in expected:
  eligible=[r for r in new if r['task']==t and r['label_code']==l and min(int(r[m+'_N']) for m in ['M','G','Q'])>=threshold]
  actual=[r for r in rows if int(r['threshold'])==threshold and r['task']==t and r['label_code']==l]
  assert len(actual)==len(eligible)*(len(eligible)-1)//2;checks.append((threshold,t,l,'exhaustive_pairs'))
manifest=json.loads((I/'source_manifest.json').read_text(encoding='utf-8'))
for fn,meta in manifest.items():assert hashlib.sha256((I/fn).read_bytes()).hexdigest()==meta['snapshot_sha256']
report={'SQL_core_rows':496,'SQL_and_arithmetic_checks':len(checks),'old_firm_G_M_cells_matched':600,'new_firm_cells':len(new),'enumerated_pairs_both_thresholds':len(rows),'input_snapshots_verified':len(manifest),'failures':0,'interpretation':'Arithmetic and provenance verification; not semantic gold-standard validation.'}
(O/'independent_computation_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
