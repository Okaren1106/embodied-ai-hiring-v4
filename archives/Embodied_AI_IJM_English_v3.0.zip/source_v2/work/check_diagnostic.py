"""Independent checks of the sampled frame, quotations and scenario arithmetic."""
from pathlib import Path
import csv,json,hashlib,collections,itertools
E=Path(__file__).resolve().parents[1];W=E/'work';O=E/'analysis'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
frame=read(W/'diagnostic_sampling_frame.csv');sample=[r for r in frame if r['audit_id']]
assert len(frame)==496 and len(sample)==105 and len({r['identity_key'] for r in sample})==94
groups=collections.defaultdict(list)
for r in frame:groups[r['task'],r['label_code'],r['audit_stratum']].append(r)
for rs in groups.values():
 expected=sorted(rs,key=lambda r:hashlib.sha256(('20260921|'+r['identity_key']+'|'+r['label_code']).encode()).hexdigest())[:5]
 assert {r['identity_key'] for r in expected}=={r['identity_key'] for r in rs if r['audit_id']}
j=json.loads((E/'blind_review/judgements.json').read_text(encoding='utf-8'))
packet={r['audit_id']:r for r in json.loads((E/'blind_review/packet.json').read_text(encoding='utf-8'))}
assert {r['audit_id'] for r in j}==set(packet)
quotes=0
for r in j:
 assert r['Q']==('P' if 'P' in [r['G'],r['R']] else 'Z' if r['G']==r['R']=='Z' else 'U')
 quote=r['evidence_quote']
 if quote:
  # The fresh reader may give more than one verbatim quote separated by a newline.
  texts=list(packet[r['audit_id']]['source_fields'].values())
  assert quote in '\n'.join(texts) or all(x in '\n'.join(texts) for x in quote.split('\n') if x),(r['audit_id'],quote)
  quotes+=1
comparison=read(O/'diagnostic_comparison.csv')
for metric,n in [('G',88),('R',100),('Q',89)]:
 assert sum(r[metric+'_original']==r[metric+'_fresh'] for r in comparison)==n
members=read(O/'diagnostic_scenario_members.csv')
scenario_counts=collections.Counter(r['scenario'] for r in members)
assert len(scenario_counts)==4 and set(scenario_counts.values())=={496}
firms=read(O/'diagnostic_scenario_firms.csv')
assert len(firms)==480
for r in firms:
 for m in ['G','R','Q']:
  p,z,u,n,b=[int(r[x]) for x in [m+'_P',m+'_Z',m+'_U',m+'_N','B']]
  assert p+z==n and n+u==b
  if n:assert abs(float(r[m+'_share'])-p/n)<1e-12
  if b:
   assert abs(float(r[m+'_lo'])-p/b)<1e-12 and abs(float(r[m+'_hi'])-(p+u)/b)<1e-12
report={'frame_pairs':496,'diagnostic_pairs':105,'diagnostic_ads':94,'strata_checked':len(groups),'quoted_pairs_verified':quotes,'scenario_rows_retained':len(members),'scenario_firm_rows':len(firms),'failures':0,'scope':'Sampling, exact quotation and numerical checks; not independent human semantic validation.'}
(O/'independent_diagnostic_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report))
