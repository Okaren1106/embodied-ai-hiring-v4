"""Build a provenance profile for the frozen 1,654-ad corpus and 248-ad task sample.

The script prefers the packaged 1,654-row source snapshot and combines it with
the packaged task and D2 inputs. Only when the snapshot is absent does it build
one from the original accepted reference and source files. Country, location,
and source language remain separate fields.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parent
OUT = Path(__file__).resolve().parent
REFERENCE = REPO / "outputs/reference-expansion-2026-09-11/accepted-reference1654-v1-2026-09-14/reference1654.jsonl"
MEMBERSHIP = ROOT / "data/inputs/primary_members.csv"
LANDSCAPE = REPO / "data/company_landscape.csv"
D2_MEMBERSHIP = ROOT / "data/inputs/D2_K_membership.csv"
D2_ROLE_PARTS = ROOT / "data/inputs/D2_decomposition_role_parts.csv"
SOURCE_SNAPSHOT = OUT / "source_profile_input.jsonl"
SOURCE_SNAPSHOT_MANIFEST = OUT / "source_profile_input_manifest.json"
ACCEPTANCE_ID = "REFERENCE1654_USER_ACCEPTED_2026_09_14_V1"

HAN_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
LATIN_RE = re.compile(r"[A-Za-z]")
WORD_RE = re.compile(r"[A-Za-zÀ-ÿ]+")
EN_MARKERS = {
    "the", "and", "with", "experience", "you", "your", "our", "role",
    "responsibilities", "requirements", "will", "for", "to", "of", "in",
    "skills", "team", "work", "engineering", "candidate", "required",
}
ES_MARKERS = {
    "el", "la", "los", "las", "del", "eres", "serás", "años", "con", "y",
    "experiencia", "responsabilidades", "requisitos", "equipo", "trabajo",
    "ingeniería", "candidato", "habilidades", "nuestra", "nuestro", "tienes",
}
PT_MARKERS = {
    "uma", "você", "vocês", "seus", "suas", "são", "não", "como", "com",
    "dos", "das", "experiência", "responsabilidades", "requisitos", "equipe",
    "trabalho", "engenharia", "habilidades", "nossa", "nosso", "pela", "pelo",
    "será", "tem", "às",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def raw_record(reference_row: dict, cache: dict[Path, list[str]]) -> dict:
    locator = reference_row["source"]
    source_path = REPO / locator["path"]
    if source_path not in cache:
        cache[source_path] = source_path.read_text(encoding="utf-8").splitlines()
    line_number = int(locator["line"])
    lines = cache[source_path]
    assert 1 <= line_number <= len(lines), (source_path, line_number, len(lines))
    envelope = json.loads(lines[line_number - 1])
    row = envelope.get("row", envelope)
    assert row["record_id"] == reference_row["record_id"], (
        reference_row["record_id"], row.get("record_id"), source_path, line_number
    )
    return row


def source_text(row: dict) -> str:
    title = str(row.get("title") or "")
    body = str(row.get("full_description") or "")
    if not body.strip():
        body = "\n".join(str(row.get(k) or "") for k in ("duties", "requirements"))
    return f"{title}\n{body}".strip()


def classify_language(text: str) -> tuple[str, str, int, int, int]:
    """Return a conservative text-based label; do not infer from country."""
    replacement = text.count("\ufffd")
    han = len(HAN_RE.findall(text))
    latin = len(LATIN_RE.findall(text))
    letters = han + latin
    if replacement >= 3 or (text and replacement / len(text) >= 0.01):
        return "unknown_mojibake", "replacement characters prevent reliable classification", han, latin, replacement
    if letters < 40:
        return "unknown_short", "fewer than 40 Han-plus-Latin letters", han, latin, replacement
    han_share = han / letters
    if han >= 20 and han_share >= 0.20:
        return "zh", "Han count >=20 and Han share >=0.20", han, latin, replacement
    if han >= 20 and latin >= 20:
        return "mixed_zh_latin", "Han and Latin counts both >=20, with Han share <0.20", han, latin, replacement
    words = {word.lower() for word in WORD_RE.findall(text)}
    en_score = len(words & EN_MARKERS)
    es_score = len(words & ES_MARKERS)
    pt_score = len(words & PT_MARKERS)
    scores = {"en": en_score, "es": es_score, "pt": pt_score}
    winner = max(scores, key=scores.get)
    ordered = sorted(scores.values(), reverse=True)
    if scores[winner] >= 4 and scores[winner] > ordered[1]:
        return winner, f"marker scores English={en_score}, Spanish={es_score}, Portuguese={pt_score}", han, latin, replacement
    return "unknown_latin", f"insufficient language separation (English={en_score}, Spanish={es_score}, Portuguese={pt_score})", han, latin, replacement


def recorded_location(raw_value: object, reference_value: object) -> tuple[str, str, str]:
    raw_text = str(raw_value or "").strip()
    ref_text = str(reference_value or "").strip()
    chosen, origin = (raw_text, "raw_source.location") if raw_text else (ref_text, "accepted_reference.location")
    if not chosen:
        return "", "unknown_missing", origin
    if "\ufffd" in chosen:
        return "", "unknown_encoding", origin
    normalized = re.sub(r"\s+", "", chosen)
    if normalized in {"市场事业部", "市场事业部/市场类"}:
        return chosen, "non_geographic_department", origin
    return chosen, "recorded_geographic", origin


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def reference_from_snapshot(row: dict) -> dict:
    return {
        "record_id": row["record_id"],
        "packet_id": row["accepted_packet_id"],
        "company_id": row["company_id"],
        "company": row["company"],
        "country": row["accepted_country"],
        "location": row["accepted_location"],
        "title": row["accepted_title"],
        "wave": row["wave"],
        "acceptance_id": row["acceptance_id"],
        "source": {
            "path": row["source_path"],
            "line": row["source_line"],
            "source_url": row["source_url"],
            "text_version_hash": row["text_version_hash"],
            "source_equivalence_sha256": row["source_equivalence_sha256"],
        },
    }


def raw_from_snapshot(row: dict) -> dict:
    return {
        "record_id": row["record_id"],
        "title": row["raw_title"],
        "location": row["raw_location"],
        "full_description": row["raw_full_description"],
        "duties": row["raw_duties"],
        "requirements": row["raw_requirements"],
    }


def write_source_snapshot(
    references: list[dict], landscape: dict[str, dict[str, str]], raw_by_record: dict[str, dict]
) -> dict:
    rows: list[dict] = []
    for reference in references:
        raw = raw_by_record[reference["record_id"]]
        firm = landscape[reference["company_id"]]
        rows.append({
            "record_id": reference["record_id"],
            "accepted_packet_id": reference["packet_id"],
            "company_id": reference["company_id"],
            "company": reference["company"],
            "accepted_country": reference["country"],
            "firm_hq_country": firm["country"],
            "firm_hq_city": firm["headquarters"],
            "wave": reference["wave"],
            "accepted_title": str(reference.get("title") or ""),
            "accepted_location": str(reference.get("location") or ""),
            "raw_title": str(raw.get("title") or ""),
            "raw_location": str(raw.get("location") or ""),
            "raw_full_description": str(raw.get("full_description") or ""),
            "raw_duties": str(raw.get("duties") or ""),
            "raw_requirements": str(raw.get("requirements") or ""),
            "source_path": reference["source"]["path"],
            "source_line": int(reference["source"]["line"]),
            "source_url": str(reference["source"].get("source_url") or ""),
            "text_version_hash": reference["source"]["text_version_hash"],
            "source_equivalence_sha256": str(reference["source"].get("source_equivalence_sha256") or ""),
            "acceptance_id": reference["acceptance_id"],
        })
    with SOURCE_SNAPSHOT.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    source_paths = sorted({reference["source"]["path"] for reference in references})
    manifest = {
        "schema_version": 1,
        "unit": "one accepted advertisement",
        "rows": len(rows),
        "snapshot_path": SOURCE_SNAPSHOT.name,
        "snapshot_sha256": sha256(SOURCE_SNAPSHOT),
        "contents": "Minimal immutable fields needed for source language, advertisement location, headquarters, identity, core-task joins, and D2 source/evaluability profiling.",
        "generated_from": {
            "accepted_reference": {"path": str(REFERENCE.relative_to(REPO)), "sha256": sha256(REFERENCE)},
            "company_landscape": {"path": str(LANDSCAPE.relative_to(REPO)), "sha256": sha256(LANDSCAPE)},
            "raw_source_files": [
                {"path": path, "sha256": sha256(REPO / path)} for path in source_paths
            ],
        },
    }
    SOURCE_SNAPSHOT_MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return manifest


def load_source_snapshot() -> tuple[list[dict], dict[str, dict], dict[str, dict], dict]:
    rows = read_jsonl(SOURCE_SNAPSHOT)
    manifest = json.loads(SOURCE_SNAPSHOT_MANIFEST.read_text(encoding="utf-8"))
    assert len(rows) == manifest["rows"] == 1654
    assert sha256(SOURCE_SNAPSHOT) == manifest["snapshot_sha256"]
    references = [reference_from_snapshot(row) for row in rows]
    raw_by_record = {row["record_id"]: raw_from_snapshot(row) for row in rows}
    landscape: dict[str, dict] = {}
    for row in rows:
        firm = {
            "company_id": row["company_id"],
            "country": row["firm_hq_country"],
            "headquarters": row["firm_hq_city"],
        }
        if row["company_id"] in landscape:
            assert landscape[row["company_id"]] == firm
        landscape[row["company_id"]] = firm
    return references, landscape, raw_by_record, manifest


def main() -> None:
    assert SOURCE_SNAPSHOT.exists() == SOURCE_SNAPSHOT_MANIFEST.exists()
    snapshot_preexisting = SOURCE_SNAPSHOT.exists()
    if snapshot_preexisting:
        references, landscape, raw_by_record, snapshot_manifest = load_source_snapshot()
    else:
        references = read_jsonl(REFERENCE)
        landscape_rows = read_csv(LANDSCAPE)
        landscape = {row["company_id"]: row for row in landscape_rows}
        assert len(landscape) == len(landscape_rows)
        raw_by_record = {}
        snapshot_manifest = {}
    assert len(references) == 1654
    assert len({row["record_id"] for row in references}) == 1654
    reading_counts = Counter(row["packet_id"] for row in references)
    reading_collisions = {key: value for key, value in reading_counts.items() if value > 1}
    assert reading_collisions == {"P0107": 2}
    assert {row["acceptance_id"] for row in references} == {ACCEPTANCE_ID}
    assert Counter(row["country"] for row in references) == Counter({"China": 963, "US": 691})

    company_ids = {row["company_id"] for row in references}
    assert len(company_ids) == 24
    assert not (company_ids - landscape.keys()), sorted(company_ids - landscape.keys())
    country_alias = {"China": "China", "US": "United States"}
    for row in references:
        assert country_alias[row["country"]] == landscape[row["company_id"]]["country"]

    membership = read_csv(MEMBERSHIP)
    primary = [row for row in membership if row["scenario"] == "PRIMARY"]
    assert len(primary) == 248
    assert len({row["reading_id"] for row in primary}) == 248
    task_counts = Counter(row["task"] for row in primary)
    assert task_counts == Counter({"ROBOT_MODEL": 105, "ROBOT_RUNTIME": 87, "BOARD_CIRCUIT": 56})
    reference_by_record = {row["record_id"]: row for row in references}
    primary_by_record: dict[str, dict[str, str]] = {}
    reading_alias_mismatches: list[tuple[str, str, str]] = []
    for member in primary:
        parts = member["identity_key"].split("|")
        assert parts[0] == ACCEPTANCE_ID
        record_id = "|".join(parts[1:-1])
        assert record_id in reference_by_record
        reference = reference_by_record[record_id]
        if member["reading_id"] != reference["packet_id"]:
            assert member["reading_id"].startswith("E")
            assert reference["packet_id"].startswith("P")
            assert member["reading_id"][1:] == reference["packet_id"][1:]
            reading_alias_mismatches.append((record_id, member["reading_id"], reference["packet_id"]))
        assert member["company_id"] == reference["company_id"]
        assert parts[-1] == reference["source"]["text_version_hash"]
        assert record_id not in primary_by_record
        primary_by_record[record_id] = member
    assert len(primary_by_record) == 248

    cache: dict[Path, list[str]] = {}
    profile_rows: list[dict] = []
    for reference in references:
        raw = raw_by_record.get(reference["record_id"])
        if raw is None:
            raw = raw_record(reference, cache)
        raw_by_record[reference["record_id"]] = raw
        member = primary_by_record.get(reference["record_id"])
        language, language_basis, han, latin, replacement = classify_language(source_text(raw))
        location, location_status, location_origin = recorded_location(
            raw.get("location"), reference.get("location")
        )
        firm = landscape[reference["company_id"]]
        profile_rows.append({
            "record_id": reference["record_id"],
            "accepted_packet_id": reference["packet_id"],
            "company_id": reference["company_id"],
            "company": reference["company"],
            "wave": reference["wave"],
            "firm_hq_country": firm["country"],
            "firm_hq_city": firm["headquarters"],
            "ad_location": location,
            "ad_location_status": location_status,
            "ad_location_origin": location_origin,
            "ad_location_raw_source": str(raw.get("location") or ""),
            "ad_location_accepted_reference": str(reference.get("location") or ""),
            "source_language": language,
            "source_language_basis": language_basis,
            "han_character_count": han,
            "latin_letter_count": latin,
            "replacement_character_count": replacement,
            "core248": "1" if member else "0",
            "core_reading_id": member["reading_id"] if member else "",
            "core_role": member["role"] if member else "",
            "core_task": member["task"] if member else "",
            "source_path": reference["source"]["path"],
            "source_line": reference["source"]["line"],
            "acceptance_id": reference["acceptance_id"],
        })

    assert len(profile_rows) == 1654
    assert sum(row["core248"] == "1" for row in profile_rows) == 248
    if not snapshot_preexisting:
        snapshot_manifest = write_source_snapshot(references, landscape, raw_by_record)
    assert snapshot_manifest["rows"] == 1654
    assert sha256(SOURCE_SNAPSHOT) == snapshot_manifest["snapshot_sha256"]

    fields = list(profile_rows[0])
    write_csv(OUT / "profile_records.csv", profile_rows, fields)

    # Local source/evaluability audit for the D_MAIN Galbot-Figure decomposition.
    # This is deliberately separate from whole-board R1/R2/R3 rules.
    d2_members = [row for row in read_csv(D2_MEMBERSHIP) if row["case_id"] == "D_MAIN"]
    assert len(d2_members) == 142
    assert Counter(row["company_id"] for row in d2_members) == Counter({"CN_GALBOT": 82, "US_FIGURE": 60})
    assert len({row["identity_key"] for row in d2_members}) == 142
    d2_parts = [
        row for row in read_csv(D2_ROLE_PARTS)
        if row["case_id"] == "D_MAIN" and row["scenario"] == "MAIN" and row["mode"] == "FIXED_K"
    ]
    assert len(d2_parts) == 32
    activities = sorted({row["activity"] for row in d2_parts})
    assert len(activities) == 8
    d2_member_counts = Counter((row["company_id"], row["role"]) for row in d2_members)
    activity_n: dict[tuple[str, str, str], int] = {}
    activity_p: dict[tuple[str, str, str], int] = {}
    for row in d2_parts:
        for company, prefix in ((row["company_a"], "A"), (row["company_b"], "B")):
            key = (company, row["role"], row["activity"])
            assert key not in activity_n
            activity_n[key] = int(row[f"{prefix}_N"])
            activity_p[key] = int(row[f"{prefix}_P"])
            assert int(row[f"{prefix}_U_source"]) == 0
            assert activity_n[key] == d2_member_counts[(company, row["role"])]

    d2_rows: list[dict] = []
    for member in d2_members:
        parts = member["identity_key"].split("|")
        assert parts[0] == ACCEPTANCE_ID
        record_id = "|".join(parts[1:-1])
        assert record_id in reference_by_record
        reference = reference_by_record[record_id]
        assert parts[-1] == reference["source"]["text_version_hash"]
        assert member["company_id"] == reference["company_id"]
        raw = raw_by_record[record_id]
        full_text = str(raw.get("full_description") or "")
        duties = str(raw.get("duties") or "")
        requirements = str(raw.get("requirements") or "")
        captured = bool(full_text.strip() or duties.strip() or requirements.strip())
        language, _, _, _, replacement = classify_language(source_text(raw))
        role_key = (member["company_id"], member["role"])
        n_map = {activity: activity_n[(*role_key, activity)] for activity in activities}
        p_map = {activity: activity_p[(*role_key, activity)] for activity in activities}
        assert len(set(n_map.values())) == 1
        d2_rows.append({
            "case_id": member["case_id"],
            "company_id": member["company_id"],
            "role": member["role"],
            "record_id": record_id,
            "d2_reading_id": member["reading_id"],
            "accepted_packet_id": reference["packet_id"],
            "observation_date": reference["wave"],
            "source_provider": record_id.split("|")[1],
            "source_url": reference["source"].get("source_url", ""),
            "source_path": reference["source"]["path"],
            "source_line": reference["source"]["line"],
            "title": reference["title"],
            "captured_text_body": "1" if captured else "0",
            "full_description_characters": len(full_text),
            "duties_characters": len(duties),
            "requirements_characters": len(requirements),
            "source_language": language,
            "replacement_character_count": replacement,
            "activity_evaluable_main_fixed_k": "1",
            "actual_activity_N": next(iter(n_map.values())),
            "actual_activity_N_by_activity_json": json.dumps(n_map, sort_keys=True),
            "activity_positive_counts_json": json.dumps(p_map, sort_keys=True),
            "identity_key": member["identity_key"],
        })
    assert len(d2_rows) == 142
    assert sum(row["captured_text_body"] == "1" for row in d2_rows) == 142
    write_csv(OUT / "D2_record_evaluability.csv", d2_rows, list(d2_rows[0]))

    d2_summary_rows: list[dict] = []
    for (company, role), expected_n in sorted(d2_member_counts.items()):
        group = [row for row in d2_rows if row["company_id"] == company and row["role"] == role]
        assert len(group) == expected_n
        d2_summary_rows.append({
            "company_id": company,
            "role": role,
            "membership_N": expected_n,
            "captured_text_body_N": sum(row["captured_text_body"] == "1" for row in group),
            "activity_evaluable_N": sum(row["activity_evaluable_main_fixed_k"] == "1" for row in group),
            "observation_dates": ";".join(sorted({row["observation_date"] for row in group})),
            "source_providers": ";".join(sorted({row["source_provider"] for row in group})),
            "source_languages": ";".join(f"{key}:{value}" for key, value in sorted(Counter(row["source_language"] for row in group).items())),
            "full_description_characters_min": min(row["full_description_characters"] for row in group),
            "full_description_characters_max": max(row["full_description_characters"] for row in group),
            "activities_checked": ";".join(activities),
        })
    write_csv(
        OUT / "D2_record_evaluability_summary.csv",
        d2_summary_rows,
        list(d2_summary_rows[0]),
    )

    summary_rows: list[dict] = []
    json_subsets: dict[str, dict] = {}
    subsets = {
        "FULL1654": profile_rows,
        "CORE248": [row for row in profile_rows if row["core248"] == "1"],
    }
    dimensions = {
        "firm_hq_country": "firm_hq_country",
        "ad_location_status": "ad_location_status",
        "source_language": "source_language",
        "core_task": "core_task",
    }
    for subset_name, rows in subsets.items():
        json_subsets[subset_name] = {"n": len(rows), "dimensions": {}}
        for dimension, field in dimensions.items():
            if dimension == "core_task" and subset_name != "CORE248":
                continue
            counts = Counter(row[field] for row in rows)
            json_subsets[subset_name]["dimensions"][dimension] = dict(sorted(counts.items()))
            for value, count in sorted(counts.items()):
                summary_rows.append({
                    "subset": subset_name,
                    "dimension": dimension,
                    "value": value or "(blank)",
                    "count": count,
                    "share": f"{count / len(rows):.6f}",
                })
        cross_dimensions = {
            "firm_hq_country_x_source_language": lambda row: f"{row['firm_hq_country']} | {row['source_language']}",
            "firm_hq_country_x_ad_location_status": lambda row: f"{row['firm_hq_country']} | {row['ad_location_status']}",
        }
        for dimension, key_function in cross_dimensions.items():
            counts = Counter(key_function(row) for row in rows)
            json_subsets[subset_name]["dimensions"][dimension] = dict(sorted(counts.items()))
            for value, count in sorted(counts.items()):
                summary_rows.append({
                    "subset": subset_name,
                    "dimension": dimension,
                    "value": value,
                    "count": count,
                    "share": f"{count / len(rows):.6f}",
                })
        location_counts = Counter(
            row["ad_location"] for row in rows if row["ad_location_status"] == "recorded_geographic"
        )
        json_subsets[subset_name]["dimensions"]["ad_location_geographic_value"] = dict(sorted(location_counts.items()))
        for value, count in sorted(location_counts.items()):
            summary_rows.append({
                "subset": subset_name,
                "dimension": "ad_location_geographic_value",
                "value": value,
                "count": count,
                "share": f"{count / len(rows):.6f}",
            })

    write_csv(OUT / "profile_summary.csv", summary_rows, ["subset", "dimension", "value", "count", "share"])
    summary = {
        "generated_by": "analysis_E_english_v2_0/work/provenance/profile.py",
        "unit": "unique accepted job advertisement",
        "inputs": {
            "source_profile_snapshot": {"path": SOURCE_SNAPSHOT.name, "sha256": sha256(SOURCE_SNAPSHOT)},
            "source_profile_snapshot_manifest": {"path": SOURCE_SNAPSHOT_MANIFEST.name, "sha256": sha256(SOURCE_SNAPSHOT_MANIFEST)},
            "snapshot_generated_from": snapshot_manifest["generated_from"],
            "membership": {"path": str(MEMBERSHIP.relative_to(ROOT)), "sha256": sha256(MEMBERSHIP)},
            "D2_membership": {"path": str(D2_MEMBERSHIP.relative_to(ROOT)), "sha256": sha256(D2_MEMBERSHIP)},
            "D2_role_parts": {"path": str(D2_ROLE_PARTS.relative_to(ROOT)), "sha256": sha256(D2_ROLE_PARTS)},
        },
        "assertions": {
            "accepted_rows": 1654,
            "unique_record_ids": 1654,
            "unique_reading_ids": len(reading_counts),
            "reading_id_collisions": reading_collisions,
            "core_reading_to_packet_alias_mismatches": len(reading_alias_mismatches),
            "companies": 24,
            "primary_membership_rows": 248,
            "primary_membership_unmatched": 0,
            "source_line_identity_mismatches": 0,
            "identity_key_mismatches": 0,
            "hq_country_mismatches": 0,
            "D2_main_membership_rows": len(d2_rows),
            "D2_main_membership_company_counts": dict(sorted(Counter(row["company_id"] for row in d2_rows).items())),
            "D2_main_captured_text_body_rows": sum(row["captured_text_body"] == "1" for row in d2_rows),
            "D2_main_activity_evaluable_rows": sum(row["activity_evaluable_main_fixed_k"] == "1" for row in d2_rows),
            "D2_main_source_providers": dict(sorted(Counter(row["source_provider"] for row in d2_rows).items())),
            "D2_main_observation_dates": dict(sorted(Counter(row["observation_date"] for row in d2_rows).items())),
            "D2_main_source_languages": dict(sorted(Counter(row["source_language"] for row in d2_rows).items())),
            "D2_main_company_role_counts": {
                f"{company} | {role}": count
                for (company, role), count in sorted(d2_member_counts.items())
            },
        },
        "language_rule": {
            "input": "raw source title plus full_description, or duties plus requirements when full_description is empty",
            "labels": ["zh", "en", "es", "pt", "mixed_zh_latin", "unknown_short", "unknown_latin", "unknown_mojibake"],
            "warning": "This deterministic profile is descriptive. It does not infer language from firm country or advertisement location, and it leaves corrupted or insufficient text unknown.",
        },
        "location_rule": "Use raw source location; fall back to accepted-reference location. Blank is unknown_missing; replacement-character text is unknown_encoding; department-only labels are non_geographic_department rather than geographic work locations.",
        "subsets": json_subsets,
    }
    (OUT / "profile_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
