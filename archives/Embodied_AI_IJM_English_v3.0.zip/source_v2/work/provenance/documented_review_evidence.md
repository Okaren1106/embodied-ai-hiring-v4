# Documented human-review evidence

## Evidence layers

The strongest direct evidence is a retrospective author statement supplied on 2026-09-21. In the context of the accepted 1,654-ad corpus, the author reported reviewing the entire accepted corpus and described substantive interventions in category design and decision rules.

> 我全部复核过，有争议的例如多职能并重，或者任选方向，是我提出来的单独类别分析，以及工业设计等后面新增类别也是我先处理的，还有很多判断规则，比如主要看交付，实际做了什么也是我确认的规则

*Working translation prepared for this provenance memo, not a separate author statement:* “I reviewed all of it. For disputed cases, such as roles giving equal weight to several functions or allowing a choice among directions, I proposed analysing them as separate categories. I also initially handled categories added later, such as industrial design. I confirmed many decision rules, including focusing mainly on the deliverable and what the job actually does.”

This statement supports reporting that the author reviewed the accepted advertisement corpus, initiated separate treatment of composite and alternative-direction cases, initially handled the subsequently added industrial-design category, and confirmed a deliverable- and work-content-based classification rule. It does not establish independent double coding, blindness to model output, inter-rater reliability, or a separately logged human decision for every downstream technology-context cell.

The earlier machine-readable completion record, [`human_review_completion_2026-09-14.json`](source_evidence/human_review_completion_2026-09-14.json), records a user-confirmed completion date, 1,654 records and 24 companies. It also states `independent_double_coding_claim=false` and `new_record_level_review_submissions_created=false`. This is a project-level confirmation, not a row-level adjudication file.

The accepted package provides a different evidence layer. Direct audit of the hashed original reference found all 1,654 rows marked `user_accepted=true`, `human_validated=false`, and with an AI reference actor. The local [`accepted_README.md`](source_evidence/accepted_README.md) and [`accepted_manifest.json`](source_evidence/accepted_manifest.json) preserve the package-level status, counts and original reference hash. The false row-level flag does not refute the later author report; it shows that the author review was not entered as 1,654 individual human-validation records.

Preserved review-scope fields are model-review metadata. Across the accepted rows, 1,044 have a nonblank `parent_review_scope` and 610 are blank. The nonblank counts are 562 primary-evidence/four-dimension screens, 280 full-text primary/four-dimension screens, 108 full-text four-dimension reviews, 67 targeted cross-batch adjudications, 15 all-four-dimension/evidence/requirement-tree reviews, nine four-dimension/evidence/primary screens, and three full-text primary/secondary reassessments. Inspection of these records attributes the actions to the Astra model, not to the author.

The measurement history is consistent with the author's account but is not a substitute for row logs. [`MEASUREMENT_RULES_V0.7.5.md`](source_evidence/MEASUREMENT_RULES_V0.7.5.md) records separate simultaneous-duty and alternative-direction categories and the emphasis on continuing deliverables. The application acceptance [`application_acceptance_REPORT.md`](source_evidence/application_acceptance_REPORT.md) documents a structural migration audit and nine repaired records; it explicitly says this was not another semantic reclassification of all 1,654 advertisements. Likewise, the reported 469/760/347 specific-function review-depth counts, 56/164/28 core-task counts, and validation of 456 evidence locations and 496 state links describe heterogeneous model-assisted review and structural checks, not independent human recoding. Snapshot hashes and original paths are recorded in [`source_evidence_manifest.json`](source_evidence/source_evidence_manifest.json).

## Methods-ready statement

The author reports having reviewed the complete accepted corpus and having adjudicated disputed category designs and central decision rules, including classification by the job's substantive deliverable. The preserved release contains project-level confirmation of that review and row-level model provenance, but no row-by-row human decision log or independent second coding. We therefore describe the process as author review and adjudication, without reporting inter-rater reliability or independent double coding.

## Remaining limitation

No preserved artifact dates each author decision, identifies every advertisement changed by the author, or links the retrospective review claim to each of the later 496 advertisement–technology pairs. The exact division of labour between author inspection and model-assisted coding cannot be reconstructed below the evidence layers described above.
