# Sample and source provenance findings

## Reproducible profile

Run [`profile.py`](profile.py) from any working directory. It first reads the packaged 1,654-row [`source_profile_input.jsonl`](source_profile_input.jsonl); if that file is absent, it rebuilds it from the hashed original reference, source lines and company landscape. [`source_profile_input_manifest.json`](source_profile_input_manifest.json) records the snapshot and source hashes. The script combines this snapshot with the packaged primary-task and D2 inputs and writes [`profile_records.csv`](profile_records.csv), [`profile_summary.csv`](profile_summary.csv), [`profile_summary.json`](profile_summary.json), [`D2_record_evaluability.csv`](D2_record_evaluability.csv), and [`D2_record_evaluability_summary.csv`](D2_record_evaluability_summary.csv).

The accepted corpus contains 1,654 unique record IDs across 24 firms. Company metadata classify 963 advertisements (58.2%) to firms headquartered in China and 691 (41.8%) to firms headquartered in the United States. Headquarters country is a firm attribute; it is not treated as advertisement location or source language.

Geographic advertisement location is recorded for 800 ads (48.4%) and missing for 848 (51.3%). Six additional nonempty values—two “市场事业部” and four “市场事业部 / 市场类”—name departments rather than places and are reported as `non_geographic_department`. Geographic coverage is 439/963 among China-headquartered-firm ads and 361/691 among United-States-headquartered-firm ads. In the 248-ad primary task sample, location is recorded for 116 ads (46.8%): 73/163 and 43/85 in the two headquarters-country groups; none of the six department values enters this sample. A missing location is retained as unknown and is not assigned from firm headquarters.

The deterministic text rule classifies the captured source text as Chinese for 957 ads, English for 676, Spanish for six, Portuguese for eight, and unknown because the text is too short for seven. The headquarters-language cross-tab is China–Chinese 957, China–unknown six, United States–English 676, United States–Spanish six, United States–Portuguese eight, and United States–unknown one. The core 248 contains 163 Chinese- and 85 English-source ads. These labels come from captured title and body text, not country or location. The rule does not translate any posting; the frozen source fields remain in the packaged snapshot.

Identity checks use the accepted composite record ID and frozen text-version hash. All 248 primary-task rows join exactly, with no unmatched records. The accepted `packet_id` field has one collision: `P0107` identifies two non-core X Square records. In addition, 99 legacy core rows use an `E####` reading alias where the accepted package uses the corresponding `P####` packet ID. The script verifies equal numeric suffixes and joins those rows through the composite identity key, avoiding an unsafe packet-ID-only join.

## D2 decomposition source/evaluability audit

The local `D_MAIN` fixed-K decomposition has exactly 142 record memberships: 82 Galbot ads from Moka observed on 2026-09-11 and 60 Figure ads from Greenhouse observed on 2026-08-31. Every member has a captured text body. All 82 Galbot source texts classify as Chinese; the Figure set contains 51 English, four Spanish and five Portuguese source texts. No language label is inferred from headquarters.

| Company | Function | Membership N | Captured body N | Main fixed-K activity-evaluable N |
|---|---|---:|---:|---:|
| Galbot | Corporate support | 13 | 13 | 13 |
| Galbot | Manufacturing, quality and supply | 20 | 20 | 20 |
| Galbot | ML/AI engineering | 24 | 24 | 24 |
| Galbot | Robotics software | 25 | 25 | 25 |
| Figure | Corporate support | 11 | 11 | 11 |
| Figure | Manufacturing, quality and supply | 28 | 28 | 28 |
| Figure | ML/AI engineering | 10 | 10 | 10 |
| Figure | Robotics software | 11 | 11 | 11 |

For each of the eight activity indicators in `D2_decomposition_role_parts.csv`, the stored `A_N` or `B_N` equals the corresponding record-membership count above, and the source-unknown count is zero. [`D2_record_evaluability.csv`](D2_record_evaluability.csv) exposes each record's identity, provider, observation date, source line, title, body-field lengths, source-language result, and the exact activity denominators and positive counts inherited from the role-parts table.

This audit establishes captured-source availability and denominator consistency for the local 82-plus-60 decomposition sample. It does not independently revalidate the semantic activity labels, does not change the fixed common-function rule, and is distinct from the whole-board R1/R2/R3 eligibility analyses.

## Limits for interpretation

The sample is purposive and nonprobability. Public boards may omit closed, unposted or inaccessible vacancies. Location remains unavailable for about half the ads, and the language labels are a transparent automated profile rather than manual language coding. The outputs therefore support source-composition and missingness statements, not estimates of country effects or a claim that headquarters determines the language or location of an advertisement.
