# 当前进度：IJM英文论文v2.0实质修订与新增研究已完成

更新：2026-09-21。依据用户提供的严格审稿建议，完成第一档研究修订、第二档的测量核查与公司比较经验拓展，并形成新的英文论文。主要目标为International Journal of Manpower；Astra负责研究结构、计算整合和审校，GPT-5.6 Sol负责英文段落及新读法诊断。用户要求本轮暂不处理出版社AI使用政策，该项未纳入本轮工作。

## 当前交付

- [完整英文阅读稿Word（13页）](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/English_Manuscript_IJM.docx>)；[PDF](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/English_Manuscript_IJM.pdf>)
- [独立正文（12页）](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/IJM_Main_Text.docx>)；[独立表格（3页）](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/IJM_Tables.docx>)；[补充材料（7页）](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/Supplementary_Material.docx>)
- [完整交付包（147个成员）](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/Embodied_AI_IJM_English_v2.0.zip>)；[复算与证据导航](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/README.md>)
- [建议回应与新增研究结果](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/修订回应与研究结果.md>)；[交付状态](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/DELIVERY.json>)；[核验汇总](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v2_0/release/verification_summary.json>)

## 本轮研究结果

研究问题聚焦同一任务内，技术提及与直接资格表达的区分如何改变公司比较。保留24主体1,654条广告、整公司23家1,630条及FAR24条单列的边界；核心为三任务248广告、六任务—技术组合496项。冻结原G/R状态不改，新增广告级并集Q：任一P即P，两者Z即Z，其余U。G原165正例，R新增5项、涉及4广告且无正例重叠，Q为170正例、277负例、49未决。

测量诊断按固定分层抽105项、94广告，遮蔽旧行标签，保存冻结输出后逐项比较。G/R/Q分别有88/100/89项相同；16个Q分歧中3个支持明确示例的U→Z澄清、3个新读法的作用范围不获原规则支持、10个保留争议。另有5个R及1个G状态差异未改变Q。保留原状态、三示例澄清、完整新读法替代、四广告任务边界限制四种情景。这是有范围限定的语境诊断，不是独立人工金标准或总体准确率。

经验拓展展示全部120公司—任务—技术单元，117个点值及3个全未知C++单元。统一M/G/Q可判分母至少10时仅有3个公司对比较，全部为Galbot—XSquare；降低至5时有32个依赖比较，其中8个M→Q排序逆转、27个Q界限分离。新读法替代下逆转变为7/32，主门槛PyTorch小幅点排序改变且区间持续重叠；Python、Linux界限分离保持。因此正文不再把PyTorch排序作为稳健公司差异。

作者2026-09-21确认全量人工复核，并说明多职能并重、任选方向、工业设计等类别及以实际交付/工作为准的规则干预。原话与历史完成记录已保存；没有补造逐条人工审核日志或独立双编码。另完成总部、原始地点与源语言分离、选择时序清单，以及Galbot82+Figure60条实际分解样本的来源/可判审核；未以整公司R1/R2/R3代替局部审核。工程分解仍为+11.10个百分点=+19.45构成项−8.35职能内项，仅作描述背景。

## 验证及边界

18份分析输入哈希通过，1,008项独立SQL/算术核对通过，原600个公司M/G汇总格复现，全部公司对与敏感性情景已重算；105项诊断的75段非空引文精确匹配原文。隔离目录离线运行随包入口，27份分析及来源概况输出逐字节一致。四份Word/PDF共35页逐页检查，545表格单元匹配生成数据。完整包147成员逐个SHA-256核对及ZIP校验通过。阅读稿5,615 Word词，加入图文及图表计量后约7,135—7,415词；补充材料3,043词另列。

本轮授权工作已完成，尚未投稿。限制保留：探索性目的抽样、主比较只有两家公司、语境分歧及无法据广告识别真实需求或因果战略。当前交付是有实证增补和复算记录的研究稿，不代表IJM录用承诺，也没有虚构作者身份或独立人工验证。

## 保留的先前版本

英文v1.0的482份交付文件逐一核对未变；中文v1.4、原研究库和冻结V3未回写。

- [上一版英文完整包](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_english_v1_0/Embodied_AI_IJM_English_v1.0.zip>)
- [中文v1.4完整包](<D:/Embod AI analysis/embodied-ai-hiring-research/analysis_E_revision_v1_4/具身智能公开招聘研究_论文v1.4完整交付包.zip>)

04:00任务`grok-ds-e`保持暂停；本轮未新建自动化或修改其状态。下方为历史研究阶段记录，当前英文论文及新Q分析以v2.0为准。

