"""Package and verify the completed revision without altering earlier releases."""
from pathlib import Path
import hashlib,json,zipfile,subprocess,sys,tempfile
E=Path(__file__).resolve().parents[1];R=E/'release';V=E/'verification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
analysis=read(E/'analysis/independent_audit.json');docs=read(V/'document_checks.json');isolated=read(V/'isolated_reproduction_report.json')
assert analysis['failures']==docs['failures']==0
for n,rec in docs['visual_review'].items():
 assert sha(R/(n+'.docx'))==rec['docx_sha256']
 assert sha(R/(n+'.pdf'))==rec['rendered_pdf_sha256']
save(R/'DELIVERY.json',{
 'version':'3.0','date':'2026-09-22','status':'completed substantive revision',
 'title':'Technology Mentions and Direct Qualification Expressions in Embodied AI Recruitment',
 'journal_target':'International Journal of Manpower','previous_version':'source_v2 is historical and immutable',
 'documents':{n:{'docx':n+'.docx','rendered_pages':d['pages'],'sha256':d['docx_sha256']} for n,d in docs['visual_review'].items()},
 'current_Q':{'positive':170,'nonpositive':280,'unresolved':46,'pairs':496},
 'admissible_scenarios':128,'company_pair_counts':{'threshold_10':3,'threshold_5':32},
 'numerical_checks':analysis['checks_passed'],'document_checks':docs['checks_passed'],
 'offline_outputs_byte_identical':31,'failures':0,
 'document_PDFs':'Local QA copies, excluded from the current delivery ZIP; figure PDFs are publication assets.',
 'submission_status':'Manuscript files prepared; no journal submission or public archive created.'})
verification_files=['independent_analysis.json','independent_pairs.csv','independent_comparison.json',
 'isolated_reproduction_report.json','document_checks.json','word_statistics.json','render_summary.json']
files=[E/p for p in ['README.md','REPRODUCE.py','RESEARCH_PROTOCOL.md']]
for directory in ['source_v2','analysis','data','work','release']:
 for p in sorted((E/directory).rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if directory=='release' and p.parent==R and p.suffix=='.pdf':continue
  files.append(p)
files.extend(V/p for p in verification_files)
files=sorted(set(files),key=lambda p:p.relative_to(E).as_posix())
manifest={'version':'3.0','scope':'Current publication files, code, analytical results and full frozen v2 provenance. QA page images, temporary exports, isolated copies and current document PDFs excluded.',
 'files':[{'path':p.relative_to(E).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
save(E/'publication_manifest.json',manifest)
dest=E/'Embodied_AI_IJM_English_v3.0.zip'
assert not dest.exists(),'Do not overwrite a packaged release; inspect before replacing.'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[E/'publication_manifest.json']:z.write(p,p.relative_to(E).as_posix())
extracted=Path(tempfile.mkdtemp(prefix='final_zip_reproduction_',dir=V))
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 expected={r['path']:r for r in manifest['files']}
 assert set(z.namelist())==set(expected)|{'publication_manifest.json'}
 for name,rec in expected.items():assert hashlib.sha256(z.read(name)).hexdigest()==rec['sha256']
 for member in z.infolist():
  target=(extracted/member.filename).resolve()
  assert target.is_relative_to(extracted.resolve())
 z.extractall(extracted)
completed=subprocess.run([sys.executable,str(extracted/'REPRODUCE.py')],cwd=extracted,capture_output=True,text=True,encoding='utf-8')
(V/'final_zip_reproduction.log').write_text(completed.stdout+'\n'+completed.stderr,encoding='utf-8')
assert completed.returncode==0,completed.stderr
generated=sorted((extracted/'analysis').glob('*'))
generated=[p for p in generated if p.name!='figure_coverage.json']+[extracted/'data/analysis_revision_ledger.json',extracted/'work/provenance/diagnostic_adjudication_ledger.csv',extracted/'work/provenance/diagnostic_process_hashes.csv']
comparison=[]
for p in generated:
 relative=p.relative_to(extracted).as_posix();same=sha(p)==sha(E/relative)
 assert same,relative
 comparison.append({'path':relative,'sha256':sha(p),'byte_identical':same})
assert len(comparison)==31
originals=read(E/'data/previous_version_protection.json')
assert all(sha(E.parent/'analysis_E_english_v2_0'/p)==h for p,h in originals.items())
report={'zip':dest.name,'sha256':sha(dest),'bytes':dest.stat().st_size,'member_count':len(files)+1,
 'manifest_entries':len(files),'member_hashes_verified':len(files),'zip_integrity':'pass',
 'extracted_reproduction_exit':completed.returncode,'outputs_byte_identical':len(comparison),
 'output_comparisons':comparison,'protected_previous_files_unchanged':len(originals),'failures':0}
save(V/'final_package_verification.json',report)
print(json.dumps({k:v for k,v in report.items() if k!='output_comparisons'},ensure_ascii=False))
