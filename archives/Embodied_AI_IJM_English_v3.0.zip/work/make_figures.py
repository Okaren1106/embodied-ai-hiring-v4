"""Code-generated paper figures from the corrected version, with no sample filter.
Figure 1 partitions observed mentions. Figure 2 uses the same fixed task B on
both axes and retains all 120 cells. Colours/markers encode evaluability only.
Unknown ranges are assignment bounds, not confidence intervals.
"""
from pathlib import Path
import csv,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'release/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.titlesize':10,
    'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
    'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,
    'svg.fonttype':'none','savefig.dpi':400})
ORDER=['SK_PYTHON','SK_PYTORCH','SK_CPP','SK_LINUX','SK_ALTIUM','V2_EMC_SIPI']
NAMES=['Robot learning: Python','Robot learning: PyTorch','Robot runtime: C++',
       'Robot runtime: Linux','Board circuitry: Altium','Board circuitry: EMC/SI/PI']
def read(name):return list(csv.DictReader((ROOT/'analysis'/name).open(encoding='utf-8-sig')))
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(OUT/(name+'.'+ext),bbox_inches='tight')
    plt.close(fig)

tasks={r['label_code']:r for r in read('current_task_summary.csv')}
fig,ax=plt.subplots(figsize=(7.1,3.8))
colors=['#0072B2','#B8B8B8','#E69F00']
for y,l in enumerate(ORDER):
    r=tasks[l];m=int(r['M_P']);left=0
    for state,color in zip(['P','Z','U'],colors):
        count=int(r['Q_'+state+'_among_mentions']);width=100*count/m
        ax.barh(y,width,left=left,height=.6,color=color,edgecolor='white',linewidth=.65)
        if count:
            if width<3:
                ax.annotate(str(count),xy=(left+width/2,y),xytext=(103,y),
                    va='center',ha='left',fontsize=8,
                    arrowprops={'arrowstyle':'-','lw':.6,'color':'#555555'},annotation_clip=False)
            else:ax.text(left+width/2,y,str(count),ha='center',va='center',fontsize=8,
                    color='white' if state=='P' else '#111111')
        left+=width
    assert abs(left-100)<1e-8
ax.set_yticks(range(6),NAMES);ax.invert_yaxis();ax.set_xlim(0,109)
ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Share of advertisements mentioning the technology (%)')
ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0)
ax.legend(handles=[Patch(facecolor=c,label=l) for c,l in zip(colors,
    ['Confirmed direct expression','No direct expression recorded','Unresolved'])],
    loc='upper center',bbox_to_anchor=(.44,-.21),ncol=2,frameon=False)
fig.subplots_adjust(left=.33,bottom=.24,top=.98,right=.94)
save(fig,'Figure_1')

cells=read('current_firm_cells.csv')
fig,axes=plt.subplots(3,2,figsize=(7.1,7.2),sharex=True,sharey=True)
coverage=[]
for ax,l,title in zip(axes.flat,ORDER,NAMES):
    rs=[r for r in cells if r['label_code']==l]
    ax.plot([0,100],[0,100],color='#999999',ls='--',lw=.8,zorder=0)
    for r in rs:
        b=int(r['B']);q_n=int(r['Q_N']);n=min(int(r[m+'_N']) for m in ['M','G','Q'])
        x=100*float(r['M_share']);y=100*float(r['Q_confirmed']);hi=100*float(r['Q_hi'])
        if q_n==0:
            color='#E69F00';marker='D';s=29;face='white';ls=':'
        elif n>=10:color='#0072B2';marker='o';s=32;face=color;ls='-'
        elif n>=5:color='#444444';marker='o';s=22;face=color;ls='-'
        else:color='#999999';marker='o';s=19;face='white';ls='-'
        if hi>y:
            ax.vlines(x,y,hi,color=color,lw=1,linestyle=ls,zorder=1)
            ax.plot([x],[hi],marker='_',ms=5,color=color,zorder=1)
        ax.scatter([x],[y],s=s,marker=marker,facecolor=face,edgecolor=color,lw=.8,zorder=2)
        if r['company_id'] in ['CN_GALBOT','CN_XSQUARE'] and n>=10:
            name='Galbot' if r['company_id']=='CN_GALBOT' else 'XSquare'
            if l=='SK_LINUX' and name=='Galbot':dx,dy,ha=-7,-10,'right'
            elif l=='SK_PYTORCH' and name=='XSquare':dx,dy,ha=-4,-13,'right'
            elif l=='SK_PYTORCH' and name=='Galbot':dx,dy,ha=-7,-13,'right'
            else:dx,dy,ha=4,8,'left'
            ax.annotate(name,(x,y),xytext=(dx,dy),textcoords='offset points',fontsize=7.5,ha=ha,
                        arrowprops={'arrowstyle':'-','lw':.5,'color':'#555555','shrinkB':4},
                        bbox={'facecolor':'white','edgecolor':'none','pad':.2,'alpha':.9},zorder=5)
    ax.set_title(title,loc='left',pad=8)
    ax.set_xlim(-4,104);ax.set_ylim(-5,108);ax.set_xticks([0,50,100]);ax.set_yticks([0,50,100])
    ax.grid(axis='both',color='#EEEEEE',lw=.5,zorder=0)
    coverage.append({'label_code':l,'all_cells':len(rs),'confirmed_points':len(rs),
                     'no_evaluable_Q':sum(int(r['Q_N'])==0 for r in rs)})
fig.supxlabel('Technology mentions / all task advertisements (%)',y=.13,fontsize=10)
fig.supylabel('Confirmed direct expressions / all task advertisements (%)',x=.015,fontsize=10)
handles=[Line2D([0],[0],marker='o',ls='',color='#0072B2',label='Evaluable N ≥ 10',ms=5),
         Line2D([0],[0],marker='o',ls='',color='#444444',label='Evaluable N 5–9',ms=4),
         Line2D([0],[0],marker='o',ls='',color='#999999',mfc='white',label='Evaluable N < 5',ms=4),
         Line2D([0],[0],marker='D',ls=':',color='#E69F00',mfc='white',label='No evaluable Q',ms=4)]
fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.52,.025),ncol=2,frameon=False)
fig.subplots_adjust(left=.12,right=.985,top=.97,bottom=.2,hspace=.35,wspace=.18)
save(fig,'Figure_2')
assets={
 'F1':{'kind':'figure','path':'figures/Figure_1.png','title':'Figure 1. Qualification context among technology mentions',
       'note':'Counts partition observed mentions into confirmed Q positives, no direct expression recorded and unresolved states in the corrected analysis. The narrow Linux unresolved segment is labelled outside the bar. Task–technology combinations differ in both their tasks and technologies.'},
 'F2':{'kind':'figure','path':'figures/Figure_2.png','title':'Figure 2. Mentions and confirmed direct expressions on the same task base',
       'note':'Both axes use all B advertisements in the firm–task cell. Markers show the confirmed-positive share P/B; vertical lines extend to (P+U)/B and are unknown-assignment bounds. All 120 cells are plotted; coincident marks can overlap. The three all-unknown C++ cells have zero confirmed positives and ranges from 0 to 100 per cent, shown with hollow diamonds and dotted lines. Their zero confirmed shares do not imply that direct expressions are absent. N is the minimum evaluable count in M, G and Q. The diagonal represents equality on the same denominator.'}}
(OUT/'assets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'analysis/figure_coverage.json').write_text(json.dumps(coverage,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'figure_count':2,'firm_cells_plotted':sum(x['all_cells'] for x in coverage),'zero_evaluable_cells':sum(x['no_evaluable_Q'] for x in coverage)}))
