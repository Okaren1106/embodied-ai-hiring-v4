# Result fact links

This ledger maps the numerical statements in `results.md` and `supplementary_results.md` to generated v3 outputs and the independent recomputation. It checks transcription and arithmetic, not source semantics.

| Result statement | Primary generated source | Independent or source-level check |
| --- | --- | --- |
| 248 advertisements; 496 pairs; 348 mentions; corrected \(Q=170P/280Z/46U\); 34.3%, 37.8%, 34.3–43.5%; 48.9–62.1% among mentions | `analysis/core_facts.json` → `current.totals`; `analysis/scenario_totals.csv` → `CORRECTED_PRIMARY` | `verification/independent_analysis.json` → `versions[THREE_CLEAR_CLARIFICATIONS]` |
| Six task–technology rows and within-mention \(P/Z/U\) counts | `analysis/current_task_summary.csv` | Reaggregation recorded in `verification/independent_analysis.json` |
| Five REQUIRED-only additions in four advertisements | `source_v2/analysis/required_addition_source_check.csv`; `analysis/core_facts.json` | Exact quotes and headings in the source-check CSV |
| 120 firm cells; 22/20/18 firms; three all-unresolved C++ cells | `analysis/current_firm_cells.csv`; `analysis/figure_coverage.json` | `verification/independent_analysis.json` confirms 120 rebuilt cells |
| Threshold 10: ten \(B\)-eligible cells, nine evaluability-eligible cells, three pairs; threshold 5: 26, 21 and 32 | `analysis/current_pair_summary.csv` → `ALL` rows | `verification/independent_analysis.json`; `verification/independent_pairs.csv` |
| Three main differences and bounds | `analysis/main_company_comparisons.csv`; `analysis/core_facts.json` → `current.main_pairs` | `verification/independent_analysis.json` → `main_threshold_pairs` |
| Threshold-five classification 22/5/3/2 and technology decomposition | `analysis/current_pair_summary.csv` | `verification/independent_pairs.csv` |
| A032/A065/A099 \(G,Q:U\rightarrow Z\) | `source_v2/analysis/diagnostic_comparison.csv`; `analysis/ad_technology_current.csv` | `verification/independent_analysis.json` → `revision.changed_rows` |
| 105 diagnostic pairs, 94 advertisements, matches 88/100/89 and 16 \(Q\) differences | `source_v2/analysis/diagnostic_facts.json`; `source_v2/analysis/diagnostic_summary.csv` | Pair-level states in `source_v2/analysis/diagnostic_comparison.csv` |
| Seven coupled switches, ten disputed pairs and 128 admissible readings | `analysis/sensitivity_facts.json`; `analysis/admissible_reading_switches.csv` | `analysis/sensitivity_checks.json` |
| Admissible main envelopes and conditional-gap ranges | `analysis/admissible_comparison_envelopes.csv`; `analysis/sensitivity_facts.json` → `main_comparison_envelopes` | Current endpoints independently reproduced in `verification/independent_analysis.json` |
| Across-reading threshold-five ranges; invariant 22 retentions and five reversals | `analysis/admissible_classification_ranges.csv`; `analysis/sensitivity_facts.json` → `admissible_ranges` | Pair identities in `analysis/scenario_key_audit.csv` and `analysis/admissible_reading_switches.csv` |
| All-switch, all-fresh and task-restriction totals and classifications | `analysis/scenario_totals.csv`; `analysis/scenario_pair_summary.csv` | Key audit in `analysis/scenario_key_audit.csv` |
| Engineering decomposition 82/60 and \(+11.10=+19.45-8.35\); R1/R2/R3 counts | `source_v2/analysis/background_check.json`; packaged background inputs | Recomputed by the v3 background check described in the package manifest |
