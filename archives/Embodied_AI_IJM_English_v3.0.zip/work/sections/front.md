# From Technology Mentions to Direct Qualification Expressions: Within-Task Firm Comparisons in Embodied AI Recruitment

**Purpose:** This paper examines how within-task firm comparisons change when a named technology's presence is separated from its confirmed direct specification as a candidate qualification.

**Design/methodology/approach:** A purposive corpus contains 1,654 public job advertisements from 24 entities associated with embodied artificial intelligence. The analytical sample comprises 248 advertisements, six task–technology combinations and 496 advertisement–technology observations. The analysis compares mention shares and confirmed direct-expression shares on the same task denominator, retains unresolved cases in unknown-assignment bounds and enumerates eligible firm pairs.

**Findings:** Confirmed direct expressions vary across task–technology combinations. At the main comparison threshold, the Galbot–XSquare difference ranges from +19.0 to +63.5 percentage points for Python and +27.5 to +33.8 for Linux, but from −1.6 to +9.5 for PyTorch. Adding two explicit required PyTorch statements removes the separation supported by general-qualification-only bounds. Admissible interpretations preserve the Python and Linux directions while leaving the PyTorch direction unresolved.

**Originality:** The paper combines established relational job-advertisement coding with fixed task denominators and bounds-supported firm comparisons. It shows how a small measurement change can narrow a local conclusion even when aggregate counts change little.

**Keywords:** job advertisements; skill requirements; firm heterogeneity; technology qualifications; embodied artificial intelligence; recruitment

**Article classification:** Research paper
