# Supplementary results and offline result files

## Source diagnostic and adjudication layers

The source-reading diagnostic contains 105 advertisement–technology pairs from 94 advertisements. Relative to the frozen row states, the fresh reader matches 88 pairs for \(G\), 100 for \(R\) and 89 for the union \(Q\); 16 \(Q\) readings differ. These are state matches within the selected diagnostic records. They are not an accuracy estimate because the fresh model is not an independent gold standard and the unweighted diagnostic strata do not estimate a corpus error rate.

The 16 \(Q\) differences separate into three evidence layers. First, A032, A065 and A099 are clear example-scope cases and enter the corrected primary layer as \(U\)-to-\(Z\) changes for both \(G\) and \(Q\). Second, ten list or slash cases remain contestable under the rule sheet: three retain their original list reading and seven retain unresolved slash scope. These ten pairs form seven coupled switches because two C/C++ readings, a Python/PyTorch stack in one advertisement and two identical EMC template readings must move together. Third, two fresh readings would disregard explicit example scope and one would disregard a local modifier; these remain outside the admissible set and enter only the all-fresh extreme. Five additional fresh \(R\) readings treat a generic *Requirements* heading as explicitly mandatory, and one fresh \(G\) reading includes a statement under *Required Skills*; none changes the corresponding \(Q\) state.

[[S1]]

## Examples of REQUIRED-only and clarified expressions

Five advertisement–technology pairs in four advertisements are positive only under an explicitly required scope. The Chinese excerpts below are followed by labelled translations; the two English excerpts are reproduced verbatim.

- **E0206, PyTorch:** under “硬性要求” [mandatory requirements], “深度学习框架熟练(PyTorch 为主);能独立推进实验闭环。” [translation: “Proficient in deep-learning frameworks (primarily PyTorch); able to independently carry an experiment through a closed loop.”] PyTorch is the principal framework, so \(R\) and \(Q\) are positive while \(G\) is not.
- **E0205, PyTorch:** under “硬性要求” [mandatory requirements], “PyTorch 熟练;有仿真(Isaac / MuJoCo)或真机联调经验。” [translation: “Proficient in PyTorch; experience with simulation (Isaac/MuJoCo) or physical-robot integration.”] The choice after the semicolon does not govern PyTorch.
- **N0874, Python:** under *Required Skills*, “Strong Python programming skills.” This gives \(R=Q=P\) and \(G=Z\).
- **N0878, Python and PyTorch:** under *Required Skills*, “Strong Python skills and deep experience with PyTorch”. The conjunctive statement contributes two technology pairs in one advertisement. The required heading does not also make either pair a \(G\) positive.

The three primary clarifications concern explicit example cues. A032 and A099 contain “熟悉PyTorch/TensorFlow等深度学习框架” [translation: “Familiar with deep-learning frameworks such as PyTorch/TensorFlow.”]. A065 contains “有使用PyTorch/TensorFlow、Isaac Gym/Mujoco等工具进行机器人控制相关算法开发的经验。” [translation: “Experience using tools such as PyTorch/TensorFlow and Isaac Gym/MuJoCo to develop robot-control algorithms.”]. In each complete source, “等” governs an illustrative class and no separate unconditional PyTorch expression appears. The revision therefore resolves direct-expression status from \(U\) to \(Z\) without removing the mention.

A contrasting disputed source is N0149: “熟练使用PyTorch/TensorFlow” [translation: “Proficient in using PyTorch/TensorFlow.”]. The slash has no explicit conjunction, choice or example marker. The primary layer retains unresolved scope; the alternative nonpositive reading is one of the admissible switches. This distinction explains why explicit examples are corrected while bare slash constructions remain a sensitivity question.

## Primary and sensitivity results

The immutable frozen version has \(Q=170P/277Z/49U\). Applying the three clear example corrections produces the current primary states, \(170P/280Z/46U\). The confirmed-positive share remains 170/496 (34.3 per cent), while the conditional proportion changes from 170/447 (38.0 per cent) to 170/450 (37.8 per cent). The share among mentions remains 170/348 (48.9 per cent); its upper assignment endpoint falls from 62.9 to 62.1 per cent.

The admissible sensitivity analysis applies every combination of the seven coupled switches to the ten contested pairs. All 128 readings preserve the same pair identities at both thresholds. The all-switch endpoint has \(Q=179P/278Z/39U\); across the main comparisons, Python remains supported, PyTorch remains unresolved and Linux remains supported. At the threshold of five, 22 supported retentions and five supported reversals appear under every reading, while one additional reversal is supported under only some readings.

The all-fresh extreme has \(180P/277Z/39U\). It additionally adopts three readings rejected by the fixed scope rules and the six fresh \(G/R\)-only differences, so it is an extreme stress test rather than another admissible adjudication. The task-boundary restriction begins from the corrected primary layer, excludes four advertisements represented by five diagnostic pairs, and leaves 244 advertisements and 488 pairs with \(Q=169P/274Z/45U\). It does not alter either threshold's pair identities or four-category counts.

[[S2]]

## Firm cells, pair keys and offline navigation

`analysis/current_firm_cells.csv` contains all 120 current firm–task–technology cells: 44 for robot learning and model development, 40 for robot runtime and 36 for board circuitry. Each row supplies \(B\), \(M/G/R/Q\) state counts, confirmed and unresolved shares, conditional proportions, assignment bounds and eligibility flags. All 120 cells have a fixed-base confirmed share. Three C++ cells have \(Q_U=B\), so their conditional proportions are undefined and their bounds span 0–100 per cent.

`analysis/current_firm_pairs.csv` contains all eligible current comparisons. It has 35 threshold-specific rows: three at ten and 32 at five. The three main rows are included again at five; technologies reuse firms and advertisements, so these rows are not independent observations. `analysis/main_company_comparisons.csv` isolates the three main comparisons, and `analysis/current_pair_summary.csv` supplies the six technology rows and total used in Table III. `analysis/current_task_summary.csv` supplies Table I and the within-mention composition for Figure 1. `analysis/ad_technology_current.csv` is the advertisement-level corrected layer; it preserves the historical state and revision identifier for the three changed rows.

Sensitivity files should be joined by the fixed pair key `threshold + task + label_code + company_a + company_b`. `analysis/admissible_reading_switches.csv` defines the 128 switch combinations. `analysis/admissible_reading_pairs.csv` and `analysis/admissible_reading_pair_summary.csv` contain their pair results; `analysis/admissible_comparison_envelopes.csv` gives cross-reading envelopes for each fixed comparison; and `analysis/admissible_classification_ranges.csv` gives the reported category ranges. The `analysis/scenario_*` files contain the frozen, corrected-primary, all-switch, all-fresh and task-restriction scenarios. `analysis/scenario_key_audit.csv` verifies that no scenario adds or removes a threshold-five or threshold-ten pair key.

An independent recomputation in `verification/independent_pairs.csv` and `verification/independent_analysis.json` reads only the two frozen v2 inputs, applies A032/A065/A099 directly, rebuilds all 120 cells and enumerates the company pairs. It reproduces the 3/32 pair counts, current category totals and main difference bounds. This is an arithmetic and transformation check; it does not independently validate source meaning.

[[S3]]

## Engineering-activity decomposition as background

The earlier Galbot–Figure engineering-activity decomposition remains a supplementary composition example. Its fixed four-function comparison contains 82 Galbot and 60 Figure advertisements. Galbot's pooled engineering-activity rate exceeds Figure's by 11.10 percentage points, decomposed arithmetically as \(+19.45-8.35\): a positive function-composition component and a negative within-function component. The identity describes these advertisements and does not estimate a firm effect.

The local source audit and the whole-board R1/R2/R3 screens answer different questions. All 142 records in the four-function comparison have captured text and evaluable activity status, establishing denominator recoverability rather than semantic accuracy. R1, R2 and R3 instead retain 17 firms/968 advertisements, 11/576 and 11/557 after successively applying whole-board activity evaluability, source-quality and description-length rules. Galbot fails those broader board screens even though its 82 records in the local example are evaluable.
