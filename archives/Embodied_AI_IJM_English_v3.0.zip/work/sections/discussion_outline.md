# Discussion and conclusion outline

The numerical anchors below were reproduced in the independent check and provide the verified basis for the final prose.

**Current computation anchors:** after the three clarifications, \(Q\) contains 170 positive, 280 no-positive-recorded and 46 unresolved observations; 450 are evaluable. The confirmed full-task share is 34.3 per cent and its unknown-assignment range is 34.3–43.5 per cent; the evaluable-case rate is 37.8 per cent. Among 348 mentions, the confirmed share is 48.9 per cent and the upper assignment endpoint is 62.1 per cent. For Galbot minus XSquare, the current difference bounds are 19.048–63.492 percentage points for Python, −1.587–9.524 for PyTorch and 27.500–33.750 for Linux. The PyTorch evaluable-case point difference is 1.190 points, while its confirmed-positive difference on the full task base is −1.587 points. At the main threshold, two of three comparisons preserve direction with bounds support and one is an evaluable-case point reversal with overlapping bounds; none is a bounds-supported reversal. At the lower threshold, the current classification is 22 bounds-supported preserved directions, five bounds-supported reversals, three evaluable-case point reversals with overlapping bounds and two aligned point estimates with overlapping bounds, with no ties.

## 5. Discussion

### 5.1 Start with the empirical answer and the hierarchy of measures

- Open with the research question: within a fixed task denominator, what changes when technology presence is separated from a confirmed direct qualification expression?
- Report the main task–technology pattern using the verified v3 totals; retain a task-by-technology placeholder until the final table is frozen: `[[INSERT VERIFIED CELL VALUES]]`.
- Interpret contrasts as properties of the selected task–technology combinations. Do not attribute the Linux–PyTorch contrast to technologies alone because the technologies occur in different predefined tasks.
- Establish the reporting hierarchy once: \(M/B\) for mentions, \(P/B\) for confirmed direct expressions, and \([P/B,(P+U)/B]\) for the range allowed by recorded unresolved cases. Treat \(P/(B-U)\) as a secondary, evaluable-case point estimate.
- Avoid organizing the discussion around whether the confirmed share is above or below one half. That statement can change when unresolved records are assigned or reread.

### 5.2 Explain what the REQUIRED additions change

- State the verified number of required-only additions and their aggregate effect after the independent check.
- Use PyTorch for the strongest measurement lesson. The defensible claim is that adding a small number of explicit required expressions removes the non-overlapping separation supported by the earlier general-qualification-only bounds.
- State that the PyTorch full-task bounds overlap and do not determine a company ordering. If the conditional \(P/(B-U)\) point ordering changes, label it explicitly as an ordering among evaluable-case point estimates.
- Contrast this with Python and Linux, for which the current full-task difference bounds are wholly positive; replace the anchors above with verified rounded values in final prose.
- Do not describe PyTorch as a full-task ranking reversal.

### 5.3 Interpret firm heterogeneity through bounds-supported categories

- Report the complete eligible-pair classification using mutually exclusive categories:
  1. direction preserved and supported by non-overlapping difference bounds;
  2. direction reversed and supported by non-overlapping difference bounds;
  3. point estimate reversed while bounds overlap;
  4. point estimate aligned while bounds overlap;
  5. ties, if present.
- Use the current cross-classification above to organize the paragraph, but insert the counts only after pair keys and revised-state membership are independently verified.
- Explain that the minimum evaluable-cell rule selects firms with sufficient readable states as well as sufficient task advertisements. State why \(G\) remains in the eligibility rule if the final methods retain it.
- Keep the small number of main-threshold comparisons visible. Shared firms and advertisements make these dependent descriptive contrasts rather than independent replications.

### 5.4 Give the adjudication layers their proper evidential roles

- Main analysis: use the versioned layer incorporating the three adjudicated example-scope \(U\)-to-\(Z\) clarifications.
- Rules-consistent ambiguity analysis: retain the ten contestable list or slash cases under the recorded state and compare them with the permitted alternative interpretation.
- Extreme stress test: present replacement by all fresh readings separately because it also includes readings that do not follow the stated scope rules.
- Discuss only which substantive conclusions change across these layers: `[[INSERT VERIFIED SENSITIVITY RESULTS]]`. Move the full match matrix, sampling strata and item-level adjudication trail to methods or supplementary material.
- One sentence is sufficient to delimit the diagnostic: it locates interpretive sensitivity in selected records; it does not estimate corpus-wide accuracy.

### 5.5 Position the contribution by research problem

- Connect the results to vacancy-based skill measurement. Colombo and Marcato (2023) show how detailed vacancy skill measures can inform a labor-market question; the present findings show that the local relation around a named technology can affect the measure before aggregation.
- Connect the semantic step to recruitment applications. Chala et al. (2018) demonstrate an abstract-level semantic matching application; this paper addresses interpretable measurement for firm comparison rather than matching performance.
- Credit GOJA precisely. Krüger et al. (2025) supply the relational representation and existing tool/work-object, alternative and requirement-strength applications. The present increment is their use with fixed task denominators, unresolved states and bounds-supported within-task comparisons.
- Use Bonesso et al. (2022) to maintain the boundary between advertised qualifications and competencies enacted at work. The more distant teleworkability analogy is unnecessary.

### 5.6 Draw practical implications from the observed measurement problem

- Recruitment analysts can distinguish a technology stated as a qualification from one appearing in a duty, example or alternative before comparing requisitions.
- Hiring managers can review advertisements for the same task on a common denominator and inspect unresolved wording instead of relying on name frequency alone.
- HR data teams can preserve direct-expression state and ambiguity when building internal skill inventories or screening rubrics, allowing later users to see which firm differences are supported by the text.
- Present these as uses of the measurement, without claiming effects on applications, hiring or workforce performance.

### 5.7 Concentrate limitations in one closing paragraph

- The firms and collection dates are purposively selected; the results describe the sampled advertisements and eligible comparisons.
- Task restriction improves comparability but does not equalize seniority, templates, location or work objects.
- Unknown-assignment bounds cover recorded \(U\) states, not every possible source or classification error.
- Advertisements document public recruitment language and do not identify realized labor demand, worker capability or causal firm strategy.
- Future evidence could use repeated collections, more firms with comparable task cells and downstream hiring-stage data. Do not turn these into requirements for the present study.

## 6. Conclusion: two-paragraph plan

**Paragraph 1 — empirical answer.** State that mention frequency, confirmed direct-expression share and unknown-assignment bounds provide different evidence about firms recruiting for the same task. Report the final task-pattern result and the firm-pair classification in one compact sequence. Emphasize that Python and Linux retain their direction, whereas adding explicit required PyTorch expressions removes the earlier general-only bound separation and leaves the full-task ordering unresolved.

**Paragraph 2 — contribution and scope.** State that the contribution is the combination of established relational coding with a fixed task denominator and bounds-supported comparison. Close on the implication for labor and HR research: before named technologies are aggregated into firm-level skill measures, their relation to candidate qualifications and the remaining ambiguity should be retained. Use one final scope sentence about public recruitment language; do not repeat the diagnostic history or a list of disclaimers.
