"""Recompute evidence-ranked scenarios and all coupled admissible readings.

Seven recorded ambiguity groups define 128 deterministic combinations. No
probability, sampling accuracy or relative plausibility is attached to a switch.
Frozen identities survive in every scenario. Membership changes are audited by
exact pair key; U-assignment bounds within a reading and ranges across readings
are separately named. No original input or primary classification is overwritten.
"""
import itertools,collections,json,hashlib
from compute_core import (ROOT,SOURCE,OUT,ORDER,CATEGORIES,F,read,write,save,key,cellkey,
                         union,load_inputs,aggregate,summarize,pairs,pair_summary,sign)

def pairkey(r):return r['threshold'],r['task'],r['label_code'],r['company_a'],r['company_b']

def main():
    old,current,diagnostic,ledger=load_inputs()
    policy=json.loads((ROOT/'data/sensitivity_policy.json').read_text(encoding='utf-8'))
    groups=policy['groups'];assert len(groups)==7
    ids=[a for g in groups for a in g['audit_ids']]
    assert len(ids)==len(set(ids))==10
    dbyid={r['audit_id']:r for r in diagnostic};dbykey={key(r):r for r in diagnostic}
    allcells=sorted({cellkey(r) for r in current})
    maincells,maintasks=summarize(current,allcells);mainpairs=pairs(maincells)
    mainset={pairkey(p) for p in mainpairs}
    flagged={r['identity_key'] for r in diagnostic if r['task_support']!='SUPPORTED'}
    assert len(flagged)==4

    def changed_rows(selected=(),extreme=False,task=False,original=False):
        selected=set(selected);out=[]
        for row in old if original else current:
            r=dict(row);d=dbykey.get(key(r))
            if d and (extreme or d['audit_id'] in selected):
                r['G']=d['G_fresh'];r['R']=d['R_fresh'];r['Q']=union(r['G'],r['R'])
            r['included']=int(not(task and r['identity_key'] in flagged))
            r['exclusion_reason']='Previously identified task-boundary ambiguity' if not r['included'] else ''
            out.append(r)
        assert len(out)==496 and {key(r) for r in out}=={key(r) for r in old}
        return out

    named=[('ORIGINAL_FROZEN',changed_rows(original=True)),('CORRECTED_PRIMARY',changed_rows()),
           ('ADMISSIBLE_ALL_SWITCHES',changed_rows(ids)),('ALL_FRESH_EXTREME',changed_rows(extreme=True)),
           ('TASK_BOUNDARY_RESTRICTION',changed_rows(task=True))]
    members,firmrows,taskrows,pairrows,totals,summaries,keyaudit=[],[],[],[],[],[],[]
    for name,rows in named:
        active=[r for r in rows if r['included']]
        cells,tasks=summarize(active,allcells);ps=pairs(cells)
        members.extend(dict(scenario=name,**r) for r in rows)
        firmrows.extend(dict(scenario=name,**r) for r in cells)
        taskrows.extend(dict(scenario=name,**r) for r in tasks)
        pairrows.extend(dict(scenario=name,**r) for r in ps)
        totals.append(dict(scenario=name,advertisements=len({r['identity_key'] for r in active}),**aggregate(active)))
        summaries.extend(dict(scenario=name,**r) for r in pair_summary(ps,cells))
        now={pairkey(p) for p in ps}
        for n in [5,10]:
            a={k for k in mainset if k[0]==n};b={k for k in now if k[0]==n}
            keyaudit.append({'scenario':name,'threshold':n,'main_keys':len(a),'scenario_keys':len(b),
                'same_keys':len(a&b),'added_keys':len(b-a),'removed_keys':len(a-b),
                'added_key_values':json.dumps(sorted(b-a)),'removed_key_values':json.dumps(sorted(a-b))})
    for file,rows in [('scenario_members.csv',members),('scenario_firm_cells.csv',firmrows),('scenario_task_summary.csv',taskrows),
                      ('scenario_firm_pairs.csv',pairrows),('scenario_totals.csv',totals),('scenario_pair_summary.csv',summaries),('scenario_key_audit.csv',keyaudit)]:write(file,rows)

    combinations,combopairs,combototals,combosummaries=[],[],[],[]
    for bits in itertools.product([0,1],repeat=7):
        name='READING_'+''.join(map(str,bits))
        chosen=[a for g,bit in zip(groups,bits) if bit for a in g['audit_ids']]
        rows=changed_rows(chosen);cells,tasks=summarize(rows,allcells);ps=pairs(cells)
        now={pairkey(p) for p in ps}
        combinations.append({'reading':name,**{g['id']:b for g,b in zip(groups,bits)},
             'changed_pair_states':sum(r['Q']!=base['Q'] for r,base in zip(rows,current)),
             'pair_keys_added':len(now-mainset),'pair_keys_removed':len(mainset-now)})
        combototals.append(dict(reading=name,**aggregate(rows)))
        combosummaries.extend(dict(reading=name,**r) for r in pair_summary(ps,cells) if r['label_code']=='ALL')
        combopairs.extend(dict(reading=name,**r) for r in ps)
    write('admissible_reading_switches.csv',combinations)
    write('admissible_reading_totals.csv',combototals)
    write('admissible_reading_pair_summary.csv',combosummaries)
    write('admissible_reading_pairs.csv',combopairs)
    envelopes=[]
    for k in sorted(mainset):
        ps=[p for p in combopairs if pairkey(p)==k]
        assert len(ps)==128,k
        first=ps[0];lo=min(p['Q_difference_lo_pp'] for p in ps);hi=max(p['Q_difference_hi_pp'] for p in ps)
        bdir=1 if lo>0 else -1 if hi<0 else 0
        envelopes.append({'threshold':k[0],'task':k[1],'label_code':k[2],'company_a':k[3],'company_b':k[4],
            'readings':len(ps),'M_direction':first['M_direction'],
            'semantic_and_U_envelope_lo_pp':lo,'semantic_and_U_envelope_hi_pp':hi,
            'envelope_direction':bdir,
            'conditional_gap_min_pp':min(p['Q_conditional_gap_pp'] for p in ps),
            'conditional_gap_max_pp':max(p['Q_conditional_gap_pp'] for p in ps),
            'supported_retention_in_all_readings':int(bdir!=0 and bdir==first['M_direction']),
            'supported_reversal_in_all_readings':int(bdir!=0 and bdir==-first['M_direction']),
            'observed_classifications':'|'.join(sorted({p['classification'] for p in ps}))})
    write('admissible_comparison_envelopes.csv',envelopes)
    ranges=[]
    for n in [5,10]:
        ss=[r for r in combosummaries if r['threshold']==n]
        e=[r for r in envelopes if r['threshold']==n]
        ranges.append({'threshold':n,'readings':128,'fixed_pairs':len(e),
            **{name+'_min':min(r[name] for r in ss) for name in CATEGORIES},
            **{name+'_max':max(r[name] for r in ss) for name in CATEGORIES},
            'supported_retention_all_readings':sum(r['supported_retention_in_all_readings'] for r in e),
            'supported_reversal_all_readings':sum(r['supported_reversal_in_all_readings'] for r in e)})
    write('admissible_classification_ranges.csv',ranges)
    checks={'named_scenarios':len(named),'named_scenario_frame_rows':len(members),
        'admissible_groups':len(groups),'disputed_pairs':len(ids),'admissible_combinations':len(combinations),
        'coupled_C_CPP_cases':True,'coupled_same_advertisement_Python_PyTorch':True,'coupled_identical_EMC_templates':True,
        'named_scenario_keys_identical':all(r['added_keys']==r['removed_keys']==0 for r in keyaudit),
        'admissible_scenario_keys_identical':all(r['pair_keys_added']==r['pair_keys_removed']==0 for r in combinations),
        'source_policy_sha256':hashlib.sha256((ROOT/'data/sensitivity_policy.json').read_bytes()).hexdigest(),
        'failures':0}
    save(OUT/'sensitivity_checks.json',checks)
    save(OUT/'sensitivity_facts.json',{'checks':checks,'named_totals':totals,
        'named_classifications':[r for r in summaries if r['label_code']=='ALL'],
        'admissible_ranges':ranges,'main_comparison_envelopes':[r for r in envelopes if r['threshold']==10]})
    print(json.dumps({'checks':checks,'named_classifications':[r for r in summaries if r['label_code']=='ALL'],
        'admissible_ranges':ranges,'main_envelopes':[r for r in envelopes if r['threshold']==10]},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
