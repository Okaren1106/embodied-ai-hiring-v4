from pathlib import Path
import re
S=Path(__file__).resolve().parent/'sections'
replacements={
 'front.md':[("confirmed direct specification as a candidate qualification","direct specification as a candidate qualification")],
 'introduction.md':[("24 embodied-artificial-intelligence-related entities","24 entities associated with embodied artificial intelligence")],
 'methods.md':[("ML/AI and software work objects","machine-learning and artificial-intelligence (ML/AI) and software work objects"),("the EMC/SI/PI method family","the electromagnetic-compatibility, signal-integrity and power-integrity (EMC/SI/PI) method family"),("the conditional $M$-to-$Q$ ordering","the ordering from the fixed-base mention share $M/B$ to the conditional $Q$ point estimate $P/(B-U)$")],
 'supplementary_methods.md':[("ML/AI and software functions","machine-learning and artificial-intelligence (ML/AI) and software functions"),("unnamed PCB tools","unnamed printed-circuit-board (PCB) tools"),("EMC/SI/PI is the sole","The electromagnetic-compatibility, signal-integrity and power-integrity (EMC/SI/PI) indicator is the sole")],
 'discussion_conclusion.md':[("HR analytics","human resource (HR) analytics")]
}
for name,rs in replacements.items():
 p=S/name;t=p.read_text(encoding='utf-8')
 for a,b in rs:
  if a in t and b not in t:t=t.replace(a,b,1)
 p.write_text(t,encoding='utf-8')
p=S/'results.md';t=p.read_text(encoding='utf-8')
t=re.sub(r'The source diagnostic separates evidence of different strength\..*?all-fresh extreme scenario\.',
 'Three complete phrases explicitly place PyTorch inside example constructions and are corrected from \\(U\\) to \\(Z\\) in the primary analysis. Ten list or slash readings remain contestable and form seven coupled, rule-admissible switches. Three fresh \\(Q\\) readings that disregard explicit example scope or a local modifier enter only the all-fresh extreme scenario; item identities and the decision ledger are reported in the supplement.',t)
p.write_text(t,encoding='utf-8')
