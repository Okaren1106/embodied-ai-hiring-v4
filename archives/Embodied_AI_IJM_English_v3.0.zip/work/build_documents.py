"""Build the revised article from computed results and reviewed English sections."""
from pathlib import Path
import csv,json,re,shutil
import document_tools as dt
E=Path(__file__).resolve().parents[1];W=E/'work';R=E/'release';S=W/'sections';O=E/'analysis'
for p in [R,R/'tables',R/'authoring']:p.mkdir(exist_ok=True)
def read(name,base=O):return list(csv.DictReader((base/name).open(encoding='utf-8-sig',newline='')))
def i(r,k):return int(r[k])
def pct(r,k):return f"{100*float(r[k]):.1f}"
def pp(r,k):return f"{float(r[k]):+.1f}"
order=['SK_PYTHON','SK_PYTORCH','SK_CPP','SK_LINUX','SK_ALTIUM','V2_EMC_SIPI']
names=dict(zip(order,['Robot learning\nPython','Robot learning\nPyTorch','Robot runtime\nC++','Robot runtime\nLinux','Board circuitry\nAltium','Board circuitry\nEMC/SI/PI']))
short=dict(zip(order,['Python','PyTorch','C++','Linux','Altium','EMC/SI/PI']))
def ordered(rows):return sorted(rows,key=lambda r:order.index(r['label_code']))
classes=['SUPPORTED_RETENTION','SUPPORTED_REVERSAL','CONDITIONAL_REVERSAL_OVERLAP','CONDITIONAL_RETENTION_OVERLAP']
A={}
def table(k,title,headers,rows,note,widths):
 A[k]={'kind':'table','title':title,'headers':headers,'rows':rows,'note':note+' Source: calculations from the captured job-advertisement corpus.','widths':widths}
t=ordered(read('current_task_summary.csv'))
table('T1','Table I. Technology mentions and direct qualification expressions',
 ['Task and technology','Ads B','Mention M','Q states\nP / Z / U','Confirmed\nP/B %','Conditional\nP/(B−U) %','Q bounds\n%'],
 [[names[r['label_code']],r['B'],r['M_P'],' / '.join(r['Q_'+v] for v in ['P','Z','U']),pct(r,'Q_confirmed'),pct(r,'Q_conditional'),pct(r,'Q_lo')+'–'+pct(r,'Q_hi')] for r in t],
 'Q is the advertisement-level union of unconditional GENERAL and REQUIRED expressions. P denotes a confirmed positive, Z no recorded positive within the coding scope, and U unresolved scope. Bounds are [P/B, (P+U)/B], not confidence intervals. Conditional proportions exclude U. Robot learning includes model development. EMC/SI/PI denotes the compatibility, signal-integrity and power-integrity method family. The two technologies within each task reuse the same advertisements.',[3.9,1,1.5,2.4,2.0,2.4,2.4])
t=ordered(read('main_company_comparisons.csv'))
table('T2','Table II. Main company differences on fixed and evaluable task bases',
 ['Technology','Mention gap\npp','Confirmed Q gap\npp','Conditional Q gap\npp','Q difference bounds\npp','Interpretation'],
 [[short[r['label_code']],pp(r,'M_gap_pp'),pp(r,'Q_confirmed_gap_pp'),pp(r,'Q_conditional_gap_pp'),pp(r,'Q_difference_lo_pp')+' to '+pp(r,'Q_difference_hi_pp'),'Supported retention' if r['classification']=='SUPPORTED_RETENTION' else 'Conditional reversal; bounds overlap'] for r in t],
 'All gaps are Galbot minus XSquare. Task bases are 18 and 21 advertisements for Python and PyTorch, and 16 and 10 for Linux. M and confirmed Q use these full bases. Conditional Q excludes each firm’s U cases. Q difference bounds assign unknowns in the two firms to opposite endpoints. All three comparisons pass the minimum evaluable-cell threshold of ten; they reuse the same two firms and are not independent replications. Positive bounds support Galbot’s higher direct-expression share.',[1.7,2.0,2.2,2.2,3.1,3.4])
summary=read('current_pair_summary.csv')
t=[r for r in summary if i(r,'threshold')==10 and r['label_code']=='ALL']+[r for r in summary if i(r,'threshold')==5]
table('T3','Table III. Conditional ordering and fixed-base bounds for all eligible comparisons',
 ['Min N','Task and technology','Pairs','Supported retention','Supported reversal','Conditional reversal with overlap','Same direction with overlap'],
 [[r['threshold'],names.get(r['label_code'],'All combinations'),r['pairs']]+[r[c] for c in classes] for r in t],
 'Each firm must meet the minimum separately for evaluable M, G and Q; N is their minimum. Retention and reversal are relative to mention ordering. Supported categories require the Q difference bounds to exclude zero. Overlap categories describe conditional point ordering only. No mention tie, conditional tie or zero bound endpoint occurs. The 32 comparisons at five include all three comparisons at ten; rows share firms and advertisements. Bounds are finite-corpus assignment ranges, not sampling intervals.',[1.3,3.4,1.2,2.3,2.1,3.1,2.7])
A.update(json.loads((R/'figures/assets.json').read_text(encoding='utf-8')))
t=ordered(read('diagnostic_summary.csv',E/'source_v2/analysis'))
table('S1','Supplementary Table S1. Source diagnostic state matches',
 ['Task and technology','Sample pairs','G matches','R matches','Q matches','Q differences','Clear examples'],
 [[names[r['label_code']],r['sample_pairs'],r['G_agreements'],r['R_agreements'],r['Q_agreements'],r['Q_disagreements'],r['Q_U_to_Z_clarifications']] for r in t],
 'The sample has 105 pairs in 94 advertisements. Counts compare frozen original labels with the frozen fresh output before adjudication. Prior-state stratification does not itself rule out probability sampling; these unweighted counts are not corpus accuracy estimates, and the fresh reader supplies no gold standard. The pooled matches are 88 for G, 100 for R and 89 for Q. The state matrices are in source_v2/analysis/diagnostic_confusion.csv; the full stratum frame is in source_v2/work/diagnostic_sampling_frame.csv.',[4.3,1.9,1.8,1.8,1.8,1.8,1.6])
scenario_names={'ORIGINAL_FROZEN':'Frozen original','CORRECTED_PRIMARY':'Corrected primary','ADMISSIBLE_ALL_SWITCHES':'All admissible switches','ALL_FRESH_EXTREME':'All-fresh extreme','TASK_BOUNDARY_RESTRICTION':'Task restriction'}
t=read('scenario_totals.csv')
table('S2','Supplementary Table S2. State totals by evidence layer',
 ['Scenario','Ads','Pairs B','Q positive','Q nonpositive','Q unresolved','Q evaluable'],
 [[scenario_names[r['scenario']],r['advertisements'],r['B'],r['Q_P'],r['Q_Z'],r['Q_U'],r['Q_N']] for r in t],
 'The corrected primary applies only three explicit-example U-to-Z changes. The all-switch case is one of 128 admissible readings. The all-fresh extreme also adopts rejected scope and G/R readings and has a different evidential status. The task restriction starts from the corrected primary and removes four advertisements from both technologies; excluded rows remain identifiable in scenario_members.csv.',[4.2,1.1,1.4,2,2.6,2.8,2])
t=[r for r in read('scenario_pair_summary.csv') if r['label_code']=='ALL']
table('S3','Supplementary Table S3. Joint comparison classifications across named scenarios',
 ['Scenario','Min N','Pairs','Supported retention','Supported reversal','Conditional reversal with overlap','Same direction with overlap'],
 [[scenario_names[r['scenario']],r['threshold'],r['pairs']]+[r[c] for c in classes] for r in t],
 'Each scenario independently reapplies eligibility and retains exactly the corrected-primary pair identities: three at ten and 32 at five. Across all 128 admissible readings, 22 supported retentions and five supported reversals persist at five; a sixth supported reversal occurs in some readings. The main Python and Linux directions remain supported and PyTorch remains unresolved. These are deterministic sensitivity results, with no probability weights.',[3.6,1.3,1.2,2.4,2.2,3.2,2.8])
t=ordered(read('current_task_summary.csv'))
table('S4','Supplementary Table S4. Task coverage and pooled and firm-equal summaries',
 ['Task and technology','Firms with task','Firms with evaluable Q','Pooled confirmed %','Firm-equal confirmed %','Pooled conditional %','Firm-equal conditional %'],
 [[names[r['label_code']],r['firms_with_task'],r['firms_evaluable_Q'],pct(r,'Q_confirmed'),pct(r,'firm_equal_confirmed'),pct(r,'Q_conditional'),pct(r,'firm_equal_conditional')] for r in t],
 'Confirmed shares use B and include all firms with task advertisements. Conditional proportions use B−U and exclude only firms with zero evaluable Q; zero-positive firms otherwise remain. There are 20 runtime firms but only 17 evaluable C++ firms. Firm-equal averages weight eligible firms equally; pooled summaries weight advertisements. Different denominators must not be treated as interchangeable.',[3.8,1.6,2.2,2.2,2.6,2.2,2.6])
t=[r for r in summary if r['label_code']=='ALL']
table('S5','Supplementary Table S5. Eligibility loss relative to the full task base',
 ['Minimum N','Cells with B ≥ N','Cells passing M G Q','Excluded by evaluability','Additional G exclusions','Eligible pairs'],
 [[r['threshold'],r['B_only_eligible_cells'],r['eligible_cells'],r['excluded_by_evaluability'],r['additional_G_exclusions'],r['pairs']] for r in t],
 'The electronic companion tables/S5_Full_Firm_Coverage.csv reports all 120 cells, including B, U/B, M_N, G_N, Q_N and both eligibility flags. Retaining G maintains a common comparison frame; it excludes no additional cell beyond M and Q in these data. A cell may pass the threshold without another eligible firm in its task–technology combination, so eligible cells do not directly equal pair counts.',[1.6,3.1,2.9,3,2.7,2])
table('SPROCESS','Supplementary Table S6. Actors and timing of the source diagnostic',
 ['Stage and timing','Actor or mechanism','Material and evidential limit'],[
 ['Corpus review\nRetrospective statement 21 September 2026','Author','Full accepted corpus reviewed; composite and alternative-direction categories, later categories and deliverable-based rules confirmed. No independent second technology code is documented for every pair.'],
 ['Sample and packet\n21 September 2026','Coordinating task; deterministic hash selection','Up to five records in four prior-G strata per task–technology cell. Sampling seed 20260921 is not a model-generation seed.'],
 ['Fresh source reading\n21 September 2026','GPT-5.6 Sol deployment','105 target pairs, 94 advertisements, rule sheet and source fields. Row labels, rationales, composite identities, firm metadata and strata withheld. High-level workspace history was visible. Output frozen before comparison.'],
 ['Source adjudication\n21 September 2026','GPT-6 Astra deployment in coordinating task','All 16 Q differences and six further G/R differences reread against captured source. No independent human gold standard. Three task-only flagged advertisements did not receive a documented additional full rereading.'],
 ['Revision and sensitivity\n22 September 2026','Coordinating analysis following the revision request','Three explicit-example corrections; seven coupled switches for ten disputed Q readings; rejected fresh readings isolated in an extreme test. No new source-reading sample was generated.'],
 ['Reproducibility record','Saved task and file provenance','Exact neutral prompt, packets, fresh outputs, row excerpts, decision ledger and SHA-256 hashes accompany the package. Deployment labels are recorded; backend snapshots and decoding settings were not preserved.']
 ],'The detailed nine-stage process and complete model prompt provenance are in work/provenance/diagnostic_process.md. The author’s retrospective project review is distinct from model source reading and arithmetic verification.',[3.2,3.4,10.2])
decisions=read('diagnostic_adjudication_ledger.csv',W/'provenance')
policy=json.loads((E/'data/sensitivity_policy.json').read_text(encoding='utf-8'))
byid={r['audit_id']:r for r in decisions}
alternative_prose={
 'c_cpp_bundle':'C/C++ jointly names C and C++ in both constructions; C++ remains the target.',
 'trailing_skill_list':'The trailing skills list is an inclusive enumeration of directly specified skills.',
 'python_pytorch_stack':'Python/PyTorch jointly names an implementation stack. The two technology readings within the same advertisement change together.',
 'emc_including_list':'The repeated including-list qualification directly includes the named method in both advertisements.',
 'qt_cpp_stack':'Qt/C++ jointly names an implementation stack. The separate task-membership question enters only the task-restriction scenario.',
 'pytorch_tensorflow_choice':'The bare PyTorch/TensorFlow pair offers a choice between frameworks. This is the sole observed alternative state used.',
 'linux_unix_joint_list':'Linux/Unix is a joint or inclusive list directly naming Linux. This interpretation does not substitute Unix for the fixed Linux target.'}
table('SDECISIONS','Supplementary Table S7. Coupled admissible source readings',
 ['Pair identifiers','Primary to alternative Q','Alternative reading'],
 [[', '.join(g['audit_ids']),'\n'.join(a+': '+byid[a]['v3_primary_Q']+' → '+byid[a]['Q_fresh'] for a in g['audit_ids']),alternative_prose[g['id']]] for g in policy['groups']],
 'Each row is one binary switch, yielding 128 combinations. Repeated constructions and two targets in one advertisement switch together as indicated. The fixed target remains unchanged in every scenario. The exact original-language quotes and the three primary corrections, ten disputed Q readings, three rejected Q readings and six further G/R differences are recorded in work/provenance/diagnostic_adjudication_ledger.csv.',[3.3,4.2,9.3])

def textfile(name):
 text=(S/name).read_text(encoding='utf-8').strip()
 text=re.sub(r'\\\((.*?)\\\)',lambda m:'$'+m[1]+'$',text)
 text=text.replace('X Square Robot','XSquare').replace('X Square','XSquare')
 # Descriptive headings; numbered main sections and unnumbered subheadings.
 lines=[]
 for line in text.splitlines():
  if line.startswith('### '):line=re.sub(r'^### \d+\.\d+\s+','### ',line)
  if line.startswith('#'):
   line=re.sub(r'(?<=\d)\.(?=\s)','',line).replace('–',' ').replace('—',' ').replace('-',' ').replace(':','').replace(',','')
  lines.append(line)
 return '\n'.join(lines)
title='Technology Mentions and Direct Qualification Expressions in Embodied AI Recruitment'
parts=[textfile(f) for f in ['front.md','introduction.md','methods.md','results.md','discussion_conclusion.md']]
parts[0]=re.sub(r'^# .*', '# '+title,parts[0])
parts[0]=parts[0].replace('**Originality:**','**Originality/value:**')
parts[0]=parts[0].replace('confirmed direct specification','direct specification')
availability='## Data availability\n\nThe accompanying research package contains versioned analytical inputs, source excerpts and identifiers for the task sample, final states, all firm cells and comparisons, the complete diagnostic and executable reproduction scripts. The package README maps each table and figure to its inputs and computation. A public archive has not yet been established. Captured advertisements remain third-party materials; their inclusion for verification does not imply permission for unrestricted redistribution.'
refs=(E/'source_v2/work/references.md').read_text(encoding='utf-8').strip()
refs='\n\n'.join(b for b in re.split(r'\n\s*\n',refs) if not b.startswith('Hennecke'))
(W/'references.md').write_text(refs+'\n',encoding='utf-8')
body='\n\n'.join(parts+[availability,refs])
sm=re.sub(r'^# .*?\n\n','',textfile('supplementary_methods.md'))
sr=re.sub(r'^# .*?\n\n','',textfile('supplementary_results.md'))
supp='# Supplementary Material\n\n'+title+'\n\n'+sm+'\n\n'+sr+'\n\n## Firm coverage tables\n\n[[S4]]\n\n[[S5]]\n\n## Diagnostic process tables\n\n[[SPROCESS]]\n\n[[SDECISIONS]]'
dt.R=R;dt.A=A;dt.LABEL={k:v['title'].split('. ')[0] for k,v in A.items()};dt.DOCUMENT_TITLE=title
dt.build(body,'English_Manuscript_IJM')
submission=body+'\n\n## Figure captions\n\n'+'\n\n'.join(A[k]['title']+'\n\nNotes: '+A[k]['note'] for k in ['F1','F2'])
dt.build(submission,'IJM_Main_Text','submission')
dt.build(supp,'Supplementary_Material')
d=dt.make('tables');d.add_paragraph('Tables','Title')
for n,k in enumerate(['T1','T2','T3']):
 if n:d.add_page_break()
 dt.table(d,k)
d.save(R/'IJM_Tables.docx');(R/'IJM_Tables.md').write_text('\n\n'.join(dt.expand_asset(k) for k in ['T1','T2','T3'])+'\n',encoding='utf-8')
for k,a in A.items():
 if a['kind']=='table':
  with (R/'tables'/(k+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
   wr=csv.writer(f);wr.writerow(a['headers']);wr.writerows(a['rows'])
shutil.copy2(O/'current_firm_cells.csv',R/'tables/S5_Full_Firm_Coverage.csv')
(R/'authoring/assets.json').write_text(json.dumps(A,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(R/'authoring/manuscript_source.md').write_text(body+'\n',encoding='utf-8')
(R/'authoring/supplement_source.md').write_text(supp+'\n',encoding='utf-8')
print('Built four English DOCX documents, three main tables, seven supplementary tables and complete 120-cell electronic coverage table.')
