"""Build the 22-row diagnostic adjudication ledger from the frozen v2 comparison.

The script reads but never modifies source_v2.  It records the v3 interpretation
layer separately, including coupled alternatives for repeated clauses/templates.
"""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "source_v2"
OUT = Path(__file__).resolve().parent

CLEAR = {"A032", "A065", "A099"}
UNSUPPORTED = {"A014", "A017", "A075"}
CONTESTED = {"A043", "A046", "A049", "A050", "A067", "A069", "A080", "A083", "A097", "A104"}
OTHER = {"A013", "A029", "A073", "A092", "A095", "A102"}
ORDER = [
    "A032", "A065", "A099",
    "A014", "A017", "A075",
    "A043", "A046", "A049", "A050", "A067", "A069", "A080", "A083", "A097", "A104",
    "A013", "A029", "A073", "A092", "A095", "A102",
]

ALT_RULE = {
    "A043": "Treat C/C++ in this direct proficiency clause as a conventional joint language bundle.",
    "A046": "Treat the skills preceding terminal 等技能 as directly enumerated competencies, with 等 adding further skills.",
    "A049": "Treat Python / PyTorch in this clause as a joint implementation stack.",
    "A050": "Treat Python / PyTorch in this clause as a joint implementation stack.",
    "A067": "Treat including as introducing named components of the stated tool skill rather than examples only.",
    "A069": "Treat including as introducing named components of the stated tool skill rather than examples only.",
    "A080": "Treat C/C++ in this direct proficiency clause as a conventional joint language bundle.",
    "A083": "Treat Qt/C++ experience as a named joint development stack.",
    "A097": "Treat the same-category PyTorch/TensorFlow slash as a choice, so PyTorch is mentioned but not individually fixed.",
    "A104": "Treat the slash as joint or inclusive enumeration, making the separately named Linux target direct; do not infer Linux from Unix or expand the frozen target to a Linux/Unix family.",
}
COUPLING = {
    "A043": "C01_A043_A080_C_CPP_joint_bundle",
    "A080": "C01_A043_A080_C_CPP_joint_bundle",
    "A046": "C02_A046_terminal_deng_inclusive_list",
    "A049": "C03_A049_A050_same_clause",
    "A050": "C03_A049_A050_same_clause",
    "A067": "C04_A067_A069_identical_template",
    "A069": "C04_A067_A069_identical_template",
    "A083": "C05_A083_Qt_CPP_joint_stack",
    "A097": "C06_A097_PyTorch_TensorFlow_choice",
    "A104": "C07_A104_Linux_Unix_joint_enumeration",
}


def category(audit_id: str) -> str:
    if audit_id in CLEAR:
        return "clear_clarification"
    if audit_id in UNSUPPORTED:
        return "unsupported_fresh_scope"
    if audit_id in CONTESTED:
        return "contested_rule_admissible_alternative"
    if audit_id in OTHER:
        return "other_G_or_R_difference_Q_unchanged"
    raise KeyError(audit_id)


def action(audit_id: str) -> str:
    if audit_id in CLEAR:
        return "adopt adjudicated U-to-Z in v3 primary revision layer; preserve frozen original"
    if audit_id in CONTESTED:
        return "retain adjudicated state in v3 primary; admit fresh state only in contested-reading sensitivity"
    if audit_id in UNSUPPORTED:
        return "retain adjudicated state; fresh state appears only in all-fresh extreme stress test"
    return "retain adjudicated G/R buckets; Q is unchanged; fresh state appears only in all-fresh extreme stress test"


def source_language(quote: str) -> str:
    return "Chinese original; untranslated" if any("\u4e00" <= c <= "\u9fff" for c in quote) else "English original"


with (SOURCE / "analysis" / "diagnostic_comparison.csv").open(encoding="utf-8-sig", newline="") as f:
    by_id = {row["audit_id"]: row for row in csv.DictReader(f)}

assert set(ORDER) == CLEAR | UNSUPPORTED | CONTESTED | OTHER
assert all(audit_id in by_id for audit_id in ORDER)

fields = [
    "audit_id", "category", "reading_id", "identity_key", "company_id", "task", "label_code",
    "source_quote", "source_quote_language_status",
    "G_original", "G_fresh", "G_adjudicated", "R_original", "R_fresh", "R_adjudicated",
    "Q_original", "Q_fresh", "Q_adjudicated", "v3_primary_G", "v3_primary_R", "v3_primary_Q",
    "admissible_alternative_G", "admissible_alternative_R", "admissible_alternative_Q",
    "alternative_allowed", "coupling_group", "primary_action", "alternative_rule",
    "resolution", "adjudication_reason", "fresh_reader_rationale", "task_support",
]

rows = []
for audit_id in ORDER:
    src = by_id[audit_id]
    contested = audit_id in CONTESTED
    row = {
        "audit_id": audit_id,
        "category": category(audit_id),
        "reading_id": src["reading_id"],
        "identity_key": src["identity_key"],
        "company_id": src["company_id"],
        "task": src["task"],
        "label_code": src["label_code"],
        "source_quote": src["fresh_quote"],
        "source_quote_language_status": source_language(src["fresh_quote"]),
        "G_original": src["G_original"],
        "G_fresh": src["G_fresh"],
        "G_adjudicated": src["G_adjudicated"],
        "R_original": src["R_original"],
        "R_fresh": src["R_fresh"],
        "R_adjudicated": src["R_adjudicated"],
        "Q_original": src["Q_original"],
        "Q_fresh": src["Q_fresh"],
        "Q_adjudicated": src["Q_adjudicated"],
        "v3_primary_G": src["G_adjudicated"],
        "v3_primary_R": src["R_adjudicated"],
        "v3_primary_Q": src["Q_adjudicated"],
        "admissible_alternative_G": src["G_fresh"] if contested else "",
        "admissible_alternative_R": src["R_fresh"] if contested else "",
        "admissible_alternative_Q": src["Q_fresh"] if contested else "",
        "alternative_allowed": "1" if contested else "0",
        "coupling_group": COUPLING.get(audit_id, ""),
        "primary_action": action(audit_id),
        "alternative_rule": ALT_RULE.get(audit_id, ""),
        "resolution": src["resolution"],
        "adjudication_reason": src["adjudication_reason"],
        "fresh_reader_rationale": src["fresh_rationale"],
        "task_support": src["task_support"],
    }
    rows.append(row)

with (OUT / "diagnostic_adjudication_ledger.csv").open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)

hash_paths = [
    "source_v2/RESEARCH_PROTOCOL.md",
    "source_v2/blind_review/READER_RULES.md",
    "source_v2/blind_review/packet.json",
    *[f"source_v2/blind_review/packet_{i:02d}.json" for i in range(1, 8)],
    "source_v2/blind_review/judgements.json",
    "source_v2/blind_review/reader_report.md",
    "source_v2/work/blind_output_freeze.json",
    "source_v2/work/diagnostic_adjudication.json",
    "source_v2/work/diagnostic_sampling_frame.csv",
    "source_v2/work/diagnostic_sample_summary.json",
    "source_v2/analysis/diagnostic_comparison.csv",
    "RESEARCH_PROTOCOL.md",
    "data/sensitivity_policy.json",
    "data/reviewer_comments_20260922.txt",
]
with (OUT / "diagnostic_process_hashes.csv").open("w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["path_from_v3_root", "bytes", "sha256"])
    writer.writeheader()
    for rel in hash_paths:
        path = ROOT / rel
        writer.writerow({
            "path_from_v3_root": rel,
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })

print(f"wrote {len(rows)} ledger rows and {len(hash_paths)} hash rows")
