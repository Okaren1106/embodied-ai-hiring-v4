# Source-reading diagnostic: process record

## Purpose and evidential status

The diagnostic was run on 21 September 2026 to locate wording-sensitive advertisement–technology classifications. It was not designed to estimate a population error rate. The sample was stratified on prior states, the second reader was a model rather than a human gold standard, and the selected cases were not reweighted to the 496-pair frame. A state match is therefore a match between two recorded readings, not an accuracy observation.

The frozen v2 artifacts are under `../../source_v2/`. The v3 revision does not overwrite them. It adds a revision layer for three explicit-example clarifications and keeps the remaining readings in evidence-ranked sensitivity layers.

## Compact process table

| Stage | Date and actor | Input and action | What was withheld or visible | Preserved artifact |
|---|---|---|---|---|
| Protocol | 2026-09-21; coordinating research task | Fixed six task–technology cells, four prior-$G$ strata, seed 20260921 and a maximum of five cases per cell–stratum before fresh judgments were viewed. | Earlier results were already known; this was a revision protocol, not preregistration. | `source_v2/RESEARCH_PROTOCOL.md`; `source_v2/work/diagnostic_sample_summary.json` |
| Deterministic draw | 2026-09-21; programmatic selection | Selected 105 pairs covering 94 advertisements from the complete 496-pair frame. Sparse strata contributed fewer than five. | The full frame and selection flags were retained. | `source_v2/work/diagnostic_sampling_frame.csv`; `source_v2/blind_review/packet.json` |
| Packet construction | 2026-09-21; programmatic preparation | Supplied audit ID, target technology, task group, job title and all distinct captured source fields; mechanically redacted employer names where possible. | Withheld composite identity, company metadata, prior row states, rationales and sampling stratum. Source language and wording were necessarily visible. | Seven packet files and consolidated `packet.json` |
| Fresh source reading | 2026-09-21; **GPT-5.6 Sol** deployment | Read all supplied fields and returned $G$, $R$, derived $Q$, exact evidence, heading/branch reasoning, task support and confidence. | Row labels and rationales were hidden. The reader had previously seen the mandatory high-level workspace summary, which exposed aggregate history but not the 105 row answers. | `source_v2/blind_review/READER_RULES.md`; `judgements.json`; `reader_report.md` |
| Freeze and comparison | 2026-09-21; programmatic | Froze all 105 judgments before joining them to earlier states. | The fresh reader did not calculate agreement. | `source_v2/work/blind_output_freeze.json`; `source_v2/analysis/diagnostic_comparison.csv` |
| Source adjudication | 2026-09-21; **GPT-6 Astra** deployment in the coordinating task | Reread the sources for all 16 $Q$ differences and six further $G/R$ differences, then separated explicit-example clarifications, rule-inconsistent readings and contestable slash/list scope. | This was model-assisted source adjudication, not a new human reliability exercise. | `source_v2/work/diagnostic_adjudication.json` |
| Task flags | 2026-09-21; diagnostic and coordinating task | Preserved five pair flags covering four advertisements for a task-boundary restriction scenario. | The three advertisements flagged only for task support (A012, A022 and A079) were not independently reread in full by the coordinating adjudicator. A083 was already among the $Q$ differences; A096 is the same advertisement under the paired technology. | `diagnostic_adjudication.json`, `task_flags` |
| Author evidence | Retrospective report supplied 2026-09-21 | The author stated that the complete accepted corpus had been reviewed and described category and decision-rule interventions. | No row-by-row human decision log, independent second coding or separate confirmation of all later 496 $G/R$ cells was supplied. | `source_v2/work/provenance/documented_review_evidence.md` |
| v3 decision | Authorized 2026-09-22 after reviewer comments | Retain all 496 pairs; apply A032, A065 and A099 from $U$ to $Z$ in a versioned primary layer. Preserve ten rule-admissible alternatives, six $Q$-unchanged differences and three rule-inconsistent readings separately. | This authorization is not described as a new advertisement-by-advertisement human reread. | `../../RESEARCH_PROTOCOL.md`; `diagnostic_adjudication_ledger.csv` |

The `scope` sentence in the frozen `diagnostic_adjudication.json` says that source rereading covered all task flags. The more precise reconstruction is the one in the table: the 16 $Q$ differences and six other state differences were reread; three task-only advertisements were preserved as flags without an additional full-source adjudication. The frozen file remains unchanged, and this memo records the correction.

## Author-review statement

The author supplied the following retrospective statement on 21 September 2026:

> 我全部复核过，有争议的例如多职能并重，或者任选方向，是我提出来的单独类别分析，以及工业设计等后面新增类别也是我先处理的，还有很多判断规则，比如主要看交付，实际做了什么也是我确认的规则

Working translation for this memo: “I reviewed all of it. For disputed cases, such as roles giving equal weight to several functions or allowing a choice among directions, I proposed analysing them as separate categories. I also initially handled categories added later, such as industrial design. I confirmed many decision rules, including focusing mainly on the deliverable and what the job actually does.”

This supports a statement that the author reviewed the accepted corpus and confirmed central category and deliverable rules. It does not establish blindness, double coding, a timestamped decision for each record, or human confirmation of every later technology-state cell.

## Identifiers, prompts and hashes

The available deployment identifiers are **GPT-5.6 Sol** for the fresh reader and **GPT-6 Astra** for the coordinating adjudication. No more specific backend snapshot, temperature, seed for model generation or decoding configuration is preserved, so none is inferred. The deterministic *sampling* seed was 20260921; it is not a model-generation seed.

The complete artifact inventory is in `diagnostic_process_hashes.csv`. The central hashes are:

| Artifact | SHA-256 |
|---|---|
| `source_v2/blind_review/READER_RULES.md` | `bb5948cdab7131a2614c073a9668b990ec9e9254f41436f4ed895f8f706784d2` |
| `source_v2/blind_review/packet.json` | `83d8787cde2c092e20ba9464cb7c6dc3d97516f9231c3ea7aa24a6e6741bad1e` |
| `source_v2/blind_review/judgements.json` | `8f1ef32800186617347ae3af7e3109e48a0c5ac34ca8b1b5b23ca9e45dd25bbb` |
| `source_v2/work/diagnostic_adjudication.json` | `47ef3ec1043bb21b650b50013b03bf0da1771422dcbb1d77532a913076ee688a` |
| `source_v2/analysis/diagnostic_comparison.csv` | `3d0e4e7ee39293658802eb69249fc66a40dfa46efbb3b6e025cfab26898ef437` |
| v3 `RESEARCH_PROTOCOL.md` | `863c7f16591451a894ab34d74f6039bb5e3256c7cfc3548d0b8735b0baab1c2c` |
| v3 `data/sensitivity_policy.json` | `221700ea4368ed529e60c38f606252cfac652e924fbf96aa76c8ad6f7a7be84a` |

`READER_RULES.md` is the preserved substantive rule/prompt file. The seven packet chunks reproduce the consolidated packet and have separate hashes in the inventory. No separate verbatim invocation message is present in the frozen delivery, so the record does not claim one. The saved rule sheet, packets, outputs, report and freeze hash define the evaluable run record.

## Difference accounting

The 22 state differences comprise three clear $Q$ clarifications (A032, A065, A099), ten contestable $Q$ readings, three fresh $Q$ readings inconsistent with the fixed scope rules (A014, A017, A075), and six $G/R$ differences that leave $Q$ unchanged. `diagnostic_adjudication_ledger.csv` preserves the exact source quote, original, fresh, adjudicated and v3-primary states, reasons, the sole observed admissible alternative, and coupling constraints. Chinese quotes remain in the captured language and are marked as untranslated. No disagreement is converted automatically to $U$, $Z$ or $P$.
