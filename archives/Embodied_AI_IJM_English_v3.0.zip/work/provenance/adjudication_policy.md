# Adjudication policy for the 22 diagnostic differences

## Decision rule

The unit is one advertisement–technology pair, and the target remains the exact frozen technology or method family. The decision sequence is:

1. Read every distinct captured source field, heading and locally governing phrase. A duty-only occurrence does not establish a qualification expression.
2. Assign **P** when at least one qualification statement directly commits to the target without choice, example, preference or unresolved scope. A clear positive occurrence survives ambiguity elsewhere.
3. Assign **Z** when adequate source is available but there is no direct unconditional qualification expression. This includes a target governed by a clear example, choice or preference cue. It does not assert employer absence.
4. Assign **U** only when a relevant qualification occurrence exists but its operator, attachment, heading or target relation remains unresolved after full-context reading. Reader disagreement alone does not create $U$.
5. Preserve target grain. A related technology, class or family cannot be substituted for the frozen target. $R$ additionally requires an explicit mandatory statement or required-skills scope; ordinary “Requirements” headings remain $G$. A required-only statement does not also enter $G$.
6. Derive $Q$ only after $G$ and $R$: $P$ if either is $P$, $Z$ if both are $Z$, and $U$ otherwise.

This rule explains the primary distinction questioned by the reviewer. A bare slash without an explicit operator remains $U$ when the individual target relation cannot be settled. An explicit `等`, “such as”, “or”, or illustrative “including” cue gives $Z$ when it governs the target. Some occurrences of `等` or “including” can also be read as adding unnamed members after a direct enumeration; those observed readings are retained as $P$ alternatives rather than silently changing the primary state. No unobserved third state is introduced.

## Three clear clarifications adopted in the v3 primary layer

All three are PyTorch pairs. The governing example cue resolves direct-expression status even though the internal slash could remain ambiguous. The frozen v2 rows remain available; the v3 layer changes $G$ and $Q$ from $U$ to $Z$, with $R=Z$.

| ID | Exact source text | Original → fresh/adjudicated $G/R/Q$ | Reason |
|---|---|---|---|
| A032 | `熟悉PyTorch/TensorFlow等深度学习框架` | U/Z/U → Z/Z/Z | `等深度学习框架` makes the named frameworks examples of the class; there is no separate direct PyTorch statement. |
| A065 | `有使用PyTorch/TensorFlow、Isaac Gym/Mujoco等工具进行机器人控制相关算法开发的经验。` | U/Z/U → Z/Z/Z | `等工具` governs the complete tool list. Slash uncertainty does not turn an illustrative item into an unconditional PyTorch expression. |
| A099 | `熟悉PyTorch/TensorFlow等深度学习框架` | U/Z/U → Z/Z/Z | The framework clause is explicitly illustrative; a separate programming-language choice clause does not alter it. |

The author’s 2026-09-22 instruction adopts this already source-adjudicated three-record correction as a versioned analysis revision. It is not described as a new row-level human recoding.

## Ten contested readings and admissible alternatives

The primary state is the adjudicated v2 state. The only admissible alternative is the state actually observed in the fresh reading and supported by the stated source-specific parse. Each alternative changes $G$ and therefore $Q$; $R$ remains $Z$. Raw Chinese is preserved without translation.

| ID | Exact source text | Primary $G/R/Q$ | Admissible alternative | Why the alternative is admissible but not primary |
|---|---|---|---|---|
| A043 | `熟练掌握C/C++编程，具有独立设计开发能力` | U/Z/U | P/Z/P | $P$ follows if `C/C++` is treated as a conventional joint language bundle. The primary reading does not infer AND or OR from the slash. |
| A046 | `具备dds/ros、故障诊断、linux系统性能分析、linux内核、驱动、计算机网络等技能;` | Z/Z/Z | P/Z/P | $P$ follows if the listed skills are direct competencies and terminal `等` merely adds others. The primary rule treats `等技能` as an illustrative cue governing the mixed list. |
| A049 | `熟练掌握 Python / PyTorch,具备较强的论文复现、模型训练和工程实现能力。` | U/Z/U | P/Z/P | $P$ follows if the cross-category slash denotes a joint implementation stack. The primary reading does not impose technical convention on the grammar. |
| A050 | `熟练掌握 Python / PyTorch,具备较强的论文复现、模型训练和工程实现能力。` | U/Z/U | P/Z/P | Same advertisement and clause as A049, now for Python; it must take the same joint-stack switch. |
| A067 | `Testing & Debugging: Skills using electrical test tools including oscilloscopes, power analyzers, and EMI/EMC setups.` | Z/Z/Z | P/Z/P | $P$ follows if “including” names components of the stated tool skill. The primary reading treats the list as illustrative; no separate general EMC expression supplies $P$. |
| A069 | `Testing & Debugging: Skills using electrical test tools including oscilloscopes, power analyzers, and EMI/EMC setups.` | Z/Z/Z | P/Z/P | Identical template to A067 and therefore constrained to the same list reading. |
| A080 | `熟练掌握Linux环境下C/C++编程` | U/Z/U | P/Z/P | $P$ follows if `C/C++` is a conventional joint bundle. Robot-runtime duties support task membership but do not resolve the qualification operator. |
| A083 | `3年以上Qt/C++开发经验` | U/Z/U | P/Z/P | $P$ follows if `Qt/C++` names a joint development stack. Task-boundary uncertainty is recorded separately and does not decide the technology state. |
| A097 | `熟练使用PyTorch/TensorFlow` | U/Z/U | Z/Z/Z | $Z$ follows if the same-category slash is read as a choice. The source contains no explicit OR or example marker, so the primary state remains unresolved. |
| A104 | `熟悉Linux/Unix系统，了解系统调用和内核机制` | U/Z/U | P/Z/P | $P$ is admissible only if the slash is read as joint or inclusive enumeration, because Linux itself is directly named. Unix is not treated as Linux, and the frozen Linux target is not expanded to a “Linux/Unix family.” |

The ten pairs form seven coherent binary switches:

| Switch | Coupled records | Primary → alternative $Q$ | Constraint |
|---|---|---|---|
| C01 | A043, A080 | U → P | Apply the same C/C++ joint-bundle rule to both. |
| C02 | A046 | Z → P | Terminal-`等` list reading. |
| C03 | A049, A050 | U → P | Same clause; both targets move together. |
| C04 | A067, A069 | Z → P | Identical English template; both records move together. |
| C05 | A083 | U → P | Qt/C++ joint-stack reading. |
| C06 | A097 | U → Z | PyTorch/TensorFlow choice reading. |
| C07 | A104 | U → P | Joint/inclusive slash reading at the unchanged Linux target grain. |

The sensitivity envelope may enumerate the $2^7=128$ coherent combinations of these observed alternatives. It must keep this semantic envelope separate from the within-scenario $U$-assignment bounds. The former changes textual interpretation; the latter assigns the $U$ records left by a specified interpretation. A one-at-a-time or arbitrary row-level mix that breaks C01, C03 or C04 is not admissible.

## Three fresh $Q$ readings outside the fixed rules

These states are retained only in the complete fresh-output stress test. They are not included in the rule-admissible alternative layer.

| ID | Exact source text | Original/final vs fresh $G/R/Q$ | Reason for rejecting the fresh state |
|---|---|---|---|
| A014 | `熟悉常用硬件开发工具，能使用Altium Designer等软件进行原理图与PCB设计；` | Z/Z/Z vs P/Z/P | `Altium Designer等软件` puts Altium inside the example class; competence wording does not cancel the governing cue. |
| A017 | `Ability to turn theoretical insights into practical, testable code using Python and PyTorch (or similar frameworks)` | P/Z/P vs Z/Z/Z | “or similar frameworks” attaches locally to PyTorch/frameworks. Extending it to Python treats a language as a framework without textual support. |
| A075 | `熟练掌握Python, C/C++等编程语言` | Z/Z/Z vs P/Z/P | Terminal `等编程语言` governs the list; there is no separate clause limiting it to C/C++. |

## Six further state differences with unchanged $Q$

These diagnose $G/R$ bucket boundaries. They do not generate an admissible $Q$ alternative.

| ID | Exact source text | Original/final vs fresh $G/R/Q$ | Fixed-rule resolution |
|---|---|---|---|
| A013 | `Proficiency in Python and deep learning frameworks such as PyTorch` | P/Z/P vs P/P/P | “Requirements” alone is general, not an explicit mandatory heading. |
| A029 | `Technical Skills: Strong modern C++, OOP skills, multi-threading, and Linux application development` | P/Z/P vs P/P/P | “SKILLS AND REQUIREMENTS” is general under the rule. |
| A073 | `Strong Python skills and deep experience with PyTorch` | Z/P/P vs P/P/P | The occurrence is under “Required Skills”; $G$ and $R$ are separate buckets, so required-only does not also make $G=P$. |
| A092 | `Expert-level proficiency in Altium Designer for schematic capture and PCB layout` | P/Z/P vs P/P/P | “SKILLS AND REQUIREMENTS” does not itself signal mandatory status. |
| A095 | `Mastery of Altium in both schematics and layout` | P/Z/P vs P/P/P | “Requirements” is an ordinary general heading. |
| A102 | `Mastery of Altium Designer in both schematics and layout` | P/Z/P vs P/P/P | “Requirements” is an ordinary general heading. |

## Scenario hierarchy

The evidence order is: (1) the v3 primary revision with the three explicit-example clarifications; (2) the 128 coherent combinations of the ten contested, observed alternatives; (3) the complete fresh-reader substitution as an extreme stress test, which also imports rule-inconsistent readings; and (4) the separately defined task-boundary restriction. The last scenario changes membership, not qualification semantics. Original frozen states remain a historical comparison. This hierarchy prevents a model disagreement from automatically becoming a correction while allowing defensible readings to influence sensitivity results.

The complete 22-row machine-readable record is `diagnostic_adjudication_ledger.csv`; its generator is `build_diagnostic_ledger.py`. The implemented seven-switch definition is `../../data/sensitivity_policy.json` (SHA-256 `221700ea4368ed529e60c38f606252cfac652e924fbf96aa76c8ad6f7a7be84a`).
