"""Independent checks of joins, revisions, quotes, company coverage and scenarios.

Uses SQLite for aggregation and direct row reconstruction for the 128 sensitivity
readings. Does not import the production aggregation or pair functions.
"""
from pathlib import Path
from fractions import Fraction
import csv,json,hashlib,sqlite3,collections,math,itertools

ROOT=Path(__file__).resolve().parents[1];O=ROOT/'analysis';S=ROOT/'source_v2'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def key(r):return r['identity_key'],r['label_code']
def cell(r):return r['task'],r['label_code'],r['company_id']
def pk(r):return tuple(r[k] for k in ['threshold','task','label_code','company_a','company_b'])
def sg(x):return (x>0)-(x<0)

def main():
    checks=0
    def check(value,reason):
        nonlocal checks
        assert value,reason;checks+=1
    old=read(S/'analysis/ad_technology_union.csv');current=read(O/'ad_technology_current.csv')
    oldmap={key(r):r for r in old};newmap={key(r):r for r in current}
    check(len(oldmap)==len(newmap)==496 and oldmap.keys()==newmap.keys(),'Frame/key preservation')
    changes=[]
    for k,r in newmap.items():
        before=oldmap[k]
        check(all(r[f]==before[f] for f in ['identity_key','reading_id','company_id','task','role','label_code','M']),'Identity/task/mention invariant')
        expected='P' if 'P' in [r['G'],r['R']] else 'Z' if r['G']==r['R']=='Z' else 'U'
        check(r['Q']==expected,'Union state')
        check(r['Q']=='Z' or r['M']=='1','Positive/unknown must be mentioned')
        if before['Q']!=r['Q']:
            check(before['G']==before['Q']=='U' and r['G']==r['Q']=='Z' and before['R']==r['R']=='Z','Only explicit correction')
            changes.append(k)
    ledger=json.loads((ROOT/'data/analysis_revision_ledger.json').read_text(encoding='utf-8'))['changes']
    check(set(changes)=={key(r) for r in ledger} and len(changes)==3,'Revision ledger exact')
    db=sqlite3.connect(':memory:')
    db.execute('CREATE TABLE states(task TEXT,label TEXT,company TEXT,m INTEGER,g TEXT,r TEXT,q TEXT)')
    db.executemany('INSERT INTO states VALUES (?,?,?,?,?,?,?)',[(r['task'],r['label_code'],r['company_id'],int(r['M']),r['G'],r['R'],r['Q']) for r in current])
    grouped=db.execute("SELECT task,label,company,COUNT(*),SUM(m),SUM(g='P'),SUM(g='U'),SUM(q='P'),SUM(q='Z'),SUM(q='U') FROM states GROUP BY task,label,company").fetchall()
    firms={cell(r):r for r in read(O/'current_firm_cells.csv')}
    check(len(grouped)==len(firms)==120,'All company cells')
    for row in grouped:
        k=tuple(row[:3]);r=firms[k]
        for f,v in zip(['B','M_P','G_P','G_U','Q_P','Q_Z','Q_U'],row[3:]):check(int(r[f])==v,'SQL count '+f)
        b,m,gp,gu,qp,qz,qu=row[3:]
        check(int(r['Q_N'])==qp+qz and qp+qz+qu==b,'Q denominator identity')
        for f,v in [('Q_confirmed',Fraction(qp,b)),('Q_lo',Fraction(qp,b)),('Q_hi',Fraction(qp+qu,b))]:
            check(math.isclose(float(r[f]),float(v),abs_tol=1e-14),'Fixed denominator '+f)
        check((r['Q_conditional']=='')==(qp+qz==0),'Undefined conditional value')
    independent=read(ROOT/'verification/independent_pairs.csv')
    aliases={'M_diff_pp':'M_gap_pp','Q_confirmed_diff_pp':'Q_confirmed_gap_pp','Q_conditional_diff_pp':'Q_conditional_gap_pp','Q_diff_lo_pp':'Q_difference_lo_pp','Q_diff_hi_pp':'Q_difference_hi_pp'}
    cmap={'direction_preserved_bounds_supported':'SUPPORTED_RETENTION','direction_reversed_bounds_supported':'SUPPORTED_REVERSAL','conditional_point_reversed_bounds_overlap':'CONDITIONAL_REVERSAL_OVERLAP','conditional_point_same_bounds_overlap':'CONDITIONAL_RETENTION_OVERLAP'}
    for version,filename in [('ORIGINAL_FROZEN','original_firm_pairs.csv'),('THREE_CLEAR_CLARIFICATIONS','current_firm_pairs.csv')]:
        a={pk(r):r for r in independent if r['version']==version};b={pk(r):r for r in read(O/filename)}
        check(a.keys()==b.keys(),'Independent pair identity')
        for k,x in a.items():
            for f,g in aliases.items():check(math.isclose(float(x[f]),float(b[k][g]),rel_tol=1e-12,abs_tol=1e-12),'Independent pair value')
            check(cmap[x['classification']]==b[k]['classification'],'Independent classification')

    # Exact evidence quote checks against original captured fields, not copied rationales.
    records={r['identity_key']:r for r in json.loads((S/'data/inputs/records.json').read_text(encoding='utf-8'))}
    decisions=read(ROOT/'work/provenance/diagnostic_adjudication_ledger.csv')
    check(len(decisions)==len({r['audit_id'] for r in decisions})==22,'Decision ledger rows')
    for r in decisions:
        fields=records[r['identity_key']]['fields']
        check(bool(r['source_quote']) and any(r['source_quote'] in text for text in fields.values()),'Exact original quote '+r['audit_id'])
        primary=newmap[key(r)]
        check(all(primary[m]==r['v3_primary_'+m] for m in ['G','R','Q']),'Ledger vs current states')
    for r in read(ROOT/'work/provenance/diagnostic_process_hashes.csv'):
        check(hashlib.sha256((ROOT/r['path_from_v3_root']).read_bytes()).hexdigest()==r['sha256'],'Process artifact hash')

    scenarios=read(O/'scenario_members.csv');named=collections.defaultdict(list)
    for r in scenarios:named[r['scenario']].append(r)
    diag=read(S/'analysis/diagnostic_comparison.csv');byid={r['audit_id']:r for r in diag}
    policy=json.loads((ROOT/'data/sensitivity_policy.json').read_text(encoding='utf-8'))
    grouped_ids=[set(g['audit_ids']) for g in policy['groups']]
    ledger_groups=collections.defaultdict(set)
    for r in decisions:
        if r['alternative_allowed']=='1':ledger_groups[r['coupling_group']].add(r['audit_id'])
    check({frozenset(g) for g in grouped_ids}=={frozenset(g) for g in ledger_groups.values()},'Coupled groups match source policy')
    for name,rs in named.items():
        check(len(rs)==496 and {key(r) for r in rs}==set(oldmap),'Scenario frame retained')
        excluded=[r for r in rs if r['included']=='0']
        check(len(excluded)==(8 if name=='TASK_BOUNDARY_RESTRICTION' else 0),'Scenario restriction count')
    combinations=read(O/'admissible_reading_switches.csv')
    combos=collections.defaultdict(list)
    for r in read(O/'admissible_reading_pairs.csv'):combos[r['reading']].append(r)
    mainkeys={pk(r) for r in read(O/'current_firm_pairs.csv')}
    check(len(combinations)==len(combos)==128,'All seven-bit combinations')
    field_checks=0
    for switch in combinations:
        replacements={}
        for group in policy['groups']:
            if switch[group['id']]=='1':
                for aid in group['audit_ids']:replacements[key(byid[aid])]=byid[aid]
        groups=collections.defaultdict(list)
        for k,r in newmap.items():
            d=replacements.get(k);q=d['Q_fresh'] if d else r['Q'];g=d['G_fresh'] if d else r['G']
            groups[cell(r)].append((int(r['M']),g,q))
        bycompany={}
        for k,rs in groups.items():
            b=len(rs);p=sum(q=='P' for m,g,q in rs);u=sum(q=='U' for m,g,q in rs)
            gu=sum(g=='U' for m,g,q in rs)
            bycompany[k]=(b,sum(m for m,g,q in rs),p,u,b-u,b-gu)
        ps=combos[switch['reading']]
        enumerated=set()
        for threshold in [5,10]:
            for task,label in sorted({k[:2] for k in bycompany}):
                eligible=sorted(k[2] for k,v in bycompany.items() if k[:2]==(task,label) and min(v[0],v[4],v[5])>=threshold)
                for a,b in itertools.combinations(eligible,2):enumerated.add((str(threshold),task,label,a,b))
        check(enumerated=={pk(r) for r in ps},'Independent enumeration excludes omitted or additional eligible pairs')
        check({pk(r) for r in ps}==mainkeys,'Exact admissible pair keys')
        for p in ps:
            t,l=p['task'],p['label_code'];a=bycompany[t,l,p['company_a']];b=bycompany[t,l,p['company_b']]
            aB,aM,aP,aU,aN,aGN=a;bB,bM,bP,bU,bN,bGN=b
            check(min(aN,aGN,bN,bGN)>=int(p['threshold']),'Scenario eligibility')
            lo=Fraction(aP,aB)-Fraction(bP+bU,bB);hi=Fraction(aP+aU,aB)-Fraction(bP,bB)
            cond=Fraction(aP,aN)-Fraction(bP,bN);mention=Fraction(aM,aB)-Fraction(bM,bB)
            bd=1 if lo>0 else -1 if hi<0 else 0;md,qd=sg(mention),sg(cond)
            category=('MENTION_TIE' if md==0 else ('SUPPORTED_RETENTION' if bd==md else 'SUPPORTED_REVERSAL') if bd else 'CONDITIONAL_TIE_OVERLAP' if qd==0 else 'CONDITIONAL_RETENTION_OVERLAP' if qd==md else 'CONDITIONAL_REVERSAL_OVERLAP')
            for f,val in [('Q_difference_lo_pp',100*lo),('Q_difference_hi_pp',100*hi),('Q_conditional_gap_pp',100*cond)]:
                check(math.isclose(float(p[f]),float(val),abs_tol=1e-12),'Admissible bounds direct row reconstruction');field_checks+=1
            check(p['classification']==category,'Admissible classification reconstruction')
    result={'checks_passed':checks,'failures':0,'SQL_cells_checked':120,'independent_pair_rows':70,
            'exact_source_quotes_checked':len(decisions),'admissible_combinations_reconstructed':128,
            'admissible_pair_numeric_fields_checked':field_checks,'interpretation':'Arithmetic, identity and provenance checks; no claim of semantic gold-standard validation.'}
    (O/'independent_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))

if __name__=='__main__':main()
