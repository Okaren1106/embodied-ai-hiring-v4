"""Check final publication objects after visual review of every rendered page."""
from pathlib import Path
from docx import Document
import json,csv,re,hashlib,zipfile
from lxml import etree
E=Path(__file__).resolve().parents[1];R=E/'release';V=E/'verification'
A=json.loads((R/'authoring/assets.json').read_text(encoding='utf-8'))
checks=[]
def check(ok,name):
 assert ok,name
 checks.append(name)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=['English_Manuscript_IJM','IJM_Main_Text','IJM_Tables','Supplementary_Material']
docs={n:Document(R/(n+'.docx')) for n in names}
for n,d in docs.items():
 texts=[p.text for p in d.paragraphs]
 check(not any('[[T' in x or '[[F' in x or '\\geq' in x or 'Bgeq' in x for x in texts),n+' no unresolved template or math commands')
 check(not d.core_properties.author and not d.core_properties.last_modified_by,n+' clean author metadata')
 with zipfile.ZipFile(R/(n+'.docx')) as z:
  x=etree.fromstring(z.read('word/document.xml'))
  ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
  check(not x.xpath('//w:ins|//w:del|//w:commentReference',namespaces=ns),n+' no tracked changes or comments')
  expected_math=2 if n in names[:2] else 0
  check(len(x.xpath('//m:oMath',namespaces=ns))==expected_math,n+' native equation count')
  if n in names[:2]:
   check('≥' in ''.join(x.xpath('//w:t/text()',namespaces=ns)),n+' rendered comparison symbol')
expected_keys={'English_Manuscript_IJM':['T1','T2','T3'],'IJM_Main_Text':[],
               'IJM_Tables':['T1','T2','T3'],'Supplementary_Material':['S1','S2','S3','S4','S5','SPROCESS','SDECISIONS']}
for n,keys in expected_keys.items():
 check(len(docs[n].tables)==len(keys),n+' exact table count')
 for t,k in zip(docs[n].tables,keys):
  actual=[[c.text for c in row.cells] for row in t.rows]
  expected=[[str(v) for v in row] for row in [A[k]['headers']]+A[k]['rows']]
  check(actual==expected,n+' '+k+' cells match computed table asset')
reader=[p.text for p in docs[names[0]].paragraphs]
submission=[p.text for p in docs[names[1]].paragraphs]
captions={v['title'] for v in A.values()};notes={'Notes: '+v['note'] for v in A.values()}
rtext=[x for x in reader if x and x not in captions and x not in notes]
stext=[x for x in submission[:submission.index('Figure captions')] if x and not x.startswith('[Insert ')]
check(rtext==stext,'Reader and submission prose exactly identical')
inserts=[x for x in submission if x.startswith('[Insert ')]
check(inserts==['[Insert Table I here]','[Insert Figure 1 here]','[Insert Figure 2 here]','[Insert Table II here]','[Insert Table III here]'],'Five unique insertion points')
check(len(docs[names[0]].inline_shapes)==2,'Reader embeds two figures')
check(len(docs[names[1]].inline_shapes)==0,'Submission figures supplied separately')
refs=[x for x in reader[reader.index('References')+1:] if x]
check(len(refs)==10 and not any('Hennecke' in x for x in refs),'Exactly ten cited references')
body=' '.join(reader[:reader.index('References')])
for author in ['Acemoglu','Bonesso','Chala','Colombo','Deming','Fabo','Kitagawa','Krüger','Modestino','Tsvetkova']:
 check(author in body and any(x.startswith(author) for x in refs),'Citation-reference match '+author)
abstract=' '.join(reader[1:reader.index('Article classification: Research paper')])
aw=len(abstract.split());conservative=len(re.findall(r"[A-Za-z0-9]+(?:[.'’][A-Za-z0-9]+)*",abstract))
check(conservative<=250,'Abstract including keywords below 250 even splitting compounds')
coverage=list(csv.DictReader((R/'tables/S5_Full_Firm_Coverage.csv').open(encoding='utf-8-sig')))
check(len(coverage)==120 and len({(x['task'],x['label_code'],x['company_id']) for x in coverage})==120,'Electronic S5 unique full coverage')
for x in coverage:check(all(k in x for k in ['B','Q_unresolved_share','M_N','G_N','Q_N']),'Coverage fields '+x['company_id']+' '+x['label_code'])
previous=json.loads((E/'data/previous_version_protection.json').read_text(encoding='utf-8'))
for p,h in previous.items():check(sha(E.parent/'analysis_E_english_v2_0'/p)==h,'Protected previous file '+p)
render=json.loads((V/'render_summary.json').read_text(encoding='utf-8'))
visual={}
for n in names:
 pages=[V/'pages'/n/f'page-{i:02}.png' for i in range(1,render[n]['pages']+1)]
 check(all(p.exists() for p in pages),n+' all page renders exist')
 visual[n]={'pages':len(pages),'docx_sha256':sha(R/(n+'.docx')),'rendered_pdf_sha256':sha(R/(n+'.pdf')),
            'page_images':[{'page':i+1,'sha256':sha(p)} for i,p in enumerate(pages)],
            'inspection':'Coordinating agent viewed every final page at the generated 980 by 1268 resolution. No clipping, overlaps, missing symbols or broken table rows remain. S6 continues with a repeated header.'}
result={'checks_passed':len(checks),'failures':0,'checks':checks,'abstract_including_keywords':{'whitespace_words':aw,'compound_split_words':conservative},
        'word_statistics':json.loads((V/'word_statistics.json').read_text(encoding='utf-8-sig')),
        'journal_length_estimate':{'method':'Submission Word count, including title, abstract, keywords, references, insertion calls and captions, plus 280 for each of three tables and two figures. Supplement excluded. Based on the supplied review; not a fresh publisher certification.', 'words':4941+5*280},
        'visual_review':visual,'protected_previous_files':len(previous),
        'renderer':'Canonical render_docx.py attempted; failed because soffice.exe is absent from PATH. Initial sandbox Word COM failed with 0x80070520. Approved local hidden Word COM exported read-only temporary copies; PDFium rendered all pages.'}
(V/'document_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['checks_passed','failures','abstract_including_keywords','journal_length_estimate','protected_previous_files']},ensure_ascii=False))
