"""Fixed-base estimates and exhaustive company comparisons for the IJM revision.

DECISIONS LOG, 2026-09-22
Unit: immutable advertisement identity x technology, 496 rows from 248 ads.
Cross-section, purposive source corpus, no causal inference or sampling inference.
Input source_v2 is immutable. The user requested the supplied review's three
explicit-example clarifications; only A032/A065/A099 G U->Z are revised here.
Q is rederived from G and R. No identity, task or membership changes occur.
Pair eligibility retains min(M_N,G_N,Q_N)>=10 or >=5; exact fractions determine
all directions, ties and boundary comparisons. Missing keys stop computation.
"""
from pathlib import Path
from fractions import Fraction as F
import csv, json, collections, itertools, hashlib

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'source_v2'
OUT = ROOT/'analysis'
ORDER = ['SK_PYTHON','SK_PYTORCH','SK_CPP','SK_LINUX','SK_ALTIUM','V2_EMC_SIPI']
CLARIFICATIONS = ['A032','A065','A099']
CATEGORIES = ['SUPPORTED_RETENTION','SUPPORTED_REVERSAL','CONDITIONAL_REVERSAL_OVERLAP',
              'CONDITIONAL_RETENTION_OVERLAP','MENTION_TIE','CONDITIONAL_TIE_OVERLAP']

def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write(name, rows):
    assert rows, name
    OUT.mkdir(exist_ok=True)
    with (OUT/name).open('w', encoding='utf-8', newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)

def save(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def key(r):return r['identity_key'],r['label_code']
def cellkey(r):return r['task'],r['label_code'],r['company_id']
def union(g,r):return 'P' if 'P' in (g,r) else 'Z' if g==r=='Z' else 'U'
def sign(x):return (x>0)-(x<0)
def ratio(p,n):return float(F(p,n)) if n else ''

def load_inputs():
    manifest=json.loads((SOURCE/'publication_manifest.json').read_text(encoding='utf-8'))
    for item in manifest['files']:
        path=SOURCE/item['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],item['path']
    rows=read(SOURCE/'analysis/ad_technology_union.csv')
    assert len(rows)==496 and len({key(r) for r in rows})==496
    assert len({r['identity_key'] for r in rows})==248
    for r in rows:
        r['M']=int(r['M']);r['choice_or_example']=int(r['choice_or_example'])
        assert r['M'] in [0,1]
        assert r['Q']==union(r['G'],r['R'])
        assert r['Q']=='Z' or r['M']==1
    diagnostic=read(SOURCE/'analysis/diagnostic_comparison.csv')
    assert len(diagnostic)==len({r['audit_id'] for r in diagnostic})==105
    bykey={key(r):r for r in rows}
    ledger=[]
    for d in diagnostic:
        if d['audit_id'] in CLARIFICATIONS:
            old=bykey[key(d)]
            assert old['G']==old['Q']=='U' and old['R']=='Z'
            assert d['resolution']=='clarify_U_to_Z'
            assert d['G_adjudicated']==d['Q_adjudicated']=='Z'
            ledger.append({**{k:d[k] for k in ['audit_id','identity_key','reading_id','company_id','task','label_code']},
                'G_before':'U','G_after':'Z','R_before':'Z','R_after':'Z','Q_before':'U','Q_after':'Z',
                'reason':d['adjudication_reason'], 'source_quote':d['fresh_quote'],
                'prior_source_adjudication':'2026-09-21; coordinating Astra source rereading',
                'analysis_revision_date':'2026-09-22',
                'authorization':'User instructed substantive revision according to the supplied review recommending these three explicit clarifications. This is not a claim of a new independent human recoding.'})
    assert sorted(x['audit_id'] for x in ledger)==CLARIFICATIONS
    corrected=[];lookup={key(r):r for r in ledger}
    for row in rows:
        r=dict(row)
        if key(r) in lookup:r['G']='Z';r['Q']=union(r['G'],r['R'])
        corrected.append(r)
    return rows,corrected,diagnostic,ledger

def aggregate(rows):
    b=len(rows);result={'B':b,'M_P':sum(r['M'] for r in rows),'M_N':b}
    result['M_share']=ratio(result['M_P'],b)
    for m in ['G','R','Q']:
        states=collections.Counter(r[m] for r in rows)
        for state in ['P','Z','U']:result[m+'_'+state]=states[state]
        p,u=states['P'],states['U'];n=b-u
        result.update({m+'_N':n,m+'_confirmed':ratio(p,b),m+'_conditional':ratio(p,n),
                       m+'_lo':ratio(p,b),m+'_hi':ratio(p+u,b),m+'_unresolved_share':ratio(u,b)})
    mentions=[r for r in rows if r['M']]
    for state in ['P','Z','U']:result['Q_'+state+'_among_mentions']=sum(r['Q']==state for r in mentions)
    result['Q_among_mentions_lo']=ratio(result['Q_P_among_mentions'],len(mentions))
    result['Q_among_mentions_hi']=ratio(result['Q_P_among_mentions']+result['Q_U_among_mentions'],len(mentions))
    result['choice_or_example_nonQ']=sum(r['Q']=='Z' and r['choice_or_example'] for r in rows)
    result['R_only_additions']=sum(r['R']=='P' and r['G']!='P' for r in rows)
    result['G_R_overlap']=sum(r['R']==r['G']=='P' for r in rows)
    return result

def summarize(rows, allcells=None):
    grouped=collections.defaultdict(list)
    for r in rows:grouped[cellkey(r)].append(r)
    names={r['company_id']:r['company_name'] for r in rows}
    cells=[]
    for t,l,c in sorted(allcells if allcells is not None else grouped):
        s={'task':t,'label_code':l,'company_id':c,'company_name':names.get(c,c),**aggregate(grouped[t,l,c])}
        for n in [5,10]:
            s['eligible_'+str(n)]=int(min(s['M_N'],s['G_N'],s['Q_N'])>=n)
            s['B_only_eligible_'+str(n)]=int(s['B']>=n)
            s['G_additionally_excludes_'+str(n)]=int(min(s['M_N'],s['Q_N'])>=n and s['G_N']<n)
        cells.append(s)
    tasks=[]
    for l in ORDER:
        taskrows=[r for r in rows if r['label_code']==l]
        cs=[c for c in cells if c['label_code']==l]
        valid=[c for c in cs if c['Q_N']]
        active=[c for c in cs if c['B']]
        tasks.append({'task':taskrows[0]['task'],'label_code':l,**aggregate(taskrows),
            'firms_with_task':len(active),'firms_evaluable_Q':len(valid),
            'firm_equal_confirmed':float(sum(F(c['Q_P'],c['B']) for c in active)/len(active)),
            'firm_equal_conditional':float(sum(F(c['Q_P'],c['Q_N']) for c in valid)/len(valid))})
    return cells,tasks

def compare(a,b,threshold):
    d={'threshold':threshold,'task':a['task'],'label_code':a['label_code'],
       'company_a':a['company_id'],'company_b':b['company_id'],
       'name_a':a['company_name'],'name_b':b['company_name']}
    for prefix,c in [('A',a),('B',b)]:
        for field in ['B','M_P','M_N','G_P','G_U','G_N','Q_P','Q_U','Q_N']:
            d[prefix+'_'+field]=c[field]
    mgap=F(a['M_P'],a['B'])-F(b['M_P'],b['B'])
    d['M_gap_pp']=float(100*mgap);d['M_direction']=sign(mgap)
    measures={}
    for m in ['G','Q']:
        confirmed=F(a[m+'_P'],a['B'])-F(b[m+'_P'],b['B'])
        conditional=F(a[m+'_P'],a[m+'_N'])-F(b[m+'_P'],b[m+'_N'])
        lo=F(a[m+'_P'],a['B'])-F(b[m+'_P']+b[m+'_U'],b['B'])
        hi=F(a[m+'_P']+a[m+'_U'],a['B'])-F(b[m+'_P'],b['B'])
        direction=1 if lo>0 else -1 if hi<0 else 0
        assert lo<=confirmed<=hi and lo<=conditional<=hi
        d.update({m+'_confirmed_gap_pp':float(100*confirmed),m+'_conditional_gap_pp':float(100*conditional),
            m+'_difference_lo_pp':float(100*lo),m+'_difference_hi_pp':float(100*hi),
            m+'_confirmed_direction':sign(confirmed),m+'_conditional_direction':sign(conditional),
            m+'_bounds_direction':direction,m+'_bounds_touch_zero':int(lo==0 or hi==0),
            m+'_bounds_straddle_zero':int(lo<0<hi)})
        measures[m]=(confirmed,conditional,lo,hi,direction)
    confirmed,conditional,lo,hi,bd=measures['Q'];md=sign(mgap);qd=sign(conditional)
    if md==0:category='MENTION_TIE'
    elif bd:category='SUPPORTED_RETENTION' if bd==md else 'SUPPORTED_REVERSAL'
    elif qd==0:category='CONDITIONAL_TIE_OVERLAP'
    elif qd==md:category='CONDITIONAL_RETENTION_OVERLAP'
    else:category='CONDITIONAL_REVERSAL_OVERLAP'
    d['classification']=category
    d['conditional_point_reversal']=int(md*qd==-1)
    d['confirmed_share_reversal']=int(md*sign(confirmed)==-1)
    d['conditioning_dependent_point_reversal']=int(md*qd==-1 and md*sign(confirmed)!=-1)
    d['recorded_share_change_pp']=float(100*(confirmed-mgap))
    d['conditioning_increment_pp']=float(100*(conditional-confirmed))
    d['total_M_to_conditional_change_pp']=float(100*(conditional-mgap))
    assert conditional-mgap==(confirmed-mgap)+(conditional-confirmed)
    return d

def pairs(cells):
    result=[]
    for n in [5,10]:
        for l in ORDER:
            eligible=sorted([c for c in cells if c['label_code']==l and min(c['M_N'],c['G_N'],c['Q_N'])>=n],key=lambda c:c['company_id'])
            for a,b in itertools.combinations(eligible,2):result.append(compare(a,b,n))
    return result

def pair_summary(ps,cells):
    result=[]
    for n in [5,10]:
        for l in ORDER+['ALL']:
            selected=[p for p in ps if p['threshold']==n and (l=='ALL' or p['label_code']==l)]
            selectedcells=[c for c in cells if l=='ALL' or c['label_code']==l]
            counts=collections.Counter(p['classification'] for p in selected)
            result.append({'threshold':n,'label_code':l,'pairs':len(selected),
                'eligible_cells':sum(c['eligible_'+str(n)] for c in selectedcells),
                'B_only_eligible_cells':sum(c['B_only_eligible_'+str(n)] for c in selectedcells),
                'excluded_by_evaluability':sum(c['B_only_eligible_'+str(n)]-c['eligible_'+str(n)] for c in selectedcells),
                'additional_G_exclusions':sum(c['G_additionally_excludes_'+str(n)] for c in selectedcells),
                **{k:counts[k] for k in CATEGORIES},
                'conditional_point_reversals':sum(p['conditional_point_reversal'] for p in selected),
                'confirmed_share_reversals':sum(p['confirmed_share_reversal'] for p in selected),
                'conditioning_dependent_point_reversals':sum(p['conditioning_dependent_point_reversal'] for p in selected)})
    return result

def main():
    original,current,diagnostic,ledger=load_inputs()
    save(ROOT/'data/analysis_revision_ledger.json',{'revision':'3.0','changes':ledger,'changed_pairs':3,'original_frame_pairs':496,'revised_frame_pairs':496})
    exported=[]
    oldbykey={key(r):r for r in original}
    revision_by_key={key(r):r['audit_id'] for r in ledger}
    for r in current:
        old=oldbykey[key(r)]
        exported.append({**r,'G_original':old['G'],'R_original':old['R'],'Q_original':old['Q'],
            'revised':int(old['Q']!=r['Q']),'revision_audit_id':revision_by_key.get(key(r),''),'included':1})
    write('ad_technology_current.csv',exported)
    allfacts={}
    for name,rows in [('original',original),('current',current)]:
        cells,tasks=summarize(rows);ps=pairs(cells);summary=pair_summary(ps,cells)
        write(name+'_firm_cells.csv',cells);write(name+'_task_summary.csv',tasks)
        write(name+'_firm_pairs.csv',ps);write(name+'_pair_summary.csv',summary)
        allfacts[name]={'totals':aggregate(rows),'cells':len(cells),'pair_summary':[s for s in summary if s['label_code']=='ALL'],
                        'main_pairs':[p for p in ps if p['threshold']==10]}
    write('main_company_comparisons.csv',allfacts['current']['main_pairs'])
    save(OUT/'core_facts.json',allfacts)
    checks={'frame_pairs':len(current),'advertisements':len({r['identity_key'] for r in current}),
        'revised_pairs':len(ledger),'firm_cells':len(cells),'pair_rows_two_thresholds':len(ps),
        'unchanged_identity_task_membership':True,'exact_rational_signs':True,'failures':0}
    save(OUT/'core_checks.json',checks)
    print(json.dumps({'checks':checks,'current_totals':allfacts['current']['totals'],
        'current_pairs':allfacts['current']['pair_summary'], 'main_pairs':allfacts['current']['main_pairs']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
