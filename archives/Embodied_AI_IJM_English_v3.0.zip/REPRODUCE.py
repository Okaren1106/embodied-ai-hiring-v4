"""Offline standard-library reproduction of the third IJM revision."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ['work/compute_core.py','work/compute_sensitivity.py','work/provenance/build_diagnostic_ledger.py','work/audit_analysis.py']:
    result=subprocess.run([sys.executable,str(root/name)],cwd=root,capture_output=True,text=True,encoding='utf-8')
    if result.returncode:
        print(result.stdout);print(result.stderr,file=sys.stderr);raise SystemExit(result.returncode)
    print('PASS '+name)
print('All revised numerical outputs regenerated and checked from packaged inputs.')
