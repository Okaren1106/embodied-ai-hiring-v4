"""Portable Stage E reproduction; no live project files or network required.
Standard-library table/strict-context reproduction. --figures also needs matplotlib/numpy.
"""
from pathlib import Path
from collections import Counter
import argparse,csv,hashlib,json,math,os,tempfile
parser=argparse.ArgumentParser()
parser.add_argument('--inputs',type=Path,default=Path(__file__).resolve().parent/'inputs')
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--figures',action='store_true')
args=parser.parse_args();INPUT=args.inputs.resolve();FINAL=args.output.resolve()
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
    if not ok:raise ValueError(msg)
def rows(n):return read(INPUT/(n+'.csv'))
manifest=json.loads((INPUT/'manifest.json').read_text(encoding='utf-8'))
for m in manifest:
    p=(INPUT/m['path']).resolve()
    require(p.is_relative_to(INPUT),'INPUT_PATH_ESCAPE')
    require(p.is_file() and sha(p)==m['sha256'],'INPUT_HASH_MISMATCH: '+m['path'])
require(sha(INPUT/'field_map.md')=='ba4dff748b3bb015887e786488b6e5fccea678ea4cde0bb3b9b4aeb89e36c5a8','PROTOCOL_HASH_MISMATCH')
require(not FINAL.exists(),'OUTPUT_ALREADY_EXISTS')
states=rows('strict_states');members=rows('pair_membership');expected=rows('pair_strict_sensitivity')
def statekey(r):return tuple(r[k] for k in ('identity_key','label_code','metric','branch'))
st={statekey(r):r for r in states}
require(len(st)==len(states),'DUPLICATE_STATE_KEY')
require(len({(r['scenario'],r['role'],r['task'],r['identity_key']) for r in members})==len(members),'DUPLICATE_MEMBER_KEY')
require(all(r['state'] in ('P','Z','U','NA','SOURCE_EXCLUDED') for r in states),'INVALID_STATE')
cells={('ROBOT_MODEL','SK_PYTHON','CN_GALBOT'),('ROBOT_MODEL','SK_PYTHON','CN_XSQUARE'),('ROBOT_RUNTIME','SK_CPP','CN_GALBOT'),('ROBOT_RUNTIME','SK_CPP','CN_XSQUARE'),('BOARD_CIRCUIT','SK_ALTIUM','US_APPTRONIK')}
scenarios={'PRIMARY','PLUS_SECONDARY','DEDUP_PRIMARY','NO_CAMPUS_PRIMARY'}
require({(r['scenario'],r['task'],r['label_code'],r['company_id']) for r in expected}=={(sc,*cell) for sc in scenarios for cell in cells} and len(expected)==20,'STRICT_CELL_SET')
recalculated=[];used=set();slice_count=0
for a in expected:
    ms=[r for r in members if all(r[k]==a[k] for k in ('scenario','role','task','company_id'))]
    require(bool(ms),'MISSING_MEMBERS')
    require(a['metric']=='GENERAL' and a['branch']=='UNCONDITIONAL','WRONG_CONTEXT')
    c=Counter()
    for m in ms:
        k=(m['identity_key'],a['label_code'],'GENERAL','UNCONDITIONAL')
        require(k in st,'MISSING_STATE: '+str(k));c[st[k]['state']]+=1;used.add(k);slice_count+=1
    p,z,u=c['P'],c['Z'],c['U'];n=p+z;b=n+u
    calc=dict(a)
    nums={'members':len(ms),'P':p,'Z':z,'U':u,'NA':c['NA'],'SOURCE_EXCLUDED':c['SOURCE_EXCLUDED'],'MISSING_STATE':0,'OTHER':0,'N':n,'B':b}
    for k,v in nums.items():require(int(a[k])==v,'COUNT_MISMATCH: '+k);calc[k]=str(v)
    for k,v in {'share':p/n if n else None,'unknown_low':p/b if b else None,'unknown_high':(p+u)/b if b else None}.items():
        require(a[k] in ('','NA') if v is None else math.isclose(float(a[k]),v,abs_tol=1e-10),'RATIO_MISMATCH: '+k)
        calc[k]='NA' if v is None else str(v)
    require(a['small_n']==('YES' if 0<n<10 else 'NO'),'SMALL_N_MISMATCH')
    recalculated.append(calc)
require(used==set(st),'UNUSED_OR_MISSING_STATE')
require(slice_count==303,'SCENARIO_MEMBER_COUNT')
for r in rows('decomposition_paper_extract'):
    if r['qualification']=='ELIGIBLE':require(math.isclose(float(r['delta_pp']),float(r['composition_pp'])+float(r['within_role_pp']),abs_tol=1e-10),'DECOMPOSITION_IDENTITY')
cross=rows('R_cross_function');q=next(r for r in cross if r['scope']=='WHOLE23' and r['activity']=='ACT_QUALITY');research=next(r for r in cross if r['scope']=='WHOLE23' and r['activity']=='ACT_RESEARCH')
require((research['P'],research['N'])==('48','66') and (q['P'],q['N'],q['unclear_primary'])==('300','459','4'),'CROSS_ACTIVITY_ANCHOR')
FINAL.parent.mkdir(parents=True,exist_ok=True)
R=Path(tempfile.mkdtemp(prefix='.stage_e_partial_',dir=FINAL.parent))
for directory in ('tables','figures'):(R/directory).mkdir()
assets={}
def pct(v,d=1):return f'{float(v)*100:.{d}f}'
def fraction(r):return f"{r['P']}/{r['N']}"
names={'CN_AGIBOT':'智元','CN_ASTRIBOT':'星尘智能','CN_DEEPROBOTICS':'云深处','CN_FOURIER':'傅利叶','CN_GALAXEA':'星海图','CN_GALBOT':'银河通用','CN_LIMX':'逐际动力','CN_NOETIX':'松延动力','CN_PAXINI':'帕西尼','CN_SPIRITAI':'千寻智能','CN_UNITREE':'宇树','CN_XSQUARE':'自变量','US_AMAZON_FTR':'Amazon FAR','US_PHYSICAL_INTELLIGENCE':'Physical Intelligence'}
sample=rows('company_sample_extract');names.update({r['company_id']:names.get(r['company_id'],r['company_name']) for r in sample})
taskname={'ROBOT_MODEL':'机器人模型','ROBOT_RUNTIME':'运行软件','BOARD_CIRCUIT':'板级电路'}
scname={'PRIMARY':'主任务','PLUS_SECONDARY':'加次任务','DEDUP_PRIMARY':'去模板','NO_CAMPUS_PRIMARY':'去校招实习'}
focus=[('ROBOT_MODEL','SK_PYTHON'),('ROBOT_MODEL','SK_PYTORCH'),('ROBOT_RUNTIME','SK_CPP'),('ROBOT_RUNTIME','SK_LINUX'),('BOARD_CIRCUIT','SK_ALTIUM'),('BOARD_CIRCUIT','V2_EMC_SIPI')]
labname={'SK_PYTHON':'Python','SK_PYTORCH':'PyTorch','SK_CPP':'C++','SK_LINUX':'Linux','SK_ALTIUM':'Altium','V2_EMC_SIPI':'EMC / SI / PI'}
assets={}
def table(key,title,headers,data,note):
    assets[key]={'kind':'table','title':title,'headers':headers,'rows':data,'note':note}
    with (R/'tables'/f'{key}.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(headers);w.writerows(data)
q1=rows('q1_existing_summary');roles=rows('company_role_extract')
concrete=sorted([r for r in q1 if r['role'].startswith('RF_') and r['role'] not in ('RF_ALTERNATIVE_DIRECTIONS','RF_COMPOSITE_FUNCTION')],key=lambda r:int(r['P']),reverse=True)
groups=[]
for label in dict.fromkeys(r['stratum_name'] for r in sample):
    sub=[r for r in sample if r['stratum_name']==label]
    groups.append([label,str(len(sub)),str(sum(int(r['n_ads']) for r in sub)),'单列团队' if sub[0]['scope_main_company']!='YES' else '整公司'])
table('T1A','表1a 样本主体与供给范围',['范围类别','主体数','广告数','比较范围'],groups,'公司类别沿用A/B/C阶段证据；不是成熟度评分。全部24主体1,654条，23家整公司1,630条。每主体的观察日期、招聘板及证据ID见附录CSV。')
table('T1B','表1b 整公司职能构成',['主职能','广告数','广告加权 %','公司等权 %'],[[r['role_name'],r['P'],pct(r['ad_weighted']),pct(r['company_equal'])] for r in concrete]+[['复合及多方向','30',pct(30/1630),pct(sum(float(r['company_equal']) for r in q1 if r['role'] in ('RF_ALTERNATIVE_DIRECTIONS','RF_COMPOSITE_FUNCTION'))) ],['歧义 未映射 来源不足','48',pct(48/1630),pct(sum(float(r['company_equal']) for r in q1 if r['role'].startswith('STATUS_')))]],'广告加权分母为1,630，公司等权先除以各公司全部广告数再平均。类别互斥；不能把整公司具体职能1,552条替换为本表分母。')
cross=read(INPUT/'R_cross_function.csv');obj=read(INPUT/'O4_company_role_object.csv');attr=read(INPUT/'O4_attribution_seniority_unknown.csv')
table('T2A','表2a 活动与同名主职能的关系',['活动','活动广告','同名主职能外','外部比例 %'],[['研究探索','66','48','72.7'],['宽质量','459','296 至 300','64.5 至 65.4']],'研究与质量取WHOLE23。宽质量上界包括4条主职能不明；下界将其视为同名主职能内。两活动可共现，不能相加。历史部署活动不纳入。')
odata=[]
for a in attr:
    sub=[r for r in obj if r['company_id']==a['company_id'] and r['role']==a['role'] and r['responsibility']=='ANY_RESPONSIBILITY']
    targets=['MODEL','DATA'] if a['role']=='RF_ML_AI_ENGINEERING' else ['ROBOT_RUNTIME','FULFILMENT_IT']
    vals=[]
    for t in targets:
        r=next(x for x in sub if x['object']==t);vals.append(fraction(r))
    odata.append([names[a['company_id']],'ML' if a['role']=='RF_ML_AI_ENGINEERING' else '软件',*vals,f"{a['product_unknown']}/{a['frame_N']}"])
table('T2B','表2b 四公司两职能的任务对象',['公司','职能','模型或运行','数据或履单IT','产品未知'],odata,'ML行两对象分别为模型、数据；软件行分别为机器人运行、履单IT。分子为涉及对象（承担或参与），分母为本案例该公司该职能广告。对象可共现，不等同于主任务或严格本人责任。84条中81条产品未知。')
dec=rows('decomposition_paper_extract');ds={'MAIN':'主范围','NO_EXPLICIT_CAMPUS_OR_INTERN':'去校招实习','EXACT_DUTY_DEDUP':'去模板','S1_ACTIVITY_COMPLETE':'来源 S1','S2_SOURCE_QUALITY':'来源 S2','S3_SOURCE_QUALITY_LENGTH200':'来源 S3'}
dec.sort(key=lambda r:list(ds).index(r['scenario']))
table('T3','表3 银河通用减Figure工程活动的固定职能分解',['情景','银河覆盖','Figure覆盖','总差 pp','构成 pp','职能内 pp'],[[ds[r['scenario']],f"{r['A_K_N']}/{r['A_total_N']}",f"{r['B_K_N']}/{r['B_total_N']}",*[f'{float(r[k]):+.2f}' if r[k] else 'NA' for k in ['delta_pp','composition_pp','within_role_pp']]] for r in dec],'固定公司支持、制造质量供应链、ML、软件四职能；覆盖分母是该情景活动分析总范围。0/0表示无可比观察而非0%；来源S1至S3不可比较。pp为百分点；分解不表示因果贡献。')
mw=rows('core_existing_MW_aggregates');g=rows('core_existing_G_primary_aggregates')
mprim=[next(r for r in mw if r['scenario']=='PRIMARY' and (r['task'],r['label_code'])==f) for f in focus]
gp=[next(r for r in g if r['metric']=='GENERAL' and r['branch']=='UNCONDITIONAL' and (r['task'],r['label_code'])==f) for f in focus]
table('T4A','表4a 三任务的技术提及和表达方式',['任务与指标','M 正例/分母','M 广告 %','M 等权 %','W 职/必/般/优'],[[taskname[r['task']]+' '+labname[r['label_code']],fraction(r),pct(r['share_ad_weighted']),pct(r['share_company_equal']),'/'.join(r[k] for k in ('DUTY_ANY','REQUIRED','GENERAL','PREFERRED'))] for r in mprim],'W列依次为职责、明确必备、一般要求、优先的广告计数，各自除以本行M正例P；可重叠，不加总。公司等权含N>0且P=0的公司。完整比例和四情景见CSV。')
table('T4B','表4b 一般无条件语境的独立分母',['任务与指标','G 正例/分母','U','G 广告 %','G 等权 %','未知界限 %'],[[taskname[r['task']]+' '+labname[r['label_code']],fraction(r),r['U'],pct(r['share_ad_weighted']),pct(r['share_company_equal']),pct(r['unknown_low_ad'])+' 至 '+pct(r['unknown_high_ad'])] for r in gp],'G仅GENERAL/UNCONDITIONAL格，N=P+Z；未知界限P/(N+U)至(P+U)/(N+U)，不是置信区间。其他21格保存在附录结果表；不能用M分母代替G分母。')
strict=rows('pair_strict_sensitivity');pm=rows('pair_existing_MW')
pairs=[('ROBOT_MODEL','CN_GALBOT'),('ROBOT_MODEL','CN_XSQUARE'),('ROBOT_RUNTIME','CN_GALBOT'),('ROBOT_RUNTIME','CN_XSQUARE'),('BOARD_CIRCUIT','US_APPTRONIK')]
strict.sort(key=lambda r:(pairs.index((r['task'],r['company_id'])),list(scname).index(r['scenario'])))
pd=[]
for r in strict:
    m=next(x for x in pm if all(x[k]==r[k] for k in ('scenario','task','company_id','label_code')))
    pd.append([names[r['company_id']]+' '+labname[r['label_code']],scname[r['scenario']],fraction(m),fraction(r)+(' *' if r['small_n']=='YES' else ''),r['U'],pct(r['unknown_low'])+' 至 '+pct(r['unknown_high'])])
table('T5','表5 固定公司任务指标的四情景比较',['公司与指标','情景','M 正例/分母','G 正例/分母','U','G 未知界限 %'],pd,'Python限模型任务；C++限运行软件；Altium限板级电路。G为一般无条件，*表示0<N<10。新增情景从冻结成员和状态连接汇总，PRIMARY与既有V3吻合；未知赋值界限不包含所有编码误差。')


if args.figures:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','SimHei','DejaVu Sans'],'axes.unicode_minus':False,'font.size':9,'svg.fonttype':'none','figure.facecolor':'white','axes.spines.top':False,'axes.spines.right':False})
    def savefig(key,title,note):
        plt.savefig(R/'figures'/f'{key}.png',dpi=220,bbox_inches='tight',facecolor='white');plt.savefig(R/'figures'/f'{key}.svg',bbox_inches='tight');plt.close()
        assets[key]={'kind':'figure','title':title,'path':f'figures/{key}.png','note':note}
    whole=[x for x in sample if x['scope_main_company']=='YES']
    codes=[r['role'] for r in concrete]
    data=np.array([[float(next(r['share_all'] for r in roles if r['company_id']==c['company_id'] and r['class_code']==code))*100 for code in codes] for c in whole])
    fig,ax=plt.subplots(figsize=(7.8,7.2));im=ax.imshow(data,cmap='Blues',vmin=0,vmax=max(30,np.max(data)),aspect='auto')
    labels=['制造质量供应','软件与平台','ML/AI','公司支持','硬件电气','商务客户','产品项目','机械机电','部署现场','控制规划','数据分析','仿真评测','感知','系统集成','工业设计','研究科学','机器人操作']
    ax.set_xticks(range(len(codes)),labels,rotation=65,ha='right',fontsize=8.5);ax.set_yticks(range(len(whole)),[names[r['company_id']]+f"  ({r['n_ads']})" for r in whole],fontsize=9)
    for i in range(len(whole)):
        for j in range(len(codes)):
            if data[i,j]>=10:ax.text(j,i,f'{data[i,j]:.0f}',ha='center',va='center',fontsize=8,color='white' if data[i,j]>22 else '#16334c')
    fig.colorbar(im,ax=ax,fraction=.025,pad=.025,label='占该公司全部广告 %');fig.tight_layout()
    savefig('F1','图1 整公司公开招聘的17职能构成','括号为全部广告数；颜色为公司内份额，数值只标10%及以上。结构类和未明状态未画入17列，但仍保留在各公司分母；空白浅色不能解释为没有相关员工。')
    d=[r for r in dec if r['qualification']=='ELIGIBLE'];fig,ax=plt.subplots(figsize=(8.8,3.7));y=np.arange(len(d));a=np.array([float(r['composition_pp']) for r in d]);b=np.array([float(r['within_role_pp']) for r in d]);delta=a+b
    ax.barh(y,a,color='#315e83',height=.48,label='构成分量');ax.barh(y,b,color='#bb7747',height=.48,label='职能内分量');ax.scatter(delta,y,color='#101010',marker='D',s=36,label='总差',zorder=5)
    for i in range(len(d)):
        ax.text(a[i]+.35,i,f'{a[i]:+.2f}',va='center',fontsize=9);ax.text(b[i]-.35,i,f'{b[i]:+.2f}',va='center',ha='right',fontsize=9);ax.text(delta[i],i-.3,f'{delta[i]:+.2f}',ha='center',fontsize=9)
    ax.axvline(0,color='#777',lw=.7);ax.set_yticks(y,[ds[r['scenario']] for r in d]);ax.invert_yaxis();ax.set_xlim(-15,27);ax.set_xlabel('银河通用减Figure  百分点');ax.legend(loc='lower center',bbox_to_anchor=(.5,-.4),ncol=3,frameon=False);fig.tight_layout()
    savefig('F2','图2 总差与两个分量方向不同','仅画可比较的三个情景；固定四职能内的描述性恒等式，不将来源S1至S3的NA画作0。')
    pr=[r for r in strict if r['scenario']=='PRIMARY'];fig,ax=plt.subplots(figsize=(8.8,4.1));ys=np.arange(len(pr))
    for i,r in enumerate(pr):
        m=next(x for x in pm if x['scenario']=='PRIMARY' and x['company_id']==r['company_id'] and x['task']==r['task'])
        ax.plot([float(r['unknown_low'])*100,float(r['unknown_high'])*100],[i,i],color='#b0b0b0',lw=6,solid_capstyle='butt',label='G 未知赋值界限' if i==0 else None)
        ax.scatter([int(m['P'])/int(m['N'])*100],[i+.11],marker='o',color='#315e83',s=45,label='M 提及' if i==0 else None,zorder=4)
        ax.scatter([float(r['share'])*100],[i-.11],marker='D',color='#bb7747',s=45,label='G 一般无条件' if i==0 else None,zorder=4)
    ax.set_yticks(ys,[names[r['company_id']]+' '+taskname[r['task']]+' '+labname[r['label_code']]+(' *' if r['small_n']=='YES' else '') for r in pr],fontsize=9);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xticks(range(0,101,20));ax.set_xlabel('各指标自身分母中的比例 %');ax.grid(axis='x',alpha=.2);ax.legend(loc='lower center',bbox_to_anchor=(.5,-.38),ncol=3,frameon=False);fig.tight_layout()
    savefig('F3','图3 主任务中提及与严格语境的公司点值','圆点与菱形使用各自分母；灰线仅为G已识别未知赋值界限，非置信区间。*为G有效分母小于10；完整四情景见表5。')

with (R/'strict_recomputed.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(recalculated[0]));w.writeheader();w.writerows(recalculated)
plot_data={'heatmap_companies':sample,'heatmap_roles':roles,'decomposition':dec,'strict_points':strict,'mention_points':pm}
(R/'figure_data.json').write_text(json.dumps(plot_data,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'paper_assets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'verification.json').write_text(json.dumps({'status':'PASS','input_files_verified':len(manifest),'strict_cells':len(recalculated),'unique_state_keys':len(st),'scenario_member_rows':slice_count,'source_scope':'Accepted compact extracts; not full semantic recoding','figures_rendered':args.figures},indent=2),encoding='utf-8')
os.replace(R,FINAL)
print(json.dumps({'status':'PASS','output':str(FINAL),'strict_cells':20,'table_csvs':len(list((FINAL/'tables').glob('*.csv'))),'figures':args.figures}))
