"""Build paper tables from verified extracts and record-level derived results."""
from pathlib import Path
import csv,json,copy
from derive import read,FOCUS

TASK={'ROBOT_MODEL':'机器人模型','ROBOT_RUNTIME':'运行软件','BOARD_CIRCUIT':'板级电路'}
LABEL={'SK_PYTHON':'Python','SK_PYTORCH':'PyTorch','SK_CPP':'C++','SK_LINUX':'Linux','SK_ALTIUM':'Altium','V2_EMC_SIPI':'EMC / SI / PI'}
def pct(x):return f'{100*float(x):.1f}' if x not in ('',None) else 'NA'
def tables(inp,analysis,out):
    out.mkdir(parents=True,exist_ok=True)
    base=json.loads((inp/'base_assets.json').read_text(encoding='utf-8'))
    assets={k:copy.deepcopy(v) for k,v in base.items() if v['kind']=='table'}
    def add(k,title,heads,rows,note,widths=None):
        assets[k]=dict(kind='table',title=title,headers=heads,rows=rows,note=note)
        if widths:assets[k]['widths']=widths
    assets['T1A']['note']='类别依据主体的产品与服务范围划分。全部24主体1,654条，其中23家整公司1,630条；Amazon FAR的24条按团队单列。逐主体观察日期、招聘板和业务边界见补充材料。'
    add('T0','表1a 分析范围与观察单位',['分析内容','广告范围','单位与分母'],[
      ['整体工作构成','23家整公司，1,630条','每条广告归入一个主职能或结构、未知类别'],
      ['跨职能活动','其中活动可判1,599条','活动可重叠；职能内比例和活动构成使用不同分母'],
      ['具体职能','整公司1,552条','明确归入17类具体职能'],
      ['固定对象案例','四公司两职能，84条','涉及对象可多值；不替代技术分析任务成员'],
      ['工程活动分解','银河通用82条，Figure 60条','两家公司共有且各有至少10条可判广告的四职能'],
      ['技术表达','三组主职能×主任务交集，248条','ML/AI工程×模型105、软件与平台×运行87、硬件电气×板级56；每组两项技术']
      ],'1,654条为包含团队的全资料范围；其余分析按本表限定。技术样本先限整公司，再取对应主职能与主任务交集；加入次任务仍保留主职能限制。技术对应表含496项，不等于496条不同广告。',[3.7,5,8.1])
    assets['T1B']['note']='广告加权以全部1,630条整公司广告为分母，包括1,552条具体职能广告及78条结构或未明记录。公司等权为各公司内部比例的平均值。'
    add('TM','表1b 技术表达的测量层次',['测量','记录内容','计数与解释'],[
      ['M 技术提及','本人职责或资格条件中的明确相关提及','按广告去重；示例、任选与关系未解片段可形成提及'],
      ['W 表达位置','职责、明确必备、一般要求、优先条件','在提及广告中分别计数，四类允许重叠'],
      ['G 具体语境','要求方式与限定关系的组合','每个组合分别记录P、Z、U'],
      ['本文展示的G','GENERAL—UNCONDITIONAL','普通资格要求中的无条件项；明确必备另计'],
      ['U赋值界限','对已识别未知作两种极端赋值','点值P/N，N=P+Z；界限P/B至(P+U)/B，B=N+U']
      ],'提及、位置与语境回答不同测量问题。一般无条件是本文展示的一个G格；全部22格见补充材料S4。',[3.2,6,7.6])
    assets['T1A']['title']='表2a 样本主体与供给范围';assets['T1B']['title']='表2b 整公司职能构成'
    roles=read(inp/'company_role_extract.csv');rn={r['class_code']:r['class_name'] for r in roles} if 'class_name' in roles[0] else {}
    rn.update({'RF_RESEARCH_SCIENCE':'研究科学','RF_ML_AI_ENGINEERING':'ML/AI工程','RF_PERCEPTION':'感知','RF_MANUFACTURING_QUALITY_SUPPLY':'制造质量供应链','RF_HARDWARE_ELECTRICAL':'硬件与电气','RF_MECHANICAL_MECHATRONICS':'机械与机电','RF_SYSTEMS_ENGINEERING_INTEGRATION':'系统工程与集成','RF_DEPLOYMENT_FIELD_SERVICE':'部署与现场服务','RF_ROBOTICS_SOFTWARE':'软件与平台','RF_CORPORATE_SUPPORT':'公司支持'})
    activity=read(analysis/'activity_bidirectional.csv');aa=[]
    select={'ACT_RESEARCH':['RF_RESEARCH_SCIENCE','RF_ML_AI_ENGINEERING','RF_PERCEPTION'],
      'ACT_QUALITY':['RF_MANUFACTURING_QUALITY_SUPPLY','RF_HARDWARE_ELECTRICAL','RF_MECHANICAL_MECHATRONICS','RF_DEPLOYMENT_FIELD_SERVICE','RF_SYSTEMS_ENGINEERING_INTEGRATION']}
    for act,rs in select.items():
      for role in rs:
        r=next(x for x in activity if x['activity']==act and x['role']==role)
        aa.append(['研究探索' if act=='ACT_RESEARCH' else '宽质量',rn[role],f"{r['P']}/{r['within_role_N']}",pct(r['within_role_rate']),f"{r['P']}/{r['activity_positive_N']}",pct(r['role_composition_of_activity'])])
    add('T2A','表3a 活动的职能内发生率与职能分布',['活动','主职能','活动数/职能数','职能内 %','活动数/活动总数','活动构成 %'],aa,
      '职能数限活动可判的广告。研究探索共有66条，宽质量459条。正文列主要分布职能，完整各类（含零值、结构类与未知）见activity_bidirectional.csv。研究科学和制造质量供应链分别为预设对应职能，并非按结果选择。',[1.7,3.9,2.6,2,3,2])
    ob=assets.pop('T2B')
    for key,typ,title,heads in [('T2B','ML','表3b ML/AI工程职能的对象',['公司','模型','数据','产品归属未知']),('T2C','软件','表3c 软件职能的对象',['公司','机器人运行','履单IT','产品归属未知'])]:
        rows=[[r[0],r[2],r[3],r[4]] for r in ob['rows'] if r[1]==typ]
        add(key,title,heads,rows,'分子为承担或参与该对象的广告数，分母为该公司该职能的固定案例数。对象可共现。两表共84条，其中81条无法归属命名产品；对象分类不等于主任务分类。',[4.3,4.2,4.2,4.1])
    original=assets['T3'];assets['S3']=copy.deepcopy(original);assets['S3']['title']='附表A1 工程分解全部情景'
    for row in assets['S3']['rows']:
        row[0]=str(row[0]).replace('S1','R1').replace('S2','R2').replace('S3','R3')
    assets['S3']['note']='银河通用减Figure，固定四共同职能；pp为百分点。覆盖分母为对应情景活动可判广告数。NA表示来源筛选排除银河通用，无法形成公司对比较。R1、R2、R3对应冻结底表S1、S2、S3。'
    assets['T3']['rows']=original['rows'][:3];assets['T3']['title']='表4a 工程活动差异的分解'
    assets['T3']['note']='银河通用减Figure，固定四共同职能。覆盖分母为对应情景活动可判的广告数。完整情景及缺失结果见附表A1。pp为百分点。'
    parts=read(analysis/'decomposition_four_roles.csv')
    add('T3B','表4b 主分析的四职能基础与分量',['职能','银河 活动/广告','Figure 活动/广告','银河/ Figure份额 %','构成 pp','职能内 pp'],[
      [rn[r['role']],f"{r['A_P']}/{r['A_N']}",f"{r['B_P']}/{r['B_N']}",pct(r['A_s'])+' / '+pct(r['B_s']),f"{float(r['composition_pp']):+.2f}",f"{float(r['within_role_pp']):+.2f}"] for r in parts],
      '两公司共同范围的分母分别为82、60；活动数/广告数可直接还原各职能内工程活动率。两类分量分别加总为+19.45和−8.35个百分点。',[3.5,2.6,2.6,3.3,2.4,2.4])
    mw=[next(r for r in read(inp/'core_existing_MW_aggregates.csv') if r['scenario']=='PRIMARY' and (r['task'],r['label_code'])==key) for key in FOCUS]
    add('T4A','表5a 技术提及与表达位置',['任务与技术','M 正例/分母','广告 %','等权 %','职责','必备','一般','优先'],[
      [TASK[r['task']]+' '+LABEL[r['label_code']],f"{r['P']}/{r['N']}",pct(r['share_ad_weighted']),pct(r['share_company_equal']),*[r[k] for k in ('DUTY_ANY','REQUIRED','GENERAL','PREFERRED')]] for r in mw],
      '后四列为提及广告中的表达方式计数，各自可除以本行M正例数；允许重叠。职责按广告合并本人使用与开发。等权均值包括有效分母大于零且正例为零的公司。EMC/SI/PI为兼容性、完整性与相关防护的家族指标，成员按广告取并集去重，与单一Altium工具的粒度不同；成员与分支规则见补充材料S1。',[4.4,2.5,1.7,1.7,1.6,1.6,1.6,1.6])
    assets['T4B']['title']='表5b 一般要求中的无条件表达'
    assets['T4B']['headers'][1]='一般无条件 正例/分母'
    assets['T4B']['note']='G此处仅展示GENERAL—UNCONDITIONAL，不合并明确必备。点值为P/N，N=P+Z；未知界限为P/B至(P+U)/B，B=N+U，不是置信区间。全部22格（含其余21格）的公司与汇总CSV见appendix/补充材料索引.md的S4。'
    ss=read(analysis/'mention_to_context_summary.csv')
    add('T4C','表5c 提及广告与一般无条件状态的逐条对应',['任务与技术','提及数','一般无条件 P','P/提及数 %','未记该格 Z','该格未知 U','其余记录含任选/示例'],[
      [TASK[r['task']]+' '+LABEL[r['label_code']],r['M_positive'],r['M_to_G_P'],pct(int(r['M_to_G_P'])/int(r['M_positive'])),r['M_to_G_Z'],r['M_to_G_U'],f"{r['non_G_any_choice_or_example']}/{int(r['M_to_G_Z'])+int(r['M_to_G_U'])}"] for r in ss],
      'P、Z、U在提及广告中互斥且相加等于提及数。P/提及数以本行全部提及广告为分母，保留U；表5b的点值分母为该任务中此语境的P+Z。最后一列的分母为Z+U，分子为其中至少有一条任选、示例或两者并存表达的广告；可与优先、职责、必备及未解分支重叠，不能用作互斥原因分解。',[3.6,1.3,2.0,2.0,1.7,1.7,4.5])
    cp=read(analysis/'company_context_distribution.csv');cs=[]
    for key in FOCUS:
      r=[x for x in cp if (x['task'],x['label_code'])==key]
      cs.append([TASK[key[0]]+' '+LABEL[key[1]],len(r),sum(int(x['M_N'])>0 for x in r),sum(int(x['M_N'])>=10 for x in r),sum(int(x['G_N'])>0 for x in r),sum(int(x['G_N'])>=10 for x in r),sum(int(x['G_N'])>0 and int(x['G_P'])==0 for x in r)])
    add('T4D','表5d 六项技术的公司覆盖与小样本情况',['任务与技术','有任务公司','M 有效','M ≥10','G 有效','G ≥10','G 有效零值'],cs,
      'G指一般无条件格；有效指N>0，≥10按该层有效分母计算。零值公司仍进入等权均值，N=0留作缺失。完整120行公司点值、分子、分母和未知界限见company_context_distribution.csv。',[4.4,2.4,2,2,2,2,2])
    assets['T5']['title']='附表A2 公司技术案例的情景比较'
    assets['T5']['note']='G为一般无条件，*表示0<N<10。主任务与加入次任务的Python成员相同；各情景成员增减见sensitivity_membership_changes.csv。未知界限不包括尚未识别的编码误差。'
    for key,a in assets.items():
      with (out/(key+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(a['headers']);w.writerows(a['rows'])
    (out/'table_assets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2),encoding='utf-8')
    return assets
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');p.add_argument('--analysis',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print('tables:',len(tables(a.inputs,a.analysis,a.output)))
