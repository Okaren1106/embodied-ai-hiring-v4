"""Bounded record-level analyses; standard library only; no semantic recoding."""
from pathlib import Path
import csv,json,statistics
from collections import defaultdict,Counter

FOCUS=[('ROBOT_MODEL','SK_PYTHON'),('ROBOT_MODEL','SK_PYTORCH'),('ROBOT_RUNTIME','SK_CPP'),('ROBOT_RUNTIME','SK_LINUX'),('BOARD_CIRCUIT','SK_ALTIUM'),('BOARD_CIRCUIT','V2_EMC_SIPI')]
METRICS={'DUTY_OWN_USE','DUTY_OWN_DEVELOP','REQUIRED','GENERAL','PREFERRED'}
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def dump(p,rows):
    assert rows,p
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def ratio(p,n):return p/n if n else None
def derive(inp,out):
    out.mkdir(parents=True,exist_ok=True)
    mem=read(inp/'primary_members.csv');member={r['identity_key']:r for r in mem}
    assert len(mem)==len(member)==248
    states=read(inp/'focus_general_unconditional_states.csv')
    st={(r['identity_key'],r['label_code']):r for r in states}
    assert len(st)==len(states)==496
    evidence=read(inp/'focus_evidence.csv');ev=defaultdict(list)
    for e in evidence:ev[e['identity_key'],e['code']].append(e)
    records=[]
    for (k,c),s in sorted(st.items()):
        m=member[k];assert (m['task'],c) in FOCUS
        ee=[e for e in ev[k,c] if e['metric'] in METRICS]
        ms={e['metric'] for e in ee};bs={e['branch'] for e in ee}
        positive=bool(ee);gs=s['state']
        assert gs in {'P','Z','U','NA','SOURCE_EXCLUDED'}
        if gs=='P':assert positive,(k,c,'G positive without M')
        rec=dict(identity_key=k,reading_id=m['reading_id'],company_id=m['company_id'],role=m['role'],task=m['task'],label_code=c,
          M_positive=int(positive),G_general_unconditional_state=gs,G_state_reason=s['state_reason'],
          non_G_positive=int(positive and gs!='P'),
          only_preferred=int(positive and ms=={'PREFERRED'}),
          only_duty=int(positive and ms<={'DUTY_OWN_USE','DUTY_OWN_DEVELOP'}),
          has_required=int('REQUIRED' in ms),
          has_general_other_branch=int(any(e['metric']=='GENERAL' and e['branch']!='UNCONDITIONAL' for e in ee)),
          has_choice=int('CHOICE' in bs),has_example=int('EXAMPLE' in bs),has_choice_and_example=int('CHOICE_AND_EXAMPLE' in bs),
          has_conditional=int('CONDITIONAL' in bs),has_unresolved_branch=int('UNRESOLVED' in bs),
          metrics_json=json.dumps(sorted(ms)),branches_json=json.dumps(sorted(bs)),
          evidence_ids_json=json.dumps([e['evidence_id'] for e in ee],ensure_ascii=False))
        records.append(rec)
    summary=[];checks=0
    agg=read(inp/'core_existing_MW_aggregates.csv');gagg=read(inp/'core_existing_G_primary_aggregates.csv')
    for task,c in FOCUS:
        rr=[r for r in records if r['task']==task and r['label_code']==c];mp=[r for r in rr if r['M_positive']]
        a=next(r for r in agg if r['scenario']=='PRIMARY' and r['task']==task and r['label_code']==c)
        g=next(r for r in gagg if r['metric']=='GENERAL' and r['branch']=='UNCONDITIONAL' and r['task']==task and r['label_code']==c)
        assert len(mp)==int(a['P']);checks+=1
        for state in ('P','Z','U','NA','SOURCE_EXCLUDED'):
            assert sum(r['G_general_unconditional_state']==state for r in rr)==int(g[state]);checks+=1
        row=dict(task=task,label_code=c,task_ads=len(rr),M_positive=len(mp),M_denominator=int(a['N']),
          M_to_G_P=sum(r['G_general_unconditional_state']=='P' for r in mp),
          M_to_G_Z=sum(r['G_general_unconditional_state']=='Z' for r in mp),
          M_to_G_U=sum(r['G_general_unconditional_state']=='U' for r in mp),
          M_to_G_other=sum(r['G_general_unconditional_state'] in {'NA','SOURCE_EXCLUDED'} for r in mp))
        assert sum(row[x] for x in ('M_to_G_P','M_to_G_Z','M_to_G_U','M_to_G_other'))==len(mp)
        ng=[r for r in mp if r['G_general_unconditional_state']!='P']
        for field in ('only_preferred','only_duty','has_required','has_general_other_branch','has_choice','has_example','has_choice_and_example','has_conditional','has_unresolved_branch'):
            row['non_G_'+field]=sum(r[field] for r in ng)
        row['non_G_any_choice_or_example']=sum(bool(r['has_choice'] or r['has_example'] or r['has_choice_and_example']) for r in ng)
        row['P_given_M']=ratio(row['M_to_G_P'],len(mp))
        summary.append(row)
    cp=read(inp/'core_existing_MW_company.csv');gp=read(inp/'core_existing_G_primary_company.csv')
    gd={(r['task'],r['label_code'],r['company_id']):r for r in gp if r['metric']=='GENERAL' and r['branch']=='UNCONDITIONAL'}
    company=[]
    for m in cp:
        if m['scenario']!='PRIMARY':continue
        key=(m['task'],m['label_code'],m['company_id']);g=gd[key]
        rr=[r for r in records if (r['task'],r['label_code'],r['company_id'])==key]
        assert sum(r['M_positive'] for r in rr)==int(m['P']);checks+=1
        for state in ('P','Z','U','NA','SOURCE_EXCLUDED'):
            assert sum(r['G_general_unconditional_state']==state for r in rr)==int(g[state]);checks+=1
        company.append(dict(task=m['task'],label_code=m['label_code'],company_id=m['company_id'],task_ads=m['total_ads'],
            M_P=m['P'],M_N=m['N'],M_share=m['share'],M_small_n=m['small_n'],
            G_P=g['P'],G_N=g['N'],G_U=g['U'],G_B=g['B'],G_share=g['share'],
            G_unknown_low=g['unknown_low'],G_unknown_high=g['unknown_high'],G_small_n=g['small_n']))
    company.sort(key=lambda r:(FOCUS.index((r['task'],r['label_code'])),r['company_id']))
    assert len(company)==len(gd)
    activities=[r for r in read(inp/'R_role_activity_bidirectional.csv') if r['scope']=='WHOLE23' and r['activity'] in {'ACT_RESEARCH','ACT_QUALITY'}]
    parts=[r for r in read(inp/'D2_decomposition_role_parts.csv') if r['case_id']=='D_MAIN' and r['scenario']=='MAIN' and r['mode']=='FIXED_K' and r['activity']=='ACT_ENGINEERING']
    assert len(parts)==4
    for r in parts:
        a,b,ar,br=[float(r[x]) for x in ('A_s','B_s','A_q','B_q')]
        assert abs(float(r['composition_pp'])-100*(a-b)*(ar+br)/2)<1e-10
        assert abs(float(r['within_role_pp'])-100*(ar-br)*(a+b)/2)<1e-10;checks+=2
    scenarios=read(inp/'V3_two_layer_membership.csv')
    membership=[]
    targets=[('ROBOT_MODEL','CN_GALBOT'),('ROBOT_MODEL','CN_XSQUARE'),('ROBOT_RUNTIME','CN_GALBOT'),('ROBOT_RUNTIME','CN_XSQUARE'),('BOARD_CIRCUIT','US_APPTRONIK')]
    for task,co in targets:
        base={r['identity_key'] for r in scenarios if r['task']==task and r['company_id']==co and r['scenario']=='PRIMARY'}
        for scene in ['PRIMARY','PLUS_SECONDARY','DEDUP_PRIMARY','NO_CAMPUS_PRIMARY']:
            now={r['identity_key'] for r in scenarios if r['task']==task and r['company_id']==co and r['scenario']==scene}
            membership.append(dict(task=task,company_id=co,scenario=scene,n=len(now),added=len(now-base),removed=len(base-now),identical_to_primary=int(now==base)))
    for name,rows in [('ad_context_correspondence',records),('mention_to_context_summary',summary),('company_context_distribution',company),('activity_bidirectional',activities),('decomposition_four_roles',parts),('sensitivity_membership_changes',membership)]:dump(out/(name+'.csv'),rows)
    report=dict(status='PASS',record_technology_pairs=len(records),evidence_rows=len(evidence),company_points=len(company),source_reconciliation_checks=checks,
      interpretation='G-state partition is exclusive; non-G expression flags overlap and are not causal explanations or error rates.')
    (out/'derivation_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print(json.dumps(derive(a.inputs,a.output),ensure_ascii=False))
