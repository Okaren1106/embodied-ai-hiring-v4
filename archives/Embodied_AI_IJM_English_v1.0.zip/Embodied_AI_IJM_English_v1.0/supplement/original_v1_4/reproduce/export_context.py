"""Rebuild readable context from locked text; retain final labels unchanged.
Evidence -> record is m:1; (ad, technology) -> evidence is 1:m.
Line boundaries and heading candidates are navigation, not a new semantic classifier.
Full original fields remain available so headings/lists and repeated passages can be checked.
"""
from pathlib import Path
import csv,json,re,hashlib,html
from collections import defaultdict,Counter

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def dump(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def js(x):return json.dumps(x,ensure_ascii=False,sort_keys=True)
def H(x):return html.escape(str(x),quote=True)
def digest(t):return hashlib.sha256(t.encode('utf-8')).hexdigest()

HEAD=re.compile(r'^(?:岗位职责|工作职责|职位描述|任职要求|职位要求|任职资格|岗位要求|加分项|优先条件|必备条件|硬性要求|技能要求|职责描述|工作内容|职位职责|岗位描述|任职条件|申请要求|基本要求|加分条件|优先考虑|Qualifications|Required Skills|Required Qualifications|Basic Qualifications|Minimum Qualifications|Preferred Qualifications|Preferred Skills|Nice to haves?|Bonus Points|About You|About the Work|About the Role|What You.?ll (?:Do|Bring|Need)|What We.?re Looking For|Requirements|Responsibilities|Day to Day Activities|Your (?:Role|Responsibilities|Profile)|You Have|You Bring|Skills and Experience|Key Responsibilities|Desired Qualifications|Must Haves?)\s*[:：]?$',re.I)
def lines(t):
    return [(m.start(),m.end(),m.group().rstrip('\r\n')) for m in re.finditer(r'[^\n]*(?:\n|$)',t) if m.group()]
def headings(t):
    out=[]
    for start,end,s in lines(t):
        v=s.strip();known=bool(HEAD.fullmatch(v));list_heading=bool(v and len(v)<125 and (v.endswith((':','：')) or re.match(r'^[一二三四五六七八九十]+[、．.]',v)))
        if known or list_heading:out.append(dict(text=s,start=start,end=start+len(s),kind='section' if known else 'list_or_subheading'))
    return out
def locate(t,q,start):
    if str(start).isdigit() and t[int(start):int(start)+len(q)]==q:return int(start),'EXACT_STORED_START'
    xs=[m.start() for m in re.finditer(re.escape(q),t)] if q else []
    assert len(xs)==1,('ambiguous or missing quote',q[:80],xs)
    return xs[0],'UNIQUE_EXACT_RECOVERY'
def block(t,s,e):
    a=t.rfind('\n',0,s)+1;b=t.find('\n',e)
    if b<0:b=len(t)
    return a,b,t[a:b]
def tree_paths(groups,node_id):
    found=[]
    def visit(n,path):
        if not isinstance(n,dict):return
        here={k:n[k] for k in ['id','relation','use','quote','field','start','end'] if k in n}
        nxt=path+[here]
        if node_id and n.get('id')==node_id:found.append(nxt)
        for c in n.get('children',[]):visit(c,nxt)
        if 'expression' in n:visit(n['expression'],nxt)
    for g in groups:visit(g,[])
    return found

STYLE='''<style>body{font:16px/1.65 "Microsoft YaHei",sans-serif;margin:32px auto;max-width:1150px;padding:0 20px;color:#202a34}h1{font-size:27px}h2{margin-top:36px}h3{font-size:18px}a{color:#245777}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border:1px solid #d8dfe5;padding:8px;vertical-align:top;text-align:left}th{background:#eef2f5}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f5f7f8;padding:14px;font:14px/1.7 "Microsoft YaHei",sans-serif}.id{overflow-wrap:anywhere;font-size:12px;color:#52616b}.note{color:#56616b;font-size:14px}section{border-top:1px solid #ddd;padding-top:12px;margin-top:24px}input{width:95%;padding:12px;font-size:16px;margin-bottom:18px}summary{cursor:pointer;font-weight:bold}code{overflow-wrap:anywhere}mark{background:#fff0b9}button{font-size:15px;padding:8px}</style>'''
def page(title,body):return '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+H(title)+'</title>'+STYLE+'<body>'+body+'</body></html>'
def export(inp,analysis,out):
    out.mkdir(parents=True,exist_ok=True);(out/'ads').mkdir(exist_ok=True)
    records=json.loads((inp/'context_records.json').read_text(encoding='utf-8'));raw={r['identity_key']:r for r in records}
    assert len(raw)==len(records)==248
    ev=read(inp/'focus_evidence.csv');assert len(ev)==len({(e['identity_key'],e['evidence_id']) for e in ev})==456
    corr=read(analysis/'ad_context_correspondence.csv');assert len(corr)==496
    assert set(raw)=={c['identity_key'] for c in corr}
    state={(r['identity_key'],r['label_code']):r for r in corr}
    bykey=defaultdict(list);byad=defaultdict(list);enriched=[];warnings=[]
    links={k:'ads/'+r['reading_id']+'_'+digest(k)[:10]+'.html' for k,r in raw.items()}
    for e in ev:
        k=e['identity_key'];r=raw[k];field=e['field'];t=r['fields'][field];q=e['quote'];s,method=locate(t,q,e['start']);end=s+len(q)
        a,b,parent=block(t,s,end);hs=[x for x in headings(t) if x['start']<=s];section=[x for x in hs if x['kind']=='section']
        nearest=section[-1:] or hs[-1:]
        path=tree_paths(r['historical_requirement_groups'],e['requirement_node_id'])
        scope_start=nearest[0]['start'] if nearest else a
        related=[]
        for f,ft in r['fields'].items():
            for m in re.finditer(re.escape(q),ft):
                ca,cb,ct=block(ft,m.start(),m.end());hh=[x for x in headings(ft) if x['start']<=m.start()]
                ss=[x for x in hh if x['kind']=='section']
                related.append(dict(field=f,start=m.start(),end=m.end(),parent_start=ca,parent_end=cb,parent_text=ct,
                    heading_candidates=(ss[-1:]+[x for x in hh if (not ss or x['start']>ss[-1]['start'])][-3:])))
        final_reason=e.get('review_reason') or e.get('reason') or e.get('override_reason') or ''
        item={**e,'company_id':r['company_id'],'company_name':r['company'],'job_title':r['title'],'observation_wave':r['observation_wave'],
          'text_version_hash':r['text_version_hash'],'source_url':r['source_url'],'verified_start':s,'verified_end':end,'location_method_v12':method,
          'parent_start':a,'parent_end':b,'parent_text':parent,'source_field_sha256':digest(t),
          'heading_context_start':scope_start,'heading_context_end':b,'heading_to_evidence_context':t[scope_start:b],
          'nearest_heading_text':' | '.join(x['text'] for x in nearest),'preceding_heading_candidates_json':js(hs),
          'all_exact_occurrence_contexts_json':js(related),'historical_tree_paths_json':js(path),
          'heading_scope_note':'原文最近可识别标题与全部前置标题供定位；全文保留。标题提取不重新赋予要求类别。',
          'final_recorded_reason':final_reason,'reason_status':'RECORDED_FINAL_REVIEW' if final_reason else 'NO_SEPARATE_REASON_RECORDED_SEE_ORIGINAL_CONTEXT',
          'G_general_unconditional_state':state[k,e['code']]['G_general_unconditional_state'],
          'coding_version':r['current_coding_version'],'rule_version':'Q2-v2.1; measurement-v0.7.4/v0.7.5',
          'reader_page':links[k]+'#'+e['code']}
        assert t[a:b]==parent and t[s:end]==q
        enriched.append(item);bykey[k,e['code']].append(item);byad[k].append(item)
        # Diagnostics only: unmatched textual cues must not silently relabel data.
        if e['branch'] in ['CHOICE','EXAMPLE','CHOICE_AND_EXAMPLE']:
            scope=parent+' '+js(path)
            example=bool(re.search(r'例如|比如|诸如|等|如|such as|e\.g\.|including|like\b|examples?',scope,re.I))
            choice=bool(re.search(r'或|至少|任[一意选]|一种|一门|one|either|\bor\b|some|and/or|/|任选',scope,re.I))
            if ('EXAMPLE' in e['branch'] and not example) or ('CHOICE' in e['branch'] and not choice):
                warnings.append(dict(reading_id=r['reading_id'],evidence_id=e['evidence_id'],code=e['code'],branch=e['branch'],parent_text=parent,final_reason=final_reason,kind='CUE_SCREEN_ONLY_NOT_A_CODING_ERROR'))
    dump(out/'context_evidence.csv',enriched)
    (out/'records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    linked=[]
    for c in corr:
        k,code=c['identity_key'],c['label_code'];ee=bykey[k,code]
        linked.append(dict(**c,source_record_page=links[k]+'#'+code,evidence_count=len(ee),all_evidence_ids_json=js([x['evidence_id'] for x in ee]),
          source_text_version_hash=raw[k]['text_version_hash']))
    dump(out/'ad_technology_context_index.csv',linked)
    for k,r in raw.items():
        body='<p><a href="../index.html">返回语境证据索引</a></p><h1>'+H(r['reading_id']+' '+r['company']+' '+r['title'])+'</h1>'
        body+='<p>观察批次：'+H(r['observation_wave'])+'；主职能：'+H(r['role'])+'；主任务：'+H(r['task'])+'</p>'
        body+='<p class="id">稳定身份：'+H(k)+'</p><p class="id">原文版本：'+H(r['text_version_hash'])+'</p>'
        body+='<p><a href="'+H(r['source_url'])+'" rel="noreferrer" target="_blank">原招聘来源</a>（在线页面可能更新；下方保存的是本研究使用的原文版本。）</p>'
        for c in [x for x in linked if x['identity_key']==k]:
            code=c['label_code'];body+='<section id="'+H(code)+'"><h2>'+H(code)+'</h2><p>技术提及正例 M：'+H(c['M_positive'])+'；一般要求—无条件 G：'+H(c['G_general_unconditional_state'])+'</p>'
            body+='<p class="note">以下列出此广告此指标的全部保留证据，包括未进入提及或一般无条件正例的记录。单条片段不能代替广告级状态。</p>'
            for e in bykey[k,code]:
                body+='<h3>'+H(e['evidence_id']+' · '+e['metric']+' / '+e['branch'])+'</h3>'
                body+='<p>定位：'+H(e['field'])+' ['+str(e['verified_start'])+', '+str(e['verified_end'])+')；最近可识别标题：'+H(e['nearest_heading_text'] or '本字段未保留可识别标题；见原文及其他字段')+'</p>'
                body+='<p><b>原技术片段</b></p><pre>'+H(e['quote'])+'</pre><p><b>完整父句或原文列表行</b></p><pre>'+H(e['parent_text'])+'</pre>'
                body+='<p><b>最近标题至该行的原文（供核对作用域）</b></p><pre>'+H(e['heading_to_evidence_context'])+'</pre>'
                body+='<p>最终记录理由：'+H(e['final_recorded_reason'] or '无独立理由文本；保留最终状态与原文供核对。')+'</p>'
                body+='<details><summary>标题、同片段全部位置与历史父节点</summary><p class="note">历史树用于追溯；最终metric/branch以本页所列V3记录为准，不能用旧树覆盖后续修订。</p><pre>'+H(js(dict(preceding_headings=json.loads(e['preceding_heading_candidates_json']),all_locations=json.loads(e['all_exact_occurrence_contexts_json']),historical_paths=json.loads(e['historical_tree_paths_json']))))+'</pre></details>'
            if not bykey[k,code]:body+='<p>本次六指标证据切片中没有此项正例片段。下方提供该广告完整原字段，不能据空证据表推定已完成新的语义复核。</p>'
            body+='</section>'
        body+='<h2>冻结原文字段</h2><p class="note">三个字段均按原样保留。来源系统可能在字段之间或同一字段内重复文字，未为展示去重；栏目、列表及局部修饰须结合完整语境阅读。</p>'
        for f,t in r['fields'].items():body+='<details><summary>'+H(f)+' · '+str(len(t))+'字符</summary><pre>'+H(t or '（原字段为空）')+'</pre></details>'
        (out/links[k]).write_text(page(r['reading_id']+' 语境证据',body),encoding='utf-8')
    body='<h1>六项技术的广告级语境证据</h1><p>本页覆盖248条固定主任务广告、496个广告—技术项和456条保留证据。点击记录可查看全部相关片段、完整父句、栏目标题及三个冻结原文字段。数据状态沿用最终V3；本次补充文本连接，不构成独立双重编码。</p><p><a href="context_evidence.csv">证据CSV</a> · <a href="ad_technology_context_index.csv">广告—技术索引CSV</a> · <a href="records.json">原字段与历史树JSON</a> · <a href="../appendix/测量说明.md">测量说明</a></p><input id="q" aria-label="筛选记录" placeholder="输入阅读编号、公司、技术或状态筛选"><p id="n"></p><table><thead><tr><th>广告</th><th>公司</th><th>技术</th><th>M正例</th><th>一般无条件G</th><th>证据条数</th></tr></thead><tbody>'
    for c in linked:
        r=raw[c['identity_key']];body+='<tr><td><a href="'+H(c['source_record_page'])+'">'+H(c['reading_id'])+'</a></td><td>'+H(r['company'])+'</td><td>'+H(c['label_code'])+'</td><td>'+H(c['M_positive'])+'</td><td>'+H(c['G_general_unconditional_state'])+'</td><td>'+str(c['evidence_count'])+'</td></tr>'
    body+='</tbody></table><script>const rows=[...document.querySelectorAll("tbody tr")],q=document.getElementById("q"),n=document.getElementById("n");function filter(){let k=0;for(const r of rows){r.hidden=!r.textContent.toLowerCase().includes(q.value.toLowerCase());if(!r.hidden)k++}n.textContent="显示 "+k+" / "+rows.length+" 个广告—技术项"}q.addEventListener("input",filter);filter();</script>'
    (out/'index.html').write_text(page('六项技术语境证据',body),encoding='utf-8')
    (out/'context_diagnostics.json').write_text(json.dumps(warnings,ensure_ascii=False,indent=2),encoding='utf-8')
    report=dict(status='PASS',records=len(raw),ad_technology_pairs=len(linked),evidence_rows=len(enriched),exact_quote_locations=len(enriched),
      parent_locations=len(enriched),evidence_keys_unique=True,unmatched_source_ids=0,source_fields_preserved=3*len(raw),
      diagnostic_cue_flags=len(warnings),scope='Text and state linkage; final semantic labels unchanged; heading candidates are navigation')
    (out/'context_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');ap.add_argument('--analysis',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args();print(js(export(a.inputs,a.analysis,a.output)))
