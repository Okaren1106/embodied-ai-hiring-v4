"""Portable, hash-checked reconstruction of the paper's tables and new analyses."""
from pathlib import Path
import argparse,json,hashlib,subprocess,sys,csv,uuid
from derive import derive
from paper_tables import tables
from export_context import export
ROOT=Path(__file__).resolve().parent
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--figures',action='store_true');a=p.parse_args()
    out=a.output.resolve()
    if out.exists():raise SystemExit('Refusing an existing output directory')
    if out==ROOT or ROOT in out.parents:raise SystemExit('Output must be outside the reproduction source directory')
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    seen=set()
    for r in manifest['files']:
        target=(ROOT/r['path']).resolve()
        if target==ROOT or ROOT not in target.parents:raise SystemExit('Input path leaves package')
        if r['path'] in seen:raise SystemExit('Duplicate manifest path')
        seen.add(r['path'])
        if not target.is_file() or digest(target)!=r['sha256']:raise SystemExit('Input integrity failure: '+r['path'])
    final=out
    final.parent.mkdir(parents=True,exist_ok=True)
    out=final.parent/('.'+final.name+'.working-'+uuid.uuid4().hex)
    out.mkdir()
    subprocess.run([sys.executable,str(ROOT/'base_v1_0/reproduce.py'),'--output',str(out/'base_tables')],check=True,cwd=out)
    base=json.loads((ROOT/'inputs/base_assets.json').read_text(encoding='utf-8'))
    for name,asset in base.items():
        if asset['kind']!='table':continue
        with (out/'base_tables/tables'/(name+'.csv')).open(encoding='utf-8-sig',newline='') as f:actual=list(csv.reader(f))
        expected=[[str(v) for v in asset['headers']]]+[[str(v) for v in row] for row in asset['rows']]
        if actual!=expected:raise SystemExit('Baseline table mismatch: '+name)
    report=derive(ROOT/'inputs',out/'analysis')
    assets=tables(ROOT/'inputs',out/'analysis',out/'tables')
    context=export(ROOT/'inputs',out/'analysis',out/'evidence')
    if a.figures:
        from figures import figures
        figures(ROOT/'inputs',out/'figures')
    report.update(context=context,paper_tables=len(assets),verified_package_files=len(seen),figures=a.figures)
    (out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    out.rename(final)
    print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
