from pathlib import Path
import json
from derive import read
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

def figures(inp,out):
    out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','SimHei','DejaVu Sans'],
      'axes.unicode_minus':False,'font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    assets={}
    def save(key,title,note):
        for ext in ['png','svg']:plt.savefig(out/(key+'.'+ext),dpi=240,bbox_inches='tight',facecolor='white')
        plt.close();assets[key]=dict(kind='figure',title=title,path='figures/'+key+'.png',note=note)
    sample=read(inp/'company_sample_extract.csv');whole=[x for x in sample if x['scope_main_company']=='YES']
    names={r['company_id']:r['company_name'] for r in sample}
    names.update({'CN_AGIBOT':'智元','CN_ASTRIBOT':'星尘智能','CN_DEEPROBOTICS':'云深处','CN_FOURIER':'傅利叶','CN_GALAXEA':'星海图','CN_GALBOT':'银河通用','CN_LIMX':'逐际动力','CN_NOETIX':'松延动力','CN_PAXINI':'帕西尼','CN_SPIRITAI':'千寻智能','CN_UNITREE':'宇树','CN_XSQUARE':'自变量','US_PHYSICAL_INTELLIGENCE':'Physical Intelligence'})
    q1=read(inp/'q1_existing_summary.csv');concrete=sorted([r for r in q1 if r['role'].startswith('RF_') and r['role'] not in ('RF_ALTERNATIVE_DIRECTIONS','RF_COMPOSITE_FUNCTION')],key=lambda x:int(x['P']),reverse=True)
    roles=read(inp/'company_role_extract.csv');lookup={(r['company_id'],r['class_code']):float(r['share_all'])*100 for r in roles}
    labels=['制造质量供应','软件与平台','ML/AI','公司支持','硬件电气','商务客户','产品项目','机械机电','部署现场','控制规划','数据分析','仿真评测','感知','系统集成','工业设计','研究科学','机器人操作','复合或多方向','歧义或未映射','来源不足']
    data=[]
    for c in whole:
      co=c['company_id'];v=[lookup[co,r['role']] for r in concrete]
      v += [sum(lookup[co,k] for k in ('RF_ALTERNATIVE_DIRECTIONS','RF_COMPOSITE_FUNCTION')),sum(lookup[co,k] for k in ('AMBIGUOUS','UNMAPPED')),lookup[co,'SOURCE_UNASSESSABLE']]
      assert abs(sum(v)-100)<1e-7;data.append(v)
    data=np.array(data)
    fig,ax=plt.subplots(figsize=(8.6,7.8));im=ax.imshow(data,cmap='Blues',vmin=0,vmax=40,aspect='auto')
    ax.set_xticks(range(20),labels,rotation=65,ha='right',fontsize=9)
    ax.set_yticks(range(len(whole)),[names[r['company_id']]+f" ({r['n_ads']})" for r in whole],fontsize=9.5)
    ax.axvline(16.5,color='#66717b',lw=1.1)
    for i in range(len(whole)):
      for j in range(20):
        if data[i,j]>=8:ax.text(j,i,f'{data[i,j]:.0f}',ha='center',va='center',fontsize=8,color='white' if data[i,j]>23 else '#18354b')
    fig.colorbar(im,ax=ax,fraction=.025,pad=.025,label='占该公司全部广告 %',extend='max');fig.tight_layout()
    save('F1','图1 公司招聘的职能构成与未明记录','括号内为公司广告数，分母保留全部广告；右侧三列分别为结构类、歧义或未映射、来源不足，整行合计100%。色阶40%以上封顶，格内标注8%以上的比例。')
    dec=read(inp/'decomposition_paper_extract.csv') if (inp/'decomposition_paper_extract.csv').exists() else read(inp.parent/'base_v1_0/inputs/decomposition_paper_extract.csv')
    dec=[r for r in dec if r['scenario'] in ('MAIN','NO_EXPLICIT_CAMPUS_OR_INTERN','EXACT_DUTY_DEDUP')]
    scenes={'MAIN':'主分析','NO_EXPLICIT_CAMPUS_OR_INTERN':'去校招实习','EXACT_DUTY_DEDUP':'去模板'}
    order=list(scenes);dec.sort(key=lambda x:order.index(x['scenario']))
    fig,ax=plt.subplots(figsize=(8.2,3.3));y=np.arange(len(dec))
    for off,field,label,color in [(-.23,'delta_pp','总差','#233d54'),(0,'composition_pp','构成分量','#59829e'),(.23,'within_role_pp','职能内分量','#aeb9bf')]:
      values=[float(x[field]) for x in dec];ax.barh(y+off,values,height=.2,label=label,color=color)
      for yy,v in zip(y+off,values):ax.text(v+(.4 if v>=0 else -.4),yy,f'{v:+.2f}',ha='left' if v>=0 else 'right',va='center',fontsize=9)
    ax.set_yticks(y,[scenes[r['scenario']] for r in dec]);ax.invert_yaxis();ax.set_xlim(-15,26);ax.axvline(0,color='#777',lw=.6);ax.set_xlabel('银河通用减Figure  百分点');ax.legend(ncol=3,frameon=False,loc='lower right');fig.tight_layout()
    save('F2','图2 工程活动的总体差异与两个分量','固定四共同职能，图示三个可比情景；来源方案的缺失结果见附表A1。')
    g=[r for r in read(inp/'pair_strict_sensitivity.csv') if r['scenario']=='PRIMARY'];m=[r for r in read(inp/'pair_existing_MW.csv') if r['scenario']=='PRIMARY']
    targets=[('ROBOT_MODEL','CN_GALBOT','银河通用 模型Python'),('ROBOT_MODEL','CN_XSQUARE','自变量 模型Python'),('ROBOT_RUNTIME','CN_GALBOT','银河通用 运行C++'),('ROBOT_RUNTIME','CN_XSQUARE','自变量 运行C++'),('BOARD_CIRCUIT','US_APPTRONIK','Apptronik 板级Altium')]
    fig,axes=plt.subplots(1,2,figsize=(8.8,4.4),sharey=True)
    for i,(task,co,label) in enumerate(targets):
      mr=next(r for r in m if r['task']==task and r['company_id']==co);gr=next(r for r in g if r['task']==task and r['company_id']==co)
      mp=int(mr['P'])/int(mr['N'])*100;gg=int(gr['P'])/int(gr['N'])*100;lo=float(gr['unknown_low'])*100;hi=float(gr['unknown_high'])*100
      axes[0].plot(mp,i,'o',color='#376983',ms=6);axes[0].text(2,i+.25,f"{mr['P']}/{mr['N']}",fontsize=9,color='#454545')
      axes[1].hlines(i,lo,hi,color='#a5adb4',lw=4);axes[1].plot(gg,i,'o',color='#376983',ms=6);axes[1].text(2,i+.25,f"{gr['P']}/{gr['N']}  U={gr['U']}",fontsize=9,color='#454545')
    for ax,title in zip(axes,['技术提及 M','一般要求中的无条件表达 G']):
      ax.set_xlim(0,100);ax.set_xticks([0,25,50,75,100]);ax.set_title(title,fontsize=11);ax.set_xlabel('比例（%）');ax.grid(axis='x',color='#e8e8e8',lw=.5);ax.set_axisbelow(True)
    axes[0].set_yticks(range(5),[x[2] for x in targets]);axes[0].invert_yaxis();axes[0].set_ylim(4.6,-.5);fig.tight_layout(w_pad=2.2)
    save('F3','图3 固定案例的技术提及与一般无条件表达','左右两图的点分别为M、G的P/N，N=P+Z；文字列P/N，G另列未知数U。灰线以B=N+U为分母，从P/B至(P+U)/B，表示已识别未知的赋值界限，不是置信区间。')
    (out/'figure_assets.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2),encoding='utf-8')
    return assets
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');p.add_argument('--output',type=Path,required=True);a=p.parse_args();print('figures:',len(figures(a.inputs,a.output)))
