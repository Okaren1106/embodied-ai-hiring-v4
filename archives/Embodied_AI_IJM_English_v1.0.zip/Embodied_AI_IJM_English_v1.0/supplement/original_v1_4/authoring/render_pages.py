from pathlib import Path
import pypdfium2 as pdfium
from PIL import Image,ImageDraw
import json
E=Path(__file__).resolve().parents[1];dest=E/'verification/pages';dest.mkdir(parents=True,exist_ok=True)
reports=[]
for prefix,name in [('paper','具身智能公开招聘研究_论文修订稿_v1.4'),('summary','具身智能公开招聘研究_一页摘要_v1.4')]:
    pdf=pdfium.PdfDocument(E/(name+'.pdf'))
    texts=[];imgs=[]
    for i,page in enumerate(pdf):
        p=dest/f'{prefix}_{i+1:02d}.png';im=page.render(scale=1.6).to_pil();im.save(p);imgs.append(p)
        t=page.get_textpage().get_text_range();texts.append(t)
    (E/'verification'/(prefix+'_pdf_text.txt')).write_text('\n\n'.join('PAGE '+str(i+1)+'\n'+t for i,t in enumerate(texts)),encoding='utf-8')
    for start in range(0,len(imgs),4):
        sheet=Image.new('RGB',(960,1380),'#ddd');draw=ImageDraw.Draw(sheet)
        for j,p in enumerate(imgs[start:start+4]):
            im=Image.open(p);im.thumbnail((470,650));x=(j%2)*480;y=(j//2)*690
            sheet.paste(im,(x,y+24));draw.text((x+10,y+4),f'{prefix} page {start+j+1}',fill='black')
        sheet.save(dest/f'{prefix}_contact_{start+1:02d}.png')
    reports.append(dict(document=name,pages=len(pdf),text_chars_per_page=[len(t) for t in texts],render='Microsoft Word PDF export; pypdfium2 rasterization; bundled LibreOffice unavailable'))
(E/'verification/render_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False))
