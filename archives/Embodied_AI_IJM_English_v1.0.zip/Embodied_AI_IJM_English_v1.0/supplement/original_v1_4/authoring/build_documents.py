from pathlib import Path
import re,json
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.opc.constants import RELATIONSHIP_TYPE as RT
E=Path(__file__).resolve().parents[1];R=E
assets=json.loads((R/'tables/table_assets.json').read_text(encoding='utf-8'))
assets.update(json.loads((R/'figures/figure_assets.json').read_text(encoding='utf-8')))

def fonts(style,name,size):
    style.font.name='Times New Roman';style.font.size=Pt(size);style.font.color.rgb=RGBColor(0,0,0)
    style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),name)
def make(summary=False):
    d=Document();s=d.sections[0];s.page_height=Cm(29.7);s.page_width=Cm(21)
    for st in d.styles:
        for b in st.element.xpath('.//w:pBdr'):b.getparent().remove(b)
    s.top_margin=s.bottom_margin=Cm(1.8 if summary else 2);s.left_margin=s.right_margin=Cm(2.1)
    s.header_distance=s.footer_distance=Cm(.9)
    fonts(d.styles['Normal'],'宋体',10.5 if summary else 11)
    pf=d.styles['Normal'].paragraph_format;pf.line_spacing=1.18 if summary else 1.3;pf.space_after=Pt(6);pf.widow_control=True
    for name,size in [('Title',18),('Heading 1',14),('Heading 2',12)]:
        fonts(d.styles[name],'黑体',size);p=d.styles[name].paragraph_format;p.keep_with_next=True;p.space_before=Pt(11);p.space_after=Pt(6)
    fonts(d.styles['Caption'],'宋体',10);d.styles['Caption'].font.italic=False;d.styles['Caption'].font.bold=True
    fonts(d.styles['Footer'],'宋体',8)
    d.core_properties.title='具身智能企业公开招聘中的工作组合与技术表达';d.core_properties.subject='研究摘要' if summary else '论文修订稿 v1.4';d.core_properties.author='';d.core_properties.comments=''
    fp=s.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fp.add_run('第 ');fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');fp._p.append(fld);fp.add_run(' 页')
    return d
def text(p,txt):
    for part in re.split(r'(https?://[^\s。]+)',txt):
        if part.startswith(('http://','https://')):
            rel=p.part.relate_to(part,RT.HYPERLINK,is_external=True);h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rel)
            rr=OxmlElement('w:r');pr=OxmlElement('w:rPr');co=OxmlElement('w:color');co.set(qn('w:val'),'315E83');pr.append(co);rr.append(pr);t=OxmlElement('w:t');t.text=('doi:'+part.split('doi.org/')[-1]) if 'doi.org/' in part else '原文链接';rr.append(t);h.append(rr);p._p.append(h)
        else:p.add_run(part)
def table(d,a):
    p=d.add_paragraph(a['title'],'Caption');p.paragraph_format.keep_with_next=True
    t=d.add_table(rows=1,cols=len(a['headers']));t.autofit=False
    defaults={4:[6.8,2.5,3.7,3.8],5:[5,3,2.5,2.5,3.8],6:[3.8,2.7,2.4,2.7,1.1,4.1]}
    widths=a.get('widths',defaults.get(len(a['headers']),[16.8/len(a['headers'])]*len(a['headers'])))
    widths=[x*16.8/sum(widths) for x in widths]
    if a['title'].startswith('表2a'):widths=[8,2,2.5,4.3]
    if a['title'].startswith('表5b'):widths=[4.1,2.8,1,2.4,2.4,4.1]
    if a['title'].startswith('表4a') or a['title'].startswith('附表A1'):widths=[3,2.5,2.5,2.9,2.9,3]
    for c,w in zip(t.columns,widths):c.width=Cm(w)
    borders=OxmlElement('w:tblBorders')
    for side in ('top','left','bottom','right','insideH','insideV'):
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    for idx,vals in enumerate([a['headers']]+a['rows']):
        row=t.rows[0] if idx==0 else t.add_row();trpr=row._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
        if idx==0:trpr.append(OxmlElement('w:tblHeader'))
        for j,(cell,val) in enumerate(zip(row.cells,vals)):
            cell.width=Cm(widths[j]);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            p=cell.paragraphs[0];p.paragraph_format.line_spacing=1.1;p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4)
            if len(a['rows'])<=8 or a['title'].startswith('表2b'):
                p.paragraph_format.keep_with_next=True
            elif a['title'].startswith(('表6','附表A2')):
                p.paragraph_format.keep_with_next=idx==0 or idx%4!=0 or idx==len(a['rows'])
            else:
                p.paragraph_format.keep_with_next=idx in (0,len(a['rows'])-1,len(a['rows']))
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 else WD_ALIGN_PARAGRAPH.CENTER
            run=p.add_run(str(val));run.font.size=Pt(9);run.bold=idx==0
            if idx==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'EEF1F4');cell._tc.get_or_add_tcPr().append(shade)
    p=d.add_paragraph('注：'+a['note']);p.paragraph_format.space_after=Pt(9);p.paragraph_format.line_spacing=1.12
    for r in p.runs:r.font.size=Pt(9)
def figure(d,a):
    p=d.add_paragraph(a['title'],'Caption');p.paragraph_format.keep_with_next=True
    p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.paragraph_format.space_after=Pt(3)
    pic=p.add_run().add_picture(str(R/a['path']),width=Cm(16.7));pic._inline.docPr.set('descr',a['title']+'。'+a['note'])
    p=d.add_paragraph('注：'+a['note']);p.paragraph_format.line_spacing=1.12;p.paragraph_format.space_after=Pt(10)
    for r in p.runs:r.font.size=Pt(9)
def build(source,stem,summary=False):
    d=make(summary);expanded=[]
    for block in source.strip().split('\n\n'):
        b=block.strip();m=re.fullmatch(r'\[\[(\w+)\]\]',b)
        if m:
            a=assets[m[1]]
            if a['kind']=='table':
                table(d,a);expanded.append(a['title']+'\n\n'+'| '+' | '.join(a['headers'])+' |\n'+'| '+' | '.join(['---']*len(a['headers']))+' |\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in a['rows'])+'\n\n注：'+a['note'])
            else:figure(d,a);expanded.append(a['title']+'\n\n!['+a['title']+']('+a['path']+')\n\n注：'+a['note'])
        elif b.startswith('# '):p=d.add_paragraph(b[2:],'Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;expanded.append(b)
        elif b.startswith('## '):
            p=d.add_paragraph(b[3:],'Heading 2' if summary else 'Heading 1')
            expanded.append(b)
        elif b.startswith('### '):d.add_paragraph(b[4:],'Heading 2');expanded.append(b)
        else:
            p=d.add_paragraph();text(p,b);expanded.append(b)
            if not b.startswith(('[','关键词')):p.paragraph_format.first_line_indent=Cm(.75)
            if b.startswith('['):
                p.paragraph_format.keep_together=True
                for run in p.runs:run.font.size=Pt(10)
    d.save(R/(stem+'.docx'));(R/(stem+'.md')).write_text('\n\n'.join(expanded)+'\n',encoding='utf-8')
    return len(d.tables),len(d.inline_shapes)
source=(E/'authoring/manuscript.md').read_text(encoding='utf-8')
print('Paper tables/figures:',build(source,'具身智能公开招聘研究_论文修订稿_v1.4'))
print('Summary:',build((E/'authoring/summary.md').read_text(encoding='utf-8'),'具身智能公开招聘研究_一页摘要_v1.4',True))
(R/'appendix/manuscript_source.md').write_text(source,encoding='utf-8')
