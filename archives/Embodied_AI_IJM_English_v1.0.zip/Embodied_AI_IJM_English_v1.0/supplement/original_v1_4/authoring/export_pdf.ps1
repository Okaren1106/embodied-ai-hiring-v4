$ErrorActionPreference = 'Stop'
$revisionRoot = Split-Path $PSScriptRoot -Parent
$releaseDir = $revisionRoot
$exportDir = Join-Path (Join-Path $revisionRoot 'verification') ('word_export_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $exportDir | Out-Null
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
$word.AutomationSecurity = 3
try {
    foreach ($name in @('具身智能公开招聘研究_论文修订稿_v1.4','具身智能公开招聘研究_一页摘要_v1.4')) {
        $sourcePath = Join-Path $exportDir ($name + '.docx')
        $targetPath = Join-Path $exportDir ($name + '.pdf')
        Copy-Item -LiteralPath (Join-Path $releaseDir ($name + '.docx')) -Destination $sourcePath
        $doc = $word.Documents.Open($sourcePath, $false, $true)
        try {
            $doc.ExportAsFixedFormat($targetPath, 17)
            if (-not (Test-Path -LiteralPath $targetPath)) { throw "PDF not created: $targetPath" }
            Copy-Item -LiteralPath $targetPath -Destination (Join-Path $releaseDir ($name + '.pdf')) -Force
            Write-Output "$name : $($doc.ComputeStatistics(2)) pages"
        } finally { $doc.Close(0) }
    }
} finally { $word.Quit() }
