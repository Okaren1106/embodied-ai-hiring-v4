from pathlib import Path
import re,json,copy,csv,shutil
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.opc.constants import RELATIONSHIP_TYPE as RT

E=Path(__file__).resolve().parents[1]
R=E/'release' if (E/'work').is_dir() else E
W=E/'work' if (E/'work').is_dir() else E/'authoring'
S=W/'sections'
A=json.loads((S/'table_assets_en.json').read_text(encoding='utf-8'))
A.update(json.loads((S/'figure_assets_en.json').read_text(encoding='utf-8')))
LABEL={'T1B':'Table I','T2A':'Table II','T3':'Table III, Panel A','T3B':'Table III, Panel B','T4A':'Table IV, Panel A','T4B':'Table IV, Panel B','T4C':'Table V',
       'T0':'Supplementary Table S1','TM':'Supplementary Table S2','T1A':'Supplementary Table S3','T2B':'Supplementary Table S4','T2C':'Supplementary Table S5','T4D':'Supplementary Table S6','S3':'Supplementary Table S7','T5':'Supplementary Table S8','F1':'Figure 1','F3':'Figure 2','F2':'Supplementary Figure S1'}
MAIN=['T1B','T2A','T3','T3B','T4A','T4B','T4C','F1','F3']
SUP=['T0','TM','T1A','T2B','T2C','T4D','S3','T5','F2']
TITLE={'T1B':'Primary functions in whole-firm recruitment','T2A':'Activity within functions and the distribution of activity advertisements',
       'T3':'Engineering-activity decomposition across sensitivity scenarios','T3B':'Function counts and components of the primary decomposition',
       'T4A':'Technology mentions and statement types','T4B':'Unconditional statements in general qualifications','T4C':'General-qualification context among technology mentions',
       'T0':'Analysis scopes and observation units','TM':'Dimensions of technology measurement','T1A':'Sample entities by product and service scope',
       'T2B':'Work objects within ML/AI engineering','T2C':'Work objects within software and platforms','T4D':'Firm coverage and small denominators',
       'S3':'All engineering-decomposition scenarios','T5':'All technology-case sensitivity scenarios',
       'F1':'Primary-function composition by firm','F3':'Technology mentions and qualification context in selected firm cases','F2':'Engineering-activity differences and their components'}

def final_refs(t):
    t=re.sub(r'; source assets? [A-Z0-9 ,and]+(?=\))','',t)
    t=re.sub(r' \(source assets? [A-Z0-9 ,and]+\)','',t)
    t=t.replace('Table 1','Table I').replace('Table 2','Table II').replace('Table 3','Table III').replace('Table 4','Table IV').replace('Table 5','Table V')
    for old,new in [('Table 5b','Table IV, Panel B'),('Table 5c','Table V'),('Table 4a','Table III, Panel A'),('Table 4b','Table III, Panel B'),('Table 2b','Table I'),('Table 1b','Supplementary Table S2'),('Table 1a','Supplementary Table S1')]:
        # source-number references are normalised separately in notes below
        pass
    return t

for k,a in A.items():
    a['title']=LABEL[k]+'. '+TITLE[k]
    a['note']=a['note'].replace('Table 5b','Table IV, Panel B').replace('Table 5c','Table V').replace('Appendix Table A1','Supplementary Table S7').replace('Appendix Table A2','Supplementary Table S8').replace('Table A1','Supplementary Table S7').replace('Table A2','Supplementary Table S8')
    a['note']=a['note'].replace('appendix/补充材料索引.md','the English Supplement Guide').replace('S4 of the English Supplement Guide','the archive section on all context cells in the English Supplement Guide')
    a['note'] += ' Source: calculations from the job-advertisement corpus.'
    a['note']=a['note'].replace('Supplementary Section S4 reports all 22 cells','the English Supplement Guide links all 22 qualification-relation cells').replace('is listed under S4 in the English Supplement Guide','is linked in the English Supplement Guide under All 22 qualification-relation cells')
    a['note']=a['note'].replace('The company and aggregate CSV for all 22 cells, including the other 21 cells, is linked in the English Supplement Guide under All 22 qualification-relation cells.','All 22 qualification-relation cells are provided in the supplementary data.').replace('R1, R2 and R3 correspond to frozen source tables S1, S2 and S3.','The R1, R2 and R3 source screens are defined in Section 2.4 of the article.')
    for field in ['title','note','headers','rows']:
        if field in a:
            # Editorial spelling and precise source-category translation only.
            def language(v):
                if isinstance(v,list):return [language(x) for x in v]
                if isinstance(v,str):
                    for old,new in [('fulfilment','fulfillment'),('Fulfilment','Fulfillment'),('programme','program'),('labelled','labeled'),('grey','gray'),('Cross-platform models','Cross-embodiment models')]:v=v.replace(old,new)
                return v
            a[field]=language(a[field])

# Compact, meaningful headers; values and source identities remain unchanged.
A['T4A']['headers']=['Task and technology','M positive/N','Ad-weighted %','Firm-equal %','Duties','Required','General','Preferred']
A['T1B']['headers'][1]='Ads'
A['T4B']['headers']=['Task and technology','G positive/N','U','Ad-weighted %','Firm-equal %','Unknown bounds %']
A['T4C']['headers']=['Task and technology','Mentions','G positive P','P/mentions %','G absent Z','G unknown U','Choice/example in Z+U']
A['T4C']['note']=A['T4C']['note'].replace('G absent','No G positive recorded')
A['T4C']['headers'][4]='No G positive Z'
A['T4D']['headers']=['Task and technology','Firms with task','M N>0','M N≥10','G N>0','G N≥10','G valid zero']
A['T2A']['headers']=['Activity','Primary function','Activity / function N','Within function %','Activity / total activity','Activity distribution %']
A['T3']['headers']=['Scenario','Galbot coverage','Figure coverage','Total gap pp','Composition pp','Within function pp']
A['S3']['headers']=A['T3']['headers']
A['T3B']['headers']=['Primary function','Galbot activity/ads','Figure activity/ads','Galbot/Figure shares %','Composition pp','Within function pp']
A['T5']['headers']=['Firm and technology','Scenario','M positive/N','G positive/N','U','G unknown bounds %']

def read(p):
    t=p.read_text(encoding='utf-8').strip()
    if p.name!='references.md':
        for a,b in [('labour','labor'),('fulfilment','fulfillment'),('organisation','organization')]:t=t.replace(a,b)
    return t
front=read(S/'front.md')
methods=read(S/'methods.md')
results=final_refs(read(S/'results.md'))
discussion=read(S/'discussion_conclusion.md')
availability=read(S/'availability.md') if (S/'availability.md').exists() else ''
refs=read(W/'references.md')
for key in SUP:
    results=results.replace('[['+key+']]','')
# Both components remain next to each other; Panel IV A/B are placed together after the context discussion.
results=results.replace('[[T4A]]','').replace('[[T4B]]','[[T4A]]\n\n[[T4B]]')
body='\n\n'.join([front,methods,results,discussion,availability,refs])
body=re.sub(r'\n{3,}','\n\n',body)
# Model assistance is recorded in the editorial report, not invented as author identity.
body=body.replace('This paper does not originate those relations. It applies them to firm comparisons,','The present analysis draws on this relational perspective to compare firms,')
body=body.replace('The last indicator is a union of compatibility, signal-integrity, power-integrity and related protection methods,','The last indicator is a union of electromagnetic compatibility (EMC), signal integrity (SI), power integrity (PI) and related protection methods,')
body=body.replace('without a local choice or example relation in general qualifications','without any governing choice, example or unresolved relation in general qualifications')
body=body.replace('two of the six Nimble advertisements also concern fulfilment IT','two of the six Nimble advertisements concern fulfilment IT')
body=body.replace('two of the six Nimble advertisements also concern fulfillment IT','two of the six Nimble advertisements concern fulfillment information technology')

detail=read(S/'detailed_measurement.md')
detail=detail.replace('# Supplementary methods: detailed measurement and sensitivity rules','## S1. Measurement definitions and analytical scopes')
detail=detail.replace('## Functions, activities, and work objects','### S1.1 Functions activities and work objects').replace('## Technology relations and advertisement-level states','### S1.2 Technology relations and advertisement-level states').replace('## Weighting, display, and sensitivity','### S1.3 Weighting display and sensitivity')
detail=detail.replace('Altium is a named software package',"An 'or' relation between members of the same family can satisfy the family-level union, while the individual members keep their own relations; a choice across families remains a choice. Altium is a named software package")
detail=detail.replace('S1.1 Functions activities and work objects','S1.1 Functions, activities and work objects').replace('S1.3 Weighting display and sensitivity','S1.3 Weighting, display and sensitivity')
detail=detail.replace('qualification relation.','qualification relation. ML, AI and IT denote machine learning, artificial intelligence and information technology, respectively.',1)
appendix=read(S/'appendix.md').replace('# Supplementary Material\n\n','').replace('## A. Supplementary results and reproducibility','## S3. Full sensitivity results and reproducibility').replace('Supplementary Table A1','Supplementary Table S7').replace('Supplementary Table A2','Supplementary Table S8')
appendix=appendix.replace('Any English quotation used in the article or supplement is a translation and must be labeled as such with its advertisement identifier; translation does not remove choice, example, or scope language. English-language advertisements remain verbatim.','Quotations translated from Chinese are identified in the article by advertisement ID and retain choice, example and scope language. Quotations from English-language advertisements remain verbatim.')
appendix=appendix.replace('No public repository, data license, or independent long-term access arrangement is asserted.','A public repository and terms for wider reuse have not yet been established.')
supp='# Supplementary Material\n\nWork Composition and Technology Requirements in Embodied AI Job Advertisements\n\n'+detail+'\n\n## S2. Firm scope work objects and coverage\n\n[[T1A]]\n\n[[T2B]]\n\n[[T2C]]\n\n[[T4D]]\n\n'+appendix+'\n\n[[F2]]\n'
supp=supp.replace('S2. Firm scope work objects and coverage','S2. Firm scope, work objects and coverage')

def make(kind):
    d=Document(); sec=d.sections[0]; sec.page_width=Cm(21.59);sec.page_height=Cm(27.94)
    sec.top_margin=sec.bottom_margin=Cm(2);sec.left_margin=sec.right_margin=Cm(2.1)
    sec.header_distance=sec.footer_distance=Cm(.85)
    for style in d.styles:
        for b in style.element.xpath('.//w:pBdr'): b.getparent().remove(b)
    for name,size in [('Normal',11),('Title',17),('Heading 1',12),('Heading 2',11),('Caption',10),('Footer',9)]:
        st=d.styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
        st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'Times New Roman')
    n=d.styles['Normal'].paragraph_format;n.line_spacing=1.25 if kind!='submission' else 1.5;n.space_after=Pt(6);n.widow_control=True
    for name in ['Heading 1','Heading 2']:
        st=d.styles[name];st.font.bold=name=='Heading 1';st.font.italic=name=='Heading 2'
        st.paragraph_format.keep_with_next=True;st.paragraph_format.space_before=Pt(10);st.paragraph_format.space_after=Pt(5)
    d.styles['Caption'].font.bold=True;d.styles['Caption'].font.italic=False
    d.styles['Caption'].paragraph_format.keep_with_next=True
    d.core_properties.title='Work Composition and Technology Requirements in Embodied AI Job Advertisements'
    d.core_properties.author='';d.core_properties.last_modified_by='';d.core_properties.subject='';d.core_properties.comments=''
    lng=OxmlElement('w:lang');lng.set(qn('w:val'),'en-US');d.styles['Normal'].element.get_or_add_rPr().append(lng)
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');p._p.append(fld)
    return d

def runs(p,text):
    # Render markdown emphasis, literal URLs, and simple inline math with native text/subscript.
    for token in re.split(r'(\*\*.*?\*\*|\*[^*]+\*|`[^`]+`|\$[^$]+\$|https?://[^\s]+|et al\.)',text):
        if not token: continue
        if token.startswith('**'):
            p.add_run(token[2:-2]).bold=True
        elif token.startswith('*'):
            p.add_run(token[1:-1]).italic=True
        elif token.startswith('`'):
            r=p.add_run(token[1:-1]);r.font.name='Consolas';r.font.size=Pt(9)
        elif token.startswith('$'):
            val=token[1:-1].replace('\\sum','Σ').replace('\\in','∈').replace('\\','')
            for part in re.split(r'(_\{[^}]+\}|_[A-Za-z]+)',val):
                r=p.add_run(part.lstrip('_').strip('{}') if part.startswith('_') else part);r.italic=True
                if part.startswith('_'):r.font.subscript=True
        elif token.startswith('http'):
            url=token.rstrip('.,');rel=p.part.relate_to(url,RT.HYPERLINK,is_external=True)
            h=OxmlElement('w:hyperlink');h.set(qn('r:id'),rel);r=OxmlElement('w:r');pr=OxmlElement('w:rPr');co=OxmlElement('w:color');co.set(qn('w:val'),'000000');pr.append(co);r.append(pr);t=OxmlElement('w:t');t.text=url;r.append(t);h.append(r);p._p.append(h)
        else:
            rr=p.add_run(token)
            if token=='et al.':rr.italic=True

def mr(text):
    r=OxmlElement('m:r');t=OxmlElement('m:t');t.text=text;r.append(t);return r
def sub(base,idx):
    e=OxmlElement('m:sSub');a=OxmlElement('m:e');a.append(mr(base));b=OxmlElement('m:sub');b.append(mr(idx));e.extend([a,b]);return e
def frac(top,bottom):
    f=OxmlElement('m:f');n=OxmlElement('m:num');de=OxmlElement('m:den')
    for x in top:n.append(x)
    for x in bottom:de.append(x)
    f.extend([n,de]);return f
def sigma(items):
    n=OxmlElement('m:nary');pr=OxmlElement('m:naryPr');ch=OxmlElement('m:chr');ch.set(qn('m:val'),'∑');pr.append(ch)
    hide=OxmlElement('m:supHide');hide.set(qn('m:val'),'1');pr.append(hide)
    loc=OxmlElement('m:limLoc');loc.set(qn('m:val'),'subSup');pr.append(loc)
    lo=OxmlElement('m:sub');lo.append(mr('k∈K'));up=OxmlElement('m:sup');e=OxmlElement('m:e')
    for x in items:e.append(x)
    n.extend([pr,lo,up,e]);return n
def equation(d,which):
    p=d.add_paragraph();p.paragraph_format.keep_together=True;p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(6)
    om=OxmlElement('m:oMathPara');o=OxmlElement('m:oMath')
    if which=='bounds':
        delimiter=OxmlElement('m:d');pr=OxmlElement('m:dPr')
        for tag,val in [('begChr','['),('endChr',']')]:
            c=OxmlElement('m:'+tag);c.set(qn('m:val'),val);pr.append(c)
        delimiter.append(pr);e=OxmlElement('m:e')
        for x in [frac([mr('P')],[mr('B')]),mr(',  '),frac([mr('P+U')],[mr('B')])]:e.append(x)
        delimiter.append(e);parts=[delimiter]
    else:
        parts=[sub('R','A'),mr('−'),sub('R','B'),mr(' = '),sigma([mr('('),sub('w','Ak'),mr('−'),sub('w','Bk'),mr(')'),frac([sub('r','Ak'),mr('+'),sub('r','Bk')],[mr('2')])]),mr(' + '),sigma([mr('('),sub('r','Ak'),mr('−'),sub('r','Bk'),mr(')'),frac([sub('w','Ak'),mr('+'),sub('w','Bk')],[mr('2')])])]
    for x in parts:o.append(x)
    om.append(o);p._p.append(om)

WIDTHS={'T1B':[7.8,2,3.5,3.5],'T2A':[2,4.2,2.5,2.3,2.9,2.9],'T3':[3.8,2.5,2.5,2.4,2.7,2.9],
 'T3B':[4.1,2.7,2.7,2.9,2.2,2.2],'T4A':[4.1,2.1,1.9,1.9,1.5,1.8,1.7,1.8],
 'T4B':[4.5,2.5,1,2.5,2.5,3.8],'T4C':[4.2,1.8,1.7,2,1.85,1.85,3.4],
 'T4D':[4.6,2,2,2,2,2,2.2],'S3':[3.8,2.5,2.5,2.4,2.7,2.9], 'T5':[3.1,3.4,2.4,2.4,1,4.5]}
def table(d,key):
    a=A[key];p=d.add_paragraph(a['title'],'Caption')
    widths=WIDTHS.get(key,a.get('widths',[16.8/len(a['headers'])]*len(a['headers'])));widths=[w*16.8/sum(widths) for w in widths]
    t=d.add_table(rows=1,cols=len(widths));t.autofit=False
    for col,w in zip(t.columns,widths):col.width=Cm(w)
    borders=OxmlElement('w:tblBorders')
    for side in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    t._tbl.tblPr.append(borders)
    for i,vals in enumerate([a['headers']]+a['rows']):
        row=t.rows[0] if i==0 else t.add_row();pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
        if i==0:pr.append(OxmlElement('w:tblHeader'))
        for j,(cell,val) in enumerate(zip(row.cells,vals)):
            cell.width=Cm(widths[j]);cell.vertical_alignment=WD_ALIGN_VERTICAL.CENTER
            p=cell.paragraphs[0];p.paragraph_format.line_spacing=1.05;p.paragraph_format.space_before=Pt(3);p.paragraph_format.space_after=Pt(3)
            if key=='T1B':p.paragraph_format.space_before=Pt(1.5);p.paragraph_format.space_after=Pt(1.5)
            p.paragraph_format.keep_with_next=i==0
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if j==0 or key in ['T0','TM'] else WD_ALIGN_PARAGRAPH.CENTER
            rr=p.add_run(str(val));rr.font.size=Pt(9 if len(widths)>5 or key=='T1B' else 10);rr.bold=i==0
            if i==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F0F0F0');cell._tc.get_or_add_tcPr().append(shade)
    p=d.add_paragraph('Notes: '+a['note']);p.paragraph_format.line_spacing=1.1;p.paragraph_format.space_after=Pt(9)
    for rr in p.runs:rr.font.size=Pt(9)

def figure(d,key):
    a=A[key];p=d.add_paragraph(a['title'],'Caption')
    p=d.add_paragraph();p.paragraph_format.keep_with_next=True;p.paragraph_format.space_after=Pt(3)
    pic=p.add_run().add_picture(str(R/a['path']),width=Cm(16.7));pic._inline.docPr.set('descr',a['title']+'. '+a['note'])
    p=d.add_paragraph('Notes: '+a['note']);p.paragraph_format.line_spacing=1.1
    for rr in p.runs:rr.font.size=Pt(9)

def expand_asset(k):
    a=A[k]
    if a['kind']=='figure':return a['title']+'\n\n!['+a['title']+']('+a['path']+')\n\nNotes: '+a['note']
    return a['title']+'\n\n| '+' | '.join(a['headers'])+' |\n| '+' | '.join(['---']*len(a['headers']))+' |\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in a['rows'])+'\n\nNotes: '+a['note']

def build(source,name,kind='reader'):
    d=make(kind);expanded=[]
    for b in re.split(r'\n\s*\n',source):
        b=b.strip()
        if not b:continue
        match=re.fullmatch(r'\[\[(\w+)\]\]',b)
        if match:
            k=match[1];a=A[k]
            if kind=='submission':
                label=LABEL[k].split(', Panel')[0]
                p=d.add_paragraph('[Insert '+label+' here]')
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            elif a['kind']=='table':table(d,k)
            else:figure(d,k)
            expanded.append(expand_asset(k) if kind!='submission' else '[Insert '+LABEL[k].split(', Panel')[0]+' here]')
        elif b.startswith('\\['):
            equation(d,'bounds' if '\\left[' in b else 'decomposition');expanded.append(b)
        elif b.startswith('# '):
            p=d.add_paragraph(b[2:],'Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;expanded.append(b)
        elif b.startswith('## '):d.add_paragraph(b[3:],'Heading 1');expanded.append(b)
        elif b.startswith('### '):d.add_paragraph(b[4:],'Heading 2');expanded.append(b)
        else:
            p=d.add_paragraph();runs(p,b);expanded.append(b)
            if re.match(r'^[A-ZÁÉ].*\(\d{4}\),',b):
                p.paragraph_format.left_indent=Cm(.5);p.paragraph_format.first_line_indent=Cm(-.5);p.paragraph_format.line_spacing=1.1;p.paragraph_format.keep_together=True
                for rr in p.runs:rr.font.size=Pt(10)
    d.save(R/(name+'.docx'));(R/(name+'.md')).write_text('\n\n'.join(expanded)+'\n',encoding='utf-8')
    return d

# Retain all source numeric cells and trace their display locations.
for key,a in A.items():
    if a['kind']=='table':
        with (R/'tables'/(key+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f);w.writerow(a['headers']);w.writerows(a['rows'])
(R/'tables/table_assets_en.json').write_text(json.dumps({k:v for k,v in A.items() if v['kind']=='table'},ensure_ascii=False,indent=2),encoding='utf-8')
(R/'figures/figure_assets_en.json').write_text(json.dumps({k:v for k,v in A.items() if v['kind']=='figure'},ensure_ascii=False,indent=2),encoding='utf-8')
(R/'figures/figure_assets.json').write_text(json.dumps({k:v for k,v in A.items() if v['kind']=='figure'},ensure_ascii=False,indent=2),encoding='utf-8')
(R/'authoring/display_crosswalk.json').write_text(json.dumps(LABEL,ensure_ascii=False,indent=2),encoding='utf-8')
(R/'authoring/manuscript_source.md').write_text(body,encoding='utf-8')
(R/'authoring/supplement_source.md').write_text(supp,encoding='utf-8')
build(body,'English_Manuscript_IJM')
submission=re.sub(r'\[\[T3\]\]\s*\[\[T3B\]\]','[[T3]]',body)
submission=re.sub(r'\[\[T4A\]\]\s*\[\[T4B\]\]','[[T4A]]',submission)
submission=submission+'\n\n## Figure captions\n\n'+'\n\n'.join(A[k]['title']+'\n\nNotes: '+A[k]['note'] for k in ['F1','F3'])
build(submission,'IJM_Main_Text','submission')
build(supp,'Supplementary_Material')
d=make('tables');d.add_paragraph('Tables','Title')
for index,group in enumerate([['T1B'],['T2A'],['T3','T3B'],['T4A','T4B'],['T4C']]):
    if index:d.add_page_break()
    for key in group:table(d,key)
d.save(R/'IJM_Tables.docx')
(R/'IJM_Tables.md').write_text('\n\n'.join(expand_asset(k) for k in MAIN if A[k]['kind']=='table'),encoding='utf-8')
guide=read(S/'SUPPLEMENT_GUIDE.md')
(R/'SUPPLEMENT_GUIDE.md').write_text(guide+'\n',encoding='utf-8')
for key,num in [('F1','Figure_1'),('F3','Figure_2'),('F2','Supplementary_Figure_S1')]:
    shutil.copyfile(R/'figures'/(key+'.pdf'),R/'figures'/(num+'.pdf'))
print('Built four English DOCX documents and editable Markdown sources')
