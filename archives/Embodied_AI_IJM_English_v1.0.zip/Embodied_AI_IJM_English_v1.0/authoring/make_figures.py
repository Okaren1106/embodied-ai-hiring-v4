"""Translate the three v1.4 figure programs without changing data selection or values.
Paper figures: preserve source chart type, blue sequential heatmap and neutral
components; export PDF/SVG vectors and PNG for Word. Input is frozen v1.4.
The figure identities F1/F2/F3 are preserved; F2 is supplementary in IJM.
"""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'release' if (ROOT/'work').is_dir() else ROOT
sys.dont_write_bytecode=True
SRC=R/'supplement/original_v1_4/reproduce'
sys.path.insert(0,str(SRC))
source=(SRC/'figures.py').read_text(encoding='utf-8')
replacement={
 "['Microsoft YaHei','SimHei','DejaVu Sans']":"['Arial','DejaVu Sans']",
 "['png','svg']":"['png','svg','pdf']",
 "dpi=240":"dpi=400",
 "'智元'":"'AgiBot'", "'星尘智能'":"'Astribot'", "'云深处'":"'Deep Robotics'",
 "'傅利叶'":"'Fourier'", "'星海图'":"'Galaxea AI'", "'银河通用'":"'Galbot'",
 "'逐际动力'":"'LimX Dynamics'", "'松延动力'":"'Noetix'", "'帕西尼'":"'Paxini'",
 "'千寻智能'":"'Spirit AI'", "'宇树'":"'Unitree'", "'自变量'":"'X Square Robot'",
 "['制造质量供应','软件与平台','ML/AI','公司支持','硬件电气','商务客户','产品项目','机械机电','部署现场','控制规划','数据分析','仿真评测','感知','系统集成','工业设计','研究科学','机器人操作','复合或多方向','歧义或未映射','来源不足']":
 "['Mfg/quality/supply','Software/platforms','ML/AI engineering','Corporate support','Hardware/electrical','Business/customers','Product/projects','Mech./mechatronics','Deployment/field','Control/planning','Data/analytics','Simulation/evaluation','Perception','Systems integration','Industrial/UX design','Research science','Robot operation','Composite/multiple','Ambiguous/unmapped','Insufficient source']",
 "占该公司全部广告 %":"Share of all firm advertisements (%)",
 "主分析":"Primary sample", "去校招实习":"No campus/intern ads", "去模板":"Template deduplication",
 "总差":"Total difference", "构成分量":"Composition", "职能内分量":"Within-function",
 "银河通用减Figure  百分点":"Galbot minus Figure (percentage points)",
 "银河通用 模型Python":"Galbot / model Python", "自变量 模型Python":"X Square Robot / model Python",
 "银河通用 运行C++":"Galbot / runtime C++", "自变量 运行C++":"X Square Robot / runtime C++",
 "Apptronik 板级Altium":"Apptronik / circuitry Altium",
 "技术提及 M":"Technology mentions (M)", "一般要求中的无条件表达 G":"Unconditional general qualifications (G)",
 "比例（%）":"Share (%)",
 "figsize=(8.6,7.8)":"figsize=(9.4,8.3)",
 "figsize=(8.2,3.3)":"figsize=(8.2,3.7)",
 "ax.legend(ncol=3,frameon=False,loc='lower right')":"ax.legend(ncol=3,frameon=False,loc='upper center',bbox_to_anchor=(0.5,1.18))",
 "figsize=(8.8,4.4)":"figsize=(9.4,4.5)",
 "ax.set_title(title,fontsize=11)":"ax.set_title(title,fontsize=9.5)",
}
for a,b in replacement.items():
    assert a in source, a
    source=source.replace(a,b)
namespace={'__name__':'translated_source','__file__':str(SRC/'figures.py')}
exec(compile(source,'translated_v1_4_figures','exec'),namespace)
namespace['figures'](SRC/'inputs',R/'figures')
(R/'verification').mkdir(exist_ok=True)
(R/'verification/figure_translation_map.json').write_text(json.dumps(replacement,ensure_ascii=False,indent=2),encoding='utf-8')
print('Three figures exported as PNG, SVG and PDF from unchanged inputs')
