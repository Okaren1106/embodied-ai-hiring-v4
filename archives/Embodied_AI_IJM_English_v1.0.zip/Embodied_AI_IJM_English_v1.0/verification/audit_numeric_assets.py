import csv
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path


ENGLISH = Path(__file__).resolve().parents[1]
PACKAGED = (ENGLISH / 'authoring').is_dir()
R = ENGLISH if PACKAGED else ENGLISH / 'release'
SOURCE = (R / 'supplement/original_v1_4/tables/table_assets.json') if PACKAGED else (ENGLISH.parent / 'analysis_E_revision_v1_4/release/tables/table_assets.json')
WORK = (R / 'authoring/sections/table_assets_en.json') if PACKAGED else (ENGLISH / 'work/sections/table_assets_en.json')
RELEASE = R / "tables" / "table_assets_en.json"
CROSSWALK = R / "authoring" / "display_crosswalk.json"
MAIN = R / "English_Manuscript_IJM.md"
TABLES = R / "IJM_Tables.md"
SUPPLEMENT = R / "Supplementary_Material.md"
GUIDE = R / "SUPPLEMENT_GUIDE.md"
FIGURES = R / "figures" / "figure_assets_en.json"
OUT = ENGLISH / "verification" / "numeric_asset_audit.json"


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numeric_tokens(value):
    if not isinstance(value, str):
        return []
    return re.findall(r"(?<![A-Za-z])[-+]?\d+(?:,\d{3})*(?:\.\d+)?(?![A-Za-z])", value)


def as_text(value):
    return str(value)


def pct(num, den):
    return round(100 * num / den, 1)


source = read_json(SOURCE)
work = read_json(WORK)
release = read_json(RELEASE)
crosswalk = read_json(CROSSWALK)
figures = read_json(FIGURES)

expected_crosswalk = {
    "T1B": "Table I",
    "T2A": "Table II",
    "T3": "Table III, Panel A",
    "T3B": "Table III, Panel B",
    "T4A": "Table IV, Panel A",
    "T4B": "Table IV, Panel B",
    "T4C": "Table V",
    "T0": "Supplementary Table S1",
    "TM": "Supplementary Table S2",
    "T1A": "Supplementary Table S3",
    "T2B": "Supplementary Table S4",
    "T2C": "Supplementary Table S5",
    "T4D": "Supplementary Table S6",
    "S3": "Supplementary Table S7",
    "T5": "Supplementary Table S8",
    "F1": "Figure 1",
    "F3": "Figure 2",
    "F2": "Supplementary Figure S1",
}

report = {
    "scope": {
        "source": str(SOURCE),
        "work_translation": str(WORK),
        "release_translation": str(RELEASE),
        "release_markdown": [str(MAIN), str(TABLES), str(SUPPLEMENT)],
        "boundary": "Numeric, row-order, formula, and display-cross-reference audit only; no recoding or independent semantic validation.",
    },
    "hashes": {str(path): sha256(path) for path in [SOURCE, WORK, RELEASE, CROSSWALK, MAIN, TABLES, SUPPLEMENT, GUIDE, FIGURES]},
    "asset_identity": {},
    "row_numeric_mismatches": [],
    "csv_mismatches": [],
    "formula_checks": [],
    "display_checks": [],
    "text_note_checks": [],
    "prose_claim_checks": [],
}

report["asset_identity"] = {
    "source_keys": list(source),
    "work_keys_match_source_in_order": list(work) == list(source),
    "release_keys_match_source_in_order": list(release) == list(source),
    "source_table_count": len(source),
    "source_row_count": sum(len(asset["rows"]) for asset in source.values()),
    "work_row_count": sum(len(asset["rows"]) for asset in work.values()),
    "release_row_count": sum(len(asset["rows"]) for asset in release.values()),
    "row_widths_match_work": True,
    "row_widths_match_release": True,
}

for key in source:
    srows = source[key]["rows"]
    for label, candidate in [("work", work[key]), ("release", release[key])]:
        crows = candidate["rows"]
        if len(srows) != len(crows):
            report["row_numeric_mismatches"].append({"asset": key, "target": label, "issue": "row_count", "source": len(srows), "target_value": len(crows)})
            continue
        for row_index, (srow, crow) in enumerate(zip(srows, crows), start=1):
            if len(srow) != len(crow):
                report["asset_identity"][f"row_widths_match_{label}"] = False
                report["row_numeric_mismatches"].append({"asset": key, "target": label, "row": row_index, "issue": "column_count", "source": len(srow), "target_value": len(crow)})
                continue
            for col_index, (scell, ccell) in enumerate(zip(srow, crow), start=1):
                s_nums = numeric_tokens(as_text(scell))
                c_nums = numeric_tokens(as_text(ccell))
                if s_nums != c_nums:
                    report["row_numeric_mismatches"].append({"asset": key, "target": label, "row": row_index, "column": col_index, "issue": "numeric_tokens", "source": scell, "target_value": ccell})
                if as_text(scell).count("*") != as_text(ccell).count("*"):
                    report["row_numeric_mismatches"].append({"asset": key, "target": label, "row": row_index, "column": col_index, "issue": "star_marker", "source": scell, "target_value": ccell})

for key, asset in release.items():
    csv_path = R / "tables" / f"{key}.csv"
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle))
    csv_data = rows[1:]
    json_data = [[as_text(cell) for cell in row] for row in asset["rows"]]
    if csv_data != json_data:
        report["csv_mismatches"].append({"asset": key, "csv_rows": len(csv_data), "json_rows": len(json_data)})


def add_formula(name, observed, expected, tolerance=1e-9, source_cells=None):
    ok = math.isclose(float(observed), float(expected), abs_tol=tolerance)
    report["formula_checks"].append({"name": name, "status": "pass" if ok else "fail", "observed": observed, "expected": expected, "tolerance": tolerance, "source_cells": source_cells or []})


# Sample and function totals.
t1a = source["T1A"]["rows"]
add_formula("T1A entity total", sum(int(row[1]) for row in t1a), 24, source_cells=["T1A rows 1–5, entities"])
add_formula("T1A advertisement total", sum(int(row[2]) for row in t1a), 1654, source_cells=["T1A rows 1–5, advertisements"])
add_formula("T1A whole-firm advertisements", sum(int(row[2]) for row in t1a if row[3] == "整公司"), 1630, source_cells=["T1A whole-firm rows"])
add_formula("T1A whole-firm entities", sum(int(row[1]) for row in t1a if row[3] == "整公司"), 23, source_cells=["T1A whole-firm rows"])
add_formula("T1B row counts sum", sum(int(row[1]) for row in source["T1B"]["rows"]), 1630, source_cells=["T1B advertisement-count column"])
for idx, row in enumerate(source["T1B"]["rows"], start=1):
    add_formula(f"T1B row {idx} ad-weighted percent", float(row[2]), pct(int(row[1]), 1630), tolerance=0.05, source_cells=[f"T1B row {idx}"])

# Bidirectional activity ratios.
for idx, row in enumerate(source["T2A"]["rows"], start=1):
    n1, d1 = map(int, row[2].split("/"))
    n2, d2 = map(int, row[4].split("/"))
    add_formula(f"T2A row {idx} within-function percent", float(row[3]), pct(n1, d1), tolerance=0.05, source_cells=[f"T2A row {idx}"])
    add_formula(f"T2A row {idx} activity-composition percent", float(row[5]), pct(n2, d2), tolerance=0.05, source_cells=[f"T2A row {idx}"])

# Work-object case denominator.
case_total = sum(int(row[1].split("/")[1]) for row in source["T2B"]["rows"]) + sum(int(row[1].split("/")[1]) for row in source["T2C"]["rows"])
add_formula("T2B+T2C fixed-case advertisements", case_total, 84, source_cells=["T2B and T2C first object denominators"])

# Engineering decomposition and direct sums.
for idx, row in enumerate(source["T3"]["rows"], start=1):
    add_formula(f"T3 row {idx} component identity", float(row[3]), float(row[4]) + float(row[5]), tolerance=0.011, source_cells=[f"T3 row {idx}, total/composition/within-function"])
t3b = source["T3B"]["rows"]
gal_activity = sum(int(row[1].split("/")[0]) for row in t3b)
fig_activity = sum(int(row[2].split("/")[0]) for row in t3b)
gal_ads = sum(int(row[1].split("/")[1]) for row in t3b)
fig_ads = sum(int(row[2].split("/")[1]) for row in t3b)
add_formula("T3B Galbot engineering positives", gal_activity, 46, source_cells=["T3B Galbot activity numerators"])
add_formula("T3B Figure engineering positives", fig_activity, 27, source_cells=["T3B Figure activity numerators"])
add_formula("T3B Galbot denominator", gal_ads, 82, source_cells=["T3B Galbot ad denominators"])
add_formula("T3B Figure denominator", fig_ads, 60, source_cells=["T3B Figure ad denominators"])
add_formula("Main engineering-rate gap (pp)", round(100 * gal_activity / gal_ads - 100 * fig_activity / fig_ads, 2), 11.10, tolerance=0.005, source_cells=["T3B activity/ad cells"])
add_formula("Galbot ML+software composition numerator", sum(int(t3b[i][1].split("/")[1]) for i in [2, 3]), 49, source_cells=["T3B ML/AI and software Galbot denominators"])
add_formula("Figure ML+software composition numerator", sum(int(t3b[i][2].split("/")[1]) for i in [2, 3]), 21, source_cells=["T3B ML/AI and software Figure denominators"])

# Mention percentages.
for idx, row in enumerate(source["T4A"]["rows"], start=1):
    p, n = map(int, row[1].split("/"))
    add_formula(f"T4A row {idx} ad-weighted mention percent", float(row[2]), pct(p, n), tolerance=0.05, source_cells=[f"T4A row {idx}"])

# Task-level G point values and bounds.
for idx, row in enumerate(source["T4B"]["rows"], start=1):
    p, n = map(int, row[1].split("/"))
    u = int(row[2])
    lo, hi = [float(x) for x in row[5].replace("至", "to").split("to")]
    b = n + u
    add_formula(f"T4B row {idx} point percent", float(row[3]), pct(p, n), tolerance=0.05, source_cells=[f"T4B row {idx}"])
    add_formula(f"T4B row {idx} lower bound", lo, pct(p, b), tolerance=0.05, source_cells=[f"T4B row {idx}"])
    add_formula(f"T4B row {idx} upper bound", hi, pct(p + u, b), tolerance=0.05, source_cells=[f"T4B row {idx}"])

# Mention-to-context correspondence.
for idx, row in enumerate(source["T4C"]["rows"], start=1):
    m, p, z, u = int(row[1]), int(row[2]), int(row[4]), int(row[5])
    other_num, other_den = map(int, row[6].split("/"))
    add_formula(f"T4C row {idx} P+Z+U identity", p + z + u, m, source_cells=[f"T4C row {idx}"])
    add_formula(f"T4C row {idx} P/mentions percent", float(row[3]), pct(p, m), tolerance=0.05, source_cells=[f"T4C row {idx}"])
    add_formula(f"T4C row {idx} other-record denominator", other_den, z + u, source_cells=[f"T4C row {idx}"])

# Technology-case bounds and small-sample marks.
for idx, row in enumerate(source["T5"]["rows"], start=1):
    _, b = map(int, row[2].split("/"))
    g_text = row[3]
    p, n = map(int, g_text.replace("*", "").strip().split("/"))
    u = int(row[4])
    lo, hi = [float(x) for x in row[5].replace("至", "to").split("to")]
    add_formula(f"T5 row {idx} B=N+U", b, n + u, source_cells=[f"T5 row {idx}"])
    add_formula(f"T5 row {idx} lower bound", lo, pct(p, b), tolerance=0.05, source_cells=[f"T5 row {idx}"])
    add_formula(f"T5 row {idx} upper bound", hi, pct(p + u, b), tolerance=0.05, source_cells=[f"T5 row {idx}"])
    expected_star = 0 < n < 10
    report["formula_checks"].append({"name": f"T5 row {idx} small-sample marker", "status": "pass" if (("*" in g_text) == expected_star) else "fail", "observed": "*" in g_text, "expected": expected_star, "source_cells": [f"T5 row {idx}"]})

# Known prose identities/bounds from source tables.
quality_outside_lo = round(100 * 296 / 459, 1)
quality_outside_hi = round(100 * 300 / 459, 1)
add_formula("Quality activity outside-function lower assignment", quality_outside_lo, 64.5, tolerance=0.05, source_cells=["manuscript source: 296 outside, 4 ambiguous, 459 total"])
add_formula("Quality activity outside-function upper assignment", quality_outside_hi, 65.4, tolerance=0.05, source_cells=["manuscript source: 296 outside, 4 ambiguous, 459 total"])

main_text = MAIN.read_text(encoding="utf-8")
tables_text = TABLES.read_text(encoding="utf-8")
supp_text = SUPPLEMENT.read_text(encoding="utf-8")
guide_text = GUIDE.read_text(encoding="utf-8")

report["display_checks"].append({"name": "display crosswalk exact mapping", "status": "pass" if crosswalk == expected_crosswalk else "fail", "observed": crosswalk, "expected": expected_crosswalk})
for key, label in expected_crosswalk.items():
    if key.startswith("F"):
        title = figures[key]["title"]
    else:
        title = release[key]["title"]
    report["display_checks"].append({"name": f"{key} title begins with display label", "status": "pass" if title.startswith(label + ".") else "fail", "observed": title, "expected": label})

for label in ["Table I", "Table II", "Table III, Panel A", "Table III, Panel B", "Table IV, Panel A", "Table IV, Panel B", "Table V", "Figure 1", "Figure 2"]:
    report["display_checks"].append({"name": f"main manuscript contains {label}", "status": "pass" if label in main_text else "fail"})
for label in [f"Supplementary Table S{i}" for i in range(1, 9)] + ["Supplementary Figure S1"]:
    report["display_checks"].append({"name": f"supplement contains {label}", "status": "pass" if label in supp_text else "fail"})

stale_patterns = [
    r"\bTable (?:1a|1b|2a|2b|3a|3b|3c|4a|4b|5a|5b|5c|5d|A1|A2)\b",
    r"\bSupplementary Table A[12]\b",
    r"\bFigure 3\b",
    r"source asset(?:s)?\b",
]
for pattern in stale_patterns:
    matches = []
    for file_name, text_value in [("English_Manuscript_IJM.md", main_text), ("IJM_Tables.md", tables_text), ("Supplementary_Material.md", supp_text)]:
        for match in re.finditer(pattern, text_value, flags=re.I):
            line = text_value.count("\n", 0, match.start()) + 1
            matches.append({"file": file_name, "line": line, "text": match.group(0)})
    report["display_checks"].append({"name": f"no stale display label matching {pattern}", "status": "pass" if not matches else "fail", "matches": matches})

han = re.compile(r"[\u3400-\u9fff]")
for key, asset in release.items():
    for field in ["title", "note"]:
        matches = han.findall(asset[field])
        report["text_note_checks"].append({"asset": key, "field": field, "status": "pass" if not matches else "fail", "han_character_count": len(matches)})
for key, asset in figures.items():
    for field in ["title", "note"]:
        matches = han.findall(asset[field])
        report["text_note_checks"].append({"asset": key, "field": field, "status": "pass" if not matches else "fail", "han_character_count": len(matches)})

# Cross-reference checks for the all-22-cell note.
tm_note = release["TM"]["note"]
t4b_note = release["T4B"]["note"]
supp_sections = re.findall(r"^## (S\d+)\.", supp_text, flags=re.M)
report["text_note_checks"].append({"asset": "TM", "field": "note cross-reference", "status": "fail" if "Supplementary Section S4" in tm_note and "S4" not in supp_sections else "pass", "observed": tm_note, "available_supplement_sections": supp_sections})
report["text_note_checks"].append({"asset": "T4B", "field": "note cross-reference", "status": "fail" if "under S4" in t4b_note and not re.search(r"^[-*].*S4", guide_text, flags=re.M) else "pass", "observed": t4b_note, "guide_has_explicit_S4_label": bool(re.search(r"^[-*].*S4", guide_text, flags=re.M))})

# Key load-bearing prose claims checked against the frozen table cells or direct sums above.
prose_expectations = [
    ("corpus size", "1,654 advertisements from 24 entities", ["T1A entity and advertisement totals"]),
    ("whole-firm sample", "The main sample contains 1,630 advertisements from 23 whole-firm recruitment boards", ["T1A whole-firm totals"]),
    ("research outside corresponding function", "48 of the 66 research-activity advertisements (72.7 per cent) lie outside the prespecified corresponding function of research science", ["T2A research total and source manuscript outside-function count"]),
    ("quality incidence/share distinction", "159/214 manufacturing, quality and supply-chain advertisements (74.3 per cent), and those 159 account for 34.6 per cent of the 459 advertisements with quality-related activity", ["T2A manufacturing-quality row"]),
    ("quality outside-function assignment bounds", "64.5–65.4 per cent", ["296 outside, 4 ambiguous, 459 total"]),
    ("engineering rate counts and total gap", "Engineering activity appears in 46/82 Galbot advertisements (56.1 per cent) and 27/60 Figure advertisements (45.0 per cent), a +11.10-point difference", ["T3B four rows"]),
    ("engineering composition counts", "49/82 Galbot advertisements (59.8 per cent), compared with 21/60 at Figure (35.0 per cent)", ["T3B ML/AI and software denominator sums"]),
    ("engineering decomposition", "+19.45-point composition component", ["T3 main scope"]),
    ("engineering within-function component", "−8.35-point within-function component", ["T3 main scope"]),
    ("technology mention denominators", "Python and PyTorch appear in 73/105 and 83/105 robot-modeling advertisements", ["T4A rows 1–2"]),
    ("runtime mention denominators", "C++ and Linux appear in 80/87 and 52/87 robot-runtime-software advertisements", ["T4A rows 3–4"]),
    ("board-level mention denominators", "Altium appears in 24/56 board-level-circuitry advertisements", ["T4A row 5"]),
    ("G task-level values", "40/88 for Python, 20/97 for PyTorch, 38/64 for C++, 47/86 for Linux, 5/56 for Altium and 15/56 for EMC/SI/PI", ["T4B rows 1–6"]),
    ("mention-level PyTorch states", "PyTorch has GENERAL—UNCONDITIONAL status in 20/83; 55 record Z and eight U", ["T4C row 2"]),
    ("mention-level Linux proportion", "Linux reaches 47/52 (90.4 per cent)", ["T4C row 4"]),
    ("firm-level coverage", "120 firm–technology points across 22 robot-modeling, 20 runtime-software and 18 board-level-circuitry firms", ["T4D rows"]),
    ("Python case counts and bounds", "12/16 with U=2 and 3/14 with U=7, giving non-overlapping unknown-assignment bounds of 66.7–77.8 and 14.3–47.6 per cent", ["T5 main-task Python rows"]),
    ("C++ case counts", "14/16 at Galbot and 9/10 at X Square Robot", ["T5 main-task C++ rows"]),
    ("Apptronik Altium case", "seven of 12 board-level advertisements mention Altium, but only one records it as GENERAL—UNCONDITIONAL", ["T5 main-task Apptronik row and source prose"]),
]
for name, phrase, evidence in prose_expectations:
    report["prose_claim_checks"].append({"name": name, "status": "pass" if phrase in main_text else "fail", "expected_phrase": phrase, "evidence": evidence})

report["summary"] = {
    "row_numeric_mismatch_count": len(report["row_numeric_mismatches"]),
    "csv_mismatch_count": len(report["csv_mismatches"]),
    "formula_check_count": len(report["formula_checks"]),
    "formula_fail_count": sum(item["status"] != "pass" for item in report["formula_checks"]),
    "display_check_count": len(report["display_checks"]),
    "display_fail_count": sum(item["status"] != "pass" for item in report["display_checks"]),
    "note_check_count": len(report["text_note_checks"]),
    "note_fail_count": sum(item["status"] != "pass" for item in report["text_note_checks"]),
    "prose_claim_check_count": len(report["prose_claim_checks"]),
    "prose_claim_fail_count": sum(item["status"] != "pass" for item in report["prose_claim_checks"]),
}

OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report["summary"], ensure_ascii=False))
